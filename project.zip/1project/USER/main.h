#ifndef __MAIN_H
#define __MAIN_H	 
#include "sys.h"
#include <string.h>
#include <stdio.h>
#include "delay.h"
#include "usart.h"

#include "FreeRTOS.h"
#include "task.h"

#include <math.h>
#include "magnetic.h"
#include "stmflash.h"
#include "buildmap.h"
#include "malloc.h"

#include "ros_usart.h"
#include "can.h"
#include "user_times.h"
#include "control.h"
#include "iwdg.h"
#include "encoder.h"
#include "adc.h"
#include "pid_motor.h"
#include "gpio_input.h"
#include "gpio_ouput.h"
#include "mc6c.h"
#include "buffer.h"



//�������ȼ�
#define START_TASK_PRIO		1
//�����ջ��С	
#define START_STK_SIZE 		256 






#endif
