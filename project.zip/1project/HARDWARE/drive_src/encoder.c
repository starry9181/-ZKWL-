#include "encoder.h"

void Get_Encoder_T1(EncoderType *GetEncoder,TIM_TypeDef* TIMx)
{
	s32 CNT_temp,CNT_last;
	GetEncoder->cnt = TIMx -> CNT;
	CNT_last = GetEncoder->CNT;
	CNT_temp = GetEncoder->rcnt * prd + GetEncoder->cnt;  
	GetEncoder->V = CNT_temp - CNT_last;		

	while ((s32)(GetEncoder->V)>Vbreak)				 
	{							      
		GetEncoder->rcnt--;					      
		CNT_temp = GetEncoder->rcnt * prd + GetEncoder->cnt;
		GetEncoder->V = CNT_temp - CNT_last;		 
	}							     
	while ((s32)(GetEncoder->V)<-Vbreak)			   
	{							      
		GetEncoder->rcnt++;					      
		CNT_temp = GetEncoder->rcnt * prd + GetEncoder->cnt;
		GetEncoder->V = CNT_temp - CNT_last;		 
	}
	GetEncoder->CNT = CNT_temp;				 
}

EncoderType GetEncoder1;
EncoderType GetEncoder2;
EncoderType GetEncoder3;
EncoderType GetEncoder4;

void all_getencoder(void)
{
	Get_Encoder_T1(&GetEncoder1,TIM1);
	Get_Encoder_T1(&GetEncoder2,TIM3);
	Get_Encoder_T1(&GetEncoder3,TIM4);
	Get_Encoder_T1(&GetEncoder4,TIM5);
}







