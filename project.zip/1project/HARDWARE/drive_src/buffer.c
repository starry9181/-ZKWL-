#include "buffer.h"
#include "gpio_ouput.h"
/*******************************************************
* Function Name  : BeefON
* Description    : ���������ú���
* Input          : cnt���������� time������ʱ��
* Output         : None
* Return         : None
*********************************************************/

typedef struct
{
	u8 cnt;//��������
	u16 Time;//�������
	u8 Flag;
}BEEFTOON;
BEEFTOON BeefToOn;

void BeefON(u8 cnt,u16 time)
{
	BeefToOn.cnt = cnt;
	BeefToOn.Time= time/100;
	BeefToOn.Flag=1;
}

/*******************************************************
* Function Name  : BeefTOON
* Description    : ��������ѭ��
* Input          : None
* Output         : None
* Return         : None
*********************************************************/
void BeefTOON(void)
{
	static u8 BeefStep = 0,TimeCnt = 0;
	if(BeefToOn.Flag)
	{
		TimeCnt++;
		if(TimeCnt < BeefToOn.Time)
		{
			return;
		}
		TimeCnt = 0;
		switch(BeefStep)
		{
			case 0:
			{
				if(BeefToOn.cnt --)
				{
					BEEF = 1;
					BeefStep = 1;
				}
				else
				{
					BEEF = 0;
					BeefToOn.Flag = 0;
					BeefStep = 0;
				}
				break;
			}
			case 1:
			{
				BEEF = 0;
				BeefStep = 0;
				break;
			}
		}
	}
	else
	{
		TimeCnt = 0;
	}

}





