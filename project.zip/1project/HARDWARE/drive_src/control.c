#include "control.h"
#include "FreeRTOS.h"
#include "task.h"

void TIM6_IRQHandler(void)
{
	taskENTER_CRITICAL();           //
	if(TIM_GetITStatus(TIM6, TIM_IT_Update) != RESET)
	{
//		GET_ENCODER();
//		SpeedControl_2();
	}
	TIM_ClearITPendingBit(TIM6,TIM_IT_Update);//��������жϱ�־λ
	taskEXIT_CRITICAL();            //
}











