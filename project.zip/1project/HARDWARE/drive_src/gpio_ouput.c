#include "gpio_ouput.h"

//RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB | RCC_APB2Periph_GPIOC,ENABLE);

void gpio_ouput_init(uint32_t RCC_APB2Periph,GPIO_TypeDef* GPIOx,uint16_t GPIO_Pin,GPIOMode_TypeDef mode)
{
	GPIO_InitTypeDef  GPIO_InitStructre;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph,ENABLE);
	GPIO_InitStructre.GPIO_Pin =GPIO_Pin;
	GPIO_InitStructre.GPIO_Mode = mode;  //  GPIO_Mode_Out_OD
																			 // GPIO_Mode_Out_PP
																			 // GPIO_Mode_AF_OD 
																			 // GPIO_Mode_AF_PP 
	GPIO_InitStructre.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_Init(GPIOx,&GPIO_InitStructre);

}

void all_gpio_ouput_init(void)
{
	gpio_ouput_init( RCC_APB2Periph_GPIOA,GPIOA,GPIO_Pin_8,GPIO_Mode_Out_PP);//������

}














