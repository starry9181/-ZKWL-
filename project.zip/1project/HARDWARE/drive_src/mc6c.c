#include "mc6c.h"
#include "ros_usart.h"
#include "string.h"
#include "stdio.h"
MC6C Mc6c;
static uint16_t _channels[16];
void MC6CInit(void)
{
	UART4_Config(100000);
	memset(Mc6c.DeCH,0,sizeof(Mc6c.DeCH));
	memset(Mc6c.NoCH,0,sizeof(Mc6c.NoCH));
	memset(_channels,0,sizeof(_channels));
	//��ʼ��Ϊ����״̬
	Mc6c.DisconFlag = 1;
}

/*******************************************************************************
* Function Name  : Sbus_Data_Count  
* Description    : ���ң��������
* Input          : ң������
* Output         : None
* Return         : None 
****************************************************************************** */
void Sbus_Data_Count(uint8_t *buffer)
{
	
	static uint8_t i=0;
	
	if(buffer[0] == 0x0F && buffer[21] == 0xEA && buffer[22] == 0x53)
	{
		_channels[0]  = ((buffer[1]>>0 |buffer[2]<<8)     			  & 0x07FF);
		_channels[1]  = ((buffer[2]>>3 |buffer[3]<<5)                 & 0x07FF);
		_channels[2]  = ((buffer[3]>>6 |buffer[4]<<2 |buffer[5]<<10)  & 0x07FF);
		_channels[3]  = ((buffer[5]>>1 |buffer[6]<<7)                 & 0x07FF);
		_channels[4]  = ((buffer[6]>>4 |buffer[7]<<4)                 & 0x07FF);
		_channels[5]  = ((buffer[7]>>7 |buffer[8]<<1 |buffer[9]<<9)   & 0x07FF);
		_channels[6]  = ((buffer[9]>>2 |buffer[10]<<6)                & 0x07FF);
		_channels[7]  = ((buffer[10]>>5|buffer[11]<<3)                & 0x07FF);
		_channels[8]  = ((buffer[12]   |buffer[13]<<8)                & 0x07FF);
		_channels[9]  = ((buffer[13]>>3|buffer[14]<<5)                & 0x07FF);
		_channels[10] = ((buffer[14]>>6|buffer[15]<<2|buffer[16]<<10) & 0x07FF);
		_channels[11] = ((buffer[16]>>1|buffer[17]<<7)                & 0x07FF);
		_channels[12] = ((buffer[17]>>4|buffer[18]<<4)                & 0x07FF);
		_channels[13] = ((buffer[18]>>7|buffer[19]<<1|buffer[20]<<9)  & 0x07FF);
		_channels[14] = ((buffer[20]>>2|buffer[21]<<6)                & 0x07FF);
		_channels[15] = ((buffer[21]>>5|buffer[22]<<3)                & 0x07FF);
	}
	else
	{
		return;
	}
	//�����ж�
	if((_channels[0] == 1001 || _channels[0] == 1000) && (_channels[1] == 1001 || _channels[1] == 1000) && (_channels[2] == 41 || _channels[2] == 40) && (_channels[3] == 1001 || _channels[3] == 1000))
	{
		memset(Mc6c.DeCH,0,sizeof(Mc6c.DeCH));
		memset(Mc6c.NoCH,0,sizeof(Mc6c.NoCH));
		memset(_channels,0,sizeof(_channels));
		Mc6c.DisconFlag = 1;
		Mc6c.LockFlag = 0;
		i = 0;
		Deal_SbusData();//�������һ�Σ���ȷ���ٶ�����
		return;
	}
	else
	{
		Mc6c.DisconFlag = 0;
	}
	//ȡĬ��ֵ
	if(i < 10)
	{
		Mc6c.DeCH[0] += (float)(_channels[0]/10.0);
		Mc6c.DeCH[1] += (float)(_channels[1]/10.0);
		Mc6c.DeCH[2] += (float)(_channels[2]/10.0);
		Mc6c.DeCH[3] += (float)(_channels[3]/10.0);
		i++;
		return;
	}
	//�����ж�
	if(Mc6c.LockFlag == 0 || Mc6c.LockFlag == 1)
	{
		if(_channels[2] > 1500)
		{
			Mc6c.LockFlag = 1;
		}
		else if(_channels[2] < 500 && Mc6c.LockFlag == 1)
		{
			Mc6c.LockFlag =2;
			//BeefON(2,300);
		}
	}
	
	//��������������
	if(Mc6c.LockFlag == 2 && Mc6c.DisconFlag == 0)
	{
		if	   (_channels[0] > Mc6c.DeCH[0] + ERRORVAUE) {Mc6c.NoCH[0] = _channels[0] - Mc6c.DeCH[0]-ERRORVAUE;}
		else if(_channels[0] < Mc6c.DeCH[0] - ERRORVAUE) {Mc6c.NoCH[0] = _channels[0] - Mc6c.DeCH[0]+ERRORVAUE;}
		else
		{
			Mc6c.NoCH[0] = 0;
		}
		
		if	   (_channels[1] > Mc6c.DeCH[1] + ERRORVAUE) {Mc6c.NoCH[1] = _channels[1] - Mc6c.DeCH[1]-ERRORVAUE;}
		else if(_channels[1] < Mc6c.DeCH[1] - ERRORVAUE) {Mc6c.NoCH[1] = _channels[1] - Mc6c.DeCH[1]+ERRORVAUE;}
		else
		{
			Mc6c.NoCH[1] = 0;
		}
			
		if	   (_channels[2] > Mc6c.DeCH[2] + ERRORVAUE) {Mc6c.NoCH[2] = _channels[2] - Mc6c.DeCH[2]-ERRORVAUE;}
		else if(_channels[2] < Mc6c.DeCH[2] - ERRORVAUE) {Mc6c.NoCH[2] = _channels[2] - Mc6c.DeCH[2]+ERRORVAUE;}
		else
		{
			Mc6c.NoCH[2] = 0;
		}
			
		if	   (_channels[3] > Mc6c.DeCH[3] + ERRORVAUE) {Mc6c.NoCH[3] = _channels[3] - Mc6c.DeCH[3]-ERRORVAUE;}
		else if(_channels[3] < Mc6c.DeCH[3] - ERRORVAUE) {Mc6c.NoCH[3] = _channels[3] - Mc6c.DeCH[3]+ERRORVAUE;}
		else
		{
			Mc6c.NoCH[3] = 0;
		}
		
		if(_channels[4] < 300)
		{
			Mc6c.LeftKey = 0;
		}
		else if(_channels[4] < 1100)
		{
			Mc6c.LeftKey = 1;
		}
		else if(_channels[4] > 1700)
		{
			Mc6c.LeftKey = 2;
		}
		
		if(_channels[5] < 300)
		{
			Mc6c.RightKey = 0;
		}
		else if(_channels[5] > 1700)
		{
			Mc6c.RightKey = 1;
		}
	}
	else
	{
		return;
	}
	Deal_SbusData();
	
}
void Deal_SbusData(void)
{
	Mc6c.LeftX  = Mc6c.NoCH[3];
	Mc6c.LeftY  = Mc6c.NoCH[1];
	Mc6c.RightX = Mc6c.NoCH[0];
	Mc6c.RightY = _channels[2];
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
			ң�������ݴ������������ÿ������ȷһ�����ݽ�һ��
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/	
}






