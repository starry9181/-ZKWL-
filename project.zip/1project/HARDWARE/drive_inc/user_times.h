#ifndef _USER_TIMES_H
#define _USER_TIMES_H

#include "sys.h"

#define EncoderPeriod 0xffff
#define   TIM8_PERIOD   36000

void Tim8_Init(uint16_t ARR,uint16_t PSC);
void TIM_ALL(void);











#endif

