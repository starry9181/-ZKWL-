#ifndef _CONTROL_H
#define _CONTROL_H
#include "sys.h"














#endif

