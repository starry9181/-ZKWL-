#ifndef _GPIO_OUPUT_H
#define _GPIO_OUPUT_H
#include "sys.h"

#define BEEF  PAout(8)



void all_gpio_ouput_init(void);





#endif


