#ifndef _IWDG_H
#define _IWDG_H
#include "sys.h"

void IWDG_init( void );

void IWDG_FEED(void);


#endif

