#ifndef _GPIO_INPUT_H
#define _GPIO_INPUT_H
#include "sys.h"


void all_gpio_input_init(void);





#endif





