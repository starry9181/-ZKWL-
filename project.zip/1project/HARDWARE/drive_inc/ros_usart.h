#ifndef _ROS_USART_H
#define _ROS_USART_H
#include "sys.h"
#include "FreeRTOS.h"
#include "semphr.h"
#include "task.h"
#define USART1_DEBUG  0
#define USART1_HANDLER 1
#define USART1_REMAP 1

#define USART2_DEBUG  0
#define USART2_HANDLER 1

#define USART3_DEBUG  0
#define USART3_HANDLER 1

#define USART4_DEBUG  1
#define USART4_HANDLER 1

#define USART5_DEBUG   0
#define USART5_HANDLER 1


#define MAX_RX_CNT 100
#define EXCNT1 5	//��ά���鳤��1
#define EXCNT2 30	//��ά���鳤��2
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
extern u8 USART1_Rx_Buff[MAX_RX_CNT];
extern u8 USART2_Rx_Buff[MAX_RX_CNT];
extern u8 USART3_Rx_Buff[MAX_RX_CNT];
extern u8 UART4_Rx_Buff[MAX_RX_CNT];
extern u8 UART5_Rx_Buff[MAX_RX_CNT];
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
void USART1_Config(uint32_t BaudRate);
void USART2_Config(uint32_t BaudRate);
void USART3_Config(uint32_t BaudRate);
void UART4_Config(uint32_t BaudRate);
void UART5_Config(uint32_t BaudRate);

void u1_printf(const char *format,...);
void u2_printf(const char *format,...);
void u3_printf(const char *format,...);
void u4_printf(const char *format,...);
void u5_printf(const char *format, ...);

extern SemaphoreHandle_t CountSemaphore4; //�������ź���
extern SemaphoreHandle_t CountSemaphore5; //�������ź���
extern SemaphoreHandle_t CountSemaphore3; //�������ź���
extern SemaphoreHandle_t CountSemaphore2; //�������ź���
extern u16 	g_UART5_RecPos;//��ŵ�ǰ���ڽ������ݴ�ŵ�λ��


uint8_t UART4_DMA_TX(const uint8_t *TxBuff, uint8_t Byte_Cnt);
uint8_t UART5_DMA_TX(const uint8_t *TxBuff, uint8_t Byte_Cnt);
uint8_t USART3_DMA_TX(const uint8_t *TxBuff, uint8_t Byte_Cnt);
uint8_t USART2_DMA_TX(const uint8_t *TxBuff, uint8_t Byte_Cnt);
uint8_t USART1_DMA_TX(const uint8_t *TxBuff, uint8_t Byte_Cnt);


void all_usart_init(void);
















#endif
