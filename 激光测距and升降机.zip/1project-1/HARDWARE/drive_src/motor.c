#include "motor.h"
#include "gpio_ouput.h"
void Motor_Control_rise_down(u8 mode)
{
	switch(mode){
		case 00: MOTOR_RISE = RISE_DOWN_FALUT ; MOTOR_DOWN = RISE_DOWN_FALUT;break;  //ֹͣ
		case 01: MOTOR_RISE = RISE_DOWN_TRUE ;  MOTOR_DOWN = RISE_DOWN_FALUT;break;  //����
		case 02: MOTOR_RISE = RISE_DOWN_FALUT ; MOTOR_DOWN = RISE_DOWN_TRUE;break;   //�½�
		default:break;
	
	}

}


