#include "laser_distance.h"
#include "ros_usart.h"
/*
�������ܣ����ܼ�����ģ�鷴�������ݲ�����
data����������
laser_dis�����ṹ��
return :  -1   У��ʧ��
					1    �ɹ�
*/
Laser_Distance Laser_Dis;
	u8 Data[11];
	

int Laser_Distance_data_deal(u8 *data,Laser_Distance *laser_dis){

	u16 i=0;
	u8 check=0;
	u8 check_f;
	u8 check_check;
	u8 data_len;
	data_len=sizeof(Data);
	for(i=0;i<data_len;i++) {
		Data[i] = data[i];
		if(i<data_len-1){
			check+=Data[i]; 
		}
	}
	check_f=((~check)+1)&0xff;    
	check_check = check_f;
	//У��
	if(Data[0] ==LASER_DEVICE_ADDR && Data[1]==LASER_CHECK_1 && Data[2]==LASER_CHECK_2&& Data[10]==check_check ) //&& Data[10]==check_check
	{
		laser_dis->data[0] = Data[3];   //100000mm
		laser_dis->data[1] = Data[4];   //10000mm
		laser_dis->data[2] = Data[5];   //1000mm
		
		laser_dis->data[3] = Data[7];   //100mm
		laser_dis->data[4] = Data[8];   //10mm
		laser_dis->data[5] = Data[9];   //1mm
	}
	else
	{
		return -1;  //У��ʧ��
		
	}
  for(i=0;i<6;i++){
		laser_dis->data_deal[i] = (laser_dis->data[i]-0x30)&0xff;
	}
	//���ռ���õ��ľ���   ��λ:  mm
	laser_dis->distance = (laser_dis->data_deal[0]*100000)+(laser_dis->data_deal[1]*10000)+(laser_dis->data_deal[2]*1000)+(laser_dis->data_deal[3]*100)+(laser_dis->data_deal[4]*10)+(laser_dis->data_deal[5]*1);
  if(laser_dis->distance>3000) laser_dis->distance=0;
	return 1;    //�ɹ���ȡ
	

}






void open_laser_dis(void)
{
	u8 i=0;
// 
//	u8 data_one[4]={0x80,0x06,0x02,0x78};   //���μ��
	u8 data_more[4]={0x80,0x06,0x03,0x77};//��μ��
	
	//���õ�ַ
	u8 data_set_add[5] = {0xfa,0x04,0x01,0x80,0x81};
	//��������
	u8 data_set_dis[5] = {0xfa,0x04,0x09,0x05,0xf4} ; //5m
	                      /*
												0xfa,0x04,0x09,0x0a,0xef    //10m
												0xfa,0x04,0x09,0x1e,0xdb    //30m
												0xfa,0x04,0x09,0x32,0xc7    //50m
												0xfa,0x04,0x09,0x50,0xa9    //80m
	                      */
	               
	//����Ƶ��
	u8 data_set_hz[5] = {0xfa,0x04,0x0a,0x05,0xf3};   
	                     /*
												0xfa,0x04,0x0a,0x00,0xf8    //3Hz
												0xfa,0x04,0x0a,0x05,0xf3    //5
												0xfa,0x04,0x0a,0x0a,0xee    //10
												0xfa,0x04,0x0a,0x14,0xe4    //20
												*/
	//���÷ֱ���
	u8 data_set_resolution_ratio[5] = {0xfa,0x04,0x0c,0x01,0xf5};//1mm
	//�ϵ�Ͳ�
	u8 data_set_open[5] = {0xfa,0x04,0x0d,0x01,0xf4};
	
//	USART3_DMA_TX(data_set_hz,5);
	//for(i=0;i<20;i++)
	
//	USART3_DMA_TX(data_set_add,5);
//	for(i=0;i<200;i++){ ;  }
//	USART3_DMA_TX(data_set_dis,5);
//	for(i=0;i<200;i++){ ;  }
//	USART3_DMA_TX(data_set_hz,5);
//	for(i=0;i<200;i++){ ;  }
//	USART3_DMA_TX(data_set_resolution_ratio,5);
//	for(i=0;i<200;i++){ ; }
//	USART3_DMA_TX(data_set_open,5);
//	for(i=0;i<200;i++){;}
	USART3_DMA_TX(data_more,4);
	
	
	if(0){
	USART3_DMA_TX(data_set_add,5);
	USART3_DMA_TX(data_set_dis,5);
	USART3_DMA_TX(data_set_hz,5);
	USART3_DMA_TX(data_set_resolution_ratio,5);
	USART3_DMA_TX(data_set_open,5);
	}

}









