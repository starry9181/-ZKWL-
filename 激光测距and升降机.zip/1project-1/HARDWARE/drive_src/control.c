#include "control.h"
#include "FreeRTOS.h"
#include "task.h"
#include "error.h"
#include "motor.h"
//void TIM6_IRQHandler(void)
//{
//	taskENTER_CRITICAL();           //
//	if(TIM_GetITStatus(TIM6, TIM_IT_Update) != RESET)
//	{
////		GET_ENCODER();
////		SpeedControl_2();
//	}
//	TIM_ClearITPendingBit(TIM6,TIM_IT_Update);//��������жϱ�־λ
//	taskEXIT_CRITICAL();            //
//}
 
void set_pwm_direction(s16 pwm)
{
	if (pwm > 0)
	{
		if (pwm < STOPPWM)
		{
			pwm = STOPPWM;
		}
		else
		{
			DERCTION = 1;
		}
	}
	else if (pwm < 0)
	{
		if (pwm > -STOPPWM)
		{
			pwm = -STOPPWM;
		}
		else
		{
			DERCTION = 0;
		}
		pwm = -pwm;
	}
	DERCTION_PWM = pwm;
}

/*
flag: ����ͨ�ű�־  ֻ����λ������ָ���ſ��Կ���
get : ����ֵ
dis : Ŀ��ֵ
*/

#define pid_pos_limit   10
#include "ros_data_deal.h"
void pos_control(u8 flag,int get,int dis)
{
	
	
	if(flag==1 &&error_detec.laser_error==0)  //ͨ������&&������ģ��ͨ������
	{
		current_calc_pid(&pos_pid,get, dis);

//		if (pos_pid.pos_out >= 5)
//		{pos_pid.pos_out = 1200;Motor_Control_rise_down(MOTOR_MODE_RISE);}
//		else if (pos_pid.pos_out < 5 && pos_pid.pos_out > -5)
//		{pos_pid.pos_out = 0;  Motor_Control_rise_down(MOTOR_MODE_STOP);  }
//		else if (pos_pid.pos_out <= -5)
//		{pos_pid.pos_out = -1200; Motor_Control_rise_down(MOTOR_MODE_DOWN); }

		if (pos_pid.pos_out >= pid_pos_limit)
		{pos_pid.pos_out = 1000;Motor_Control_rise_down(MOTOR_MODE_RISE);}
		
		else if (pos_pid.pos_out < pid_pos_limit && pos_pid.pos_out > -pid_pos_limit)
		{pos_pid.pos_out = 0;  Motor_Control_rise_down(MOTOR_MODE_STOP);hight_flag.connect_flag=0;  //Ŀ�ĵص���󣬵�����������ر�
			Ros_SEND_data(0x83,&usart_send_2);  //Ŀ�ĵص��������Ϣ
		}
		
		else if (pos_pid.pos_out <= -pid_pos_limit)
		{pos_pid.pos_out = -1000; Motor_Control_rise_down(MOTOR_MODE_DOWN); }
		
		
		//set_pwm_direction(pos_pid.pos_out);
   }
	 else { 
		Motor_Control_rise_down(MOTOR_MODE_STOP); 
	  pid_clear();  //��� PID ����
	 }
}







