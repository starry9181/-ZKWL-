#ifndef _BUFFER_H
#define _BUFFER_H
#include "sys.h"

void BeefON(u8 cnt,u16 time);
void BeefTOON(void);









#endif




