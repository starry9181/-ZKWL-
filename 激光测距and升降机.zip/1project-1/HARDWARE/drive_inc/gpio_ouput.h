#ifndef _GPIO_OUPUT_H
#define _GPIO_OUPUT_H
#include "sys.h"

#define BEEF  PAout(8)

#define GPIO_PIN_RISE               GPIO_Pin_12
#define GPIO_X_RISE                 GPIOB
#define RCC_APBXPeriph_GPIOX_RISE   RCC_APB2Periph_GPIOB


#define GPIO_PIN_DOWN              GPIO_Pin_13
#define GPIO_X_DOWN                GPIOB
#define RCC_APBXPeriph_GPIOX_DOWN   RCC_APB2Periph_GPIOB

#define MOTOR_RISE                 PBout(12)
#define MOTOR_DOWN                 PBout(13)

#define MOTOR_RISE_READ            PBin(12)
#define MOTOR_DOWN_READ            PBin(13)

#define RISE_DOWN_TRUE    0
#define RISE_DOWN_FALUT    1



void all_gpio_ouput_init(void);





#endif


