#ifndef _ENCODER_H
#define _ENCODER_H
#include "sys.h"
#include "user_times.h"
#define prd     EncoderPeriod
#define Vbreak  EncoderPeriod/2
typedef struct
{
	s16 V;    //����������
	s16 cnt;  //
	s16 rcnt;
	s32 CNT;  //����
}EncoderType;

	extern	EncoderType GetEncoder1;
	extern	EncoderType GetEncoder2;
	extern	EncoderType GetEncoder3;
	extern	EncoderType GetEncoder4;

void all_getencoder(void);





#endif
