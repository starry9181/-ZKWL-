#ifndef _CONTROL_H
#define _CONTROL_H
#include "sys.h"
#include "pid_motor.h"

#define STOPPWM 10
#define DERCTION_PWM TIM8->CCR1
#define DERCTION PCout(14) //����



void pos_control(u8 flag,int get,int dis);





#endif

