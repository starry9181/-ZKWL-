#ifndef _ROS_DATA_DEAL_H
#define _ROS_DATA_DEAL_H
#include "sys.h"

#define ROS_HEAD   0xDEED
#define ROS_TYPE   0X06
//������λ��������
extern union ROS_RECEVICE_DATA{
	u8 data[10];
	struct {
		u16 head; //0xdeed
		u8 len;   //0x0a
		u8 type;  //0x06 
		u8 cmd; //0x00 ��ѯӲ������    0x01 ��ѯ�߶�   0x02 �߶�����  
		u8 num; //0x01
		u16 data;
		u16 check;
	}port;

}ROS_RECEVICE_Data;

typedef struct UsartX_SEND{
	u8 (*usartx_send)(const u8 *txbuff,u8 len);

}Usart_Send_X;

extern Usart_Send_X usart_send_2;

struct Hight_and_flag{
	int dis;
	u8 connect_flag;

};
extern struct Hight_and_flag hight_flag;

/***********************************************************/


//��������λ���ϴ�����



typedef struct ROS_TX_DATA{
	union{
			struct {
				u16 head; //0xdeed
				u8 len;   //0x10
				u8 type;  //0x06 
				u8 cmd; //0x80 ��ѯӲ������    
				u8 num; //0x04
				u16 data[4];
				u16 check;
	    }port;
	    u8 data[16];	
	}ros_80;
	union{
			struct {
				u16 head; //0xdeed
				u8 len;   //0x10
				u8 type;  //0x06 
				u8 cmd; //0x80 ��ѯ�߶�    
				u8 num; //0x01
				u16 data;
				u16 check;
	    }port;
	    u8 data[10];	
	}ros_81;
	union{
			struct {
				u16 head; //0xdeed
				u8 len;   //0x10
				u8 type;  //0x06 
				u8 cmd; //0x80 �߶����������   
				u8 num; //0x01
				u16 data;
				u16 check;
	    }port;
	    u8 data[10];	
	}ros_82;
	union{
			struct {
				u16 head; //0xdeed
				u8 len;   //0x10
				u8 type;  //0x06 
				u8 cmd; //0x80 �߶����������   
				u8 num; //0x01
				u16 data;
				u16 check;
	    }port;
	    u8 data[10];	
	}ros_83;
	union{
			struct {
				u16 head; //0xdeed
				u8 len;   //0x10
				u8 type;  //0x06 
				u8 cmd; //0x80 ������ 
				u8 num; //0x01
				u16 data;
				u16 check;
	    }port;
	    u8 data[10];	
	}ros_84;
	
}ROS_TX_Data;




void Ros_SEND_data(u8 flag,Usart_Send_X *usartx_send);
int recevice_data_deal(u8 *data);

#endif
