#ifndef _MOTOR_H
#define _MOTOR_H
#include "sys.h"

#define HIGHT_LIMIT   3000   //�߶�����   1000mm

#define MOTOR_MODE_STOP   0
#define MOTOR_MODE_RISE   1
#define MOTOR_MODE_DOWN   2










void Motor_Control_rise_down(u8 mode);







#endif
