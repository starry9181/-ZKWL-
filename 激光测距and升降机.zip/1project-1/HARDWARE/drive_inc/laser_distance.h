#ifndef _LASER_DISTANCE_H
#define _LASER_DISTANCE_H
#include "sys.h"

#define LASER_DEVICE_ADDR    0X80
#define LASER_CHECK_1        0X06
#define LASER_CHECK_2        0X83

typedef struct LASER_DISTANCE{

	u8 data[6];
	u8 data_deal[6];
	int distance;   //mm 
}Laser_Distance;

extern Laser_Distance Laser_Dis;
int Laser_Distance_data_deal(u8 *data,Laser_Distance *laser_dis);
void open_laser_dis(void);

















#endif

