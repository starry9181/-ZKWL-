#ifndef _CAN_H
#define _CAN_H
#include "sys.h"

u8 CAN_Mode_Init(u8 tsjw,u8 tbs2,u8 tbs1,u16 brp,u8 mode);











#endif

