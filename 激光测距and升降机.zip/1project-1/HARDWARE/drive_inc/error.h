#ifndef _ERROR_H
#define _ERROR_H
#include "sys.h"

typedef struct ERROR_DETECTION{
	u8 motor_error;
	u8 laser_error;
	
	u8 laser_lost_connect;  //������ģ�����
	u8 ros_t_lost;   //ͨ�ŵ���

	u8 all_error;
}Error_Detection;
extern Error_Detection error_detec;
//�˲�
typedef struct
{
    uint32_t max_cnt;
    uint32_t now_cnt;
    uint8_t last_flag;
    uint8_t return_flag;
}Flag_Filter_Type;
extern Flag_Filter_Type flag_filter;




void error_init(void);
void error_collect(u8 IO_STATE);

uint8_t Flag_Filter(Flag_Filter_Type * filter , uint8_t flag , uint32_t filter_cnt);




#endif


