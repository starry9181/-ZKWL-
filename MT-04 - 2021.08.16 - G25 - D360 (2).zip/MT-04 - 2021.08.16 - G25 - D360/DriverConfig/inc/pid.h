#ifndef __PID_H
#define __PID_H

/*====================================================================================================
    PID Function
    
    The PID (���������֡�΢��) function is used in mainly
    control applications. PIDCalc performs one iteration of the PID
    algorithm.

    While the PID function works, main is just a dummy program showing
    a typical usage.
=====================================================================================================*/
#include "TaskManage.h"

enum pid_two_way_mode{two_way = 0 , one_way = !two_way};


typedef struct 
{
    float target;
    float actual;

    float kp;     //����ϵ��
    float ki;     //����ϵ��
    float kd;     //΢��ϵ��

    float errNow; 
    float dCtrOut;//�����������
    float ctrOut;//�������
    float errILim;
    float dErrP;
    float dErrI;
    float dErrD;
    float output_max;

    float errOld1;
    float errOld2;

}PID_Type;



typedef struct pid{
    int16_t SetPoint;  //�趨Ŀ��
    float Kp,Ki,Kd;       //����������
//    int32_t Kp,Ki,Kd;       //����������
    int16_t SumError;  //�ۻ����  
    int16_t LastError;
}PidStruct;




extern PidStruct frontLeftWheelPid;
extern PidStruct frontRightWheelPid;
extern PidStruct behindLeftWheelPid;
extern PidStruct behindRightWheelPid;


void vPidStructInit( void );
void vWheelPidStructInit( PidStruct *pid, int32_t SetSpeed );
void vSetSpeed( PidStruct *pid, int16_t SetSpeed );
void vAllPidInit( void );
void turnLeftRightPidAdjust( float setPoint, float realPoint );
int16_t sPidAdjust( PidStruct *pid, int32_t RealPoint );
float fFanPidAdjust( PidStruct *pid, float NextPoint );
void vWheelSpeedAdjust( void );
void UpDownSpeed( void );
void vSetPidStruct( void *pid, float Kp, float Ki, float Kd );
void PID_IncrementMode(PID_Type* PID , uint8_t mode);
void Set_BL_PID(float kp , float ki , float kd , float errILimit , float output_limit);
void Set_BR_PID(float kp , float ki , float kd , float errILimit , float output_limit);


#endif
