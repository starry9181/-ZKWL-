#ifndef __TIMERENCODE_H
#define __TIMERENCODE_H
#include "TaskManage.h"

typedef struct{
    int32_t frontLeftEncode;
    uint16_t frontLeftEncodeOld;
    uint16_t frontLeftEncodeNew;
    
    int32_t frontRightEncode;
    uint16_t frontRightEncodeOld;
    uint16_t frontRightEncodeNew;
    
    int32_t behindLeftEncode;
    uint16_t behindLeftEncodeOld;
    uint16_t behindLeftEncodeNew;
    
    int32_t behindRightEncode;
    uint16_t behindRightEncodeOld;
    uint16_t behindRightEncodeNew;
    
    bool frontLeftUpdateFlag;
    bool frontRightUpdateFlag;
    bool behindLeftUpdateFlag;
    bool behindRightUpdateFlag;
   
}Encode;


extern Encode TimerEmcode;

void Timer1EncoderInitialize( void );
void Timer2EncoderInitialize( void );
void Timer3EncoderInitialize( void );
void Timer4EncoderInitialize( void );

#endif
