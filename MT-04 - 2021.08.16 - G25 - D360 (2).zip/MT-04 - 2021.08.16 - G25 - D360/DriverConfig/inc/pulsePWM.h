#ifndef __PULSEPWM_H
#define __PULSEPWM_H

#include "TaskManage.h"


void TIM4_Master__TIM3_Slave_Configuration(u32 PulseFrequency);
void Pulse_output(u32 Cycle,u32 PulseNum);

#endif
