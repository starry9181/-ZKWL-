#ifndef __FLASH__
#define __FLASH__

#include "TaskManage.h"



//#define SELECT_BOARD_ADDRESS      (uint32_t)0x08019000  //�洢���԰�ѡ��ģʽ
#define ALL_TEST_BOARD_NUMBER     (uint32_t)0x08019000  //���в��԰�����
#define TEST_DATA_ADDRESS         (uint32_t)0x08019800  //����������ʼ��ַ

#define STM32_FLASH_BASE_ADDRESS  (uint32_t)0x08000000  //STM32 Flash ��ʼ��ַ
#define STM32_FLASH_SIZE          256*1024              //STM32 Flash��С
#define STM32_FLASH_PAGE_SIZE     2*1024                //STM32 Flash ҳ��С



typedef enum {FLASH_UNDONE = 0, FLASH_DONE = !FLASH_UNDONE}FlashWriteState;



extern uint16_t flashdata; //�û�����

void PowerUpGetFlashData( void );
uint32_t ReadProgramWordFromFlash(uint32_t address);
uint8_t ReadProgramOptionByteDataFromSTM32Flash( uint32_t address );
uint16_t ReadProgramHalfWordDataFromSTM32Flash( uint32_t address );
uint32_t ReadProgramWordDataFromSTM32Flash( uint32_t address );
uint32_t FindTestDataAddress( uint32_t Address );
void WriteProgramWordDataToSTM32Flash( uint32_t address, uint32_t data );
void WriteSelectBoardDataToSTM32Flash( uint32_t address );
void WriteTestDataToSTM32Flash( uint32_t address );


#endif
