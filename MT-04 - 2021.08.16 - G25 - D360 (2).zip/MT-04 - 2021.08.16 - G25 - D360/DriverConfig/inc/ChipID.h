#ifndef __CHIPID_H
#define __CHIPID_H
#include "TaskManage.h"

/****************оƬID�Ĵ�����ַ***********/
#define CHIPIDHIGHBYTEREGISTERADDRESS     (uint32_t)0X1FFFF7F0
#define CHIPIDMEDIUMBYTEREGISTERADDRESS   (uint32_t)0X1FFFF7EC
#define CHIPIDLOWBYTEREGISTERADDRESS      (uint32_t)0X1FFFF7E8

/*****************�洢оƬID��Flash��ַ**************/
#define FLASHPAGESIZE           1024
#define ENCRYPTFLAGADDRESSA     (uint32_t)(0x0801E000) //��120K Byte
#define ENCRYPTFLAGADDRESSB     (uint32_t)(0x0801E000+(4*FLASHPAGESIZE))

#define CHIPIDHIGHBYTEADDRESS   (uint32_t)(0x0801E000+FLASHPAGESIZE)    
#define CHIPIDMEDIUMBYTEADDRESS (uint32_t)(0x0801E000+(2*FLASHPAGESIZE))
#define CHIpIDLOWBYTEADDRESS    (uint32_t)(0x0801E000+(3*FLASHPAGESIZE))

void GetChipID(uint32_t ChipUniqueID[ ]);
uint32_t GetChipProgramWord(uint32_t registeraddress);
void WriteProgramWordtoFlash(uint32_t address, uint32_t data);


void ChipEncryptionFunction(void);

#endif
