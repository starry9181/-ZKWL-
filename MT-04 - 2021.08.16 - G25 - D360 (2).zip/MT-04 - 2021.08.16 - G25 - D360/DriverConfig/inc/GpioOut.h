#ifndef __IOOUT_H
#define __IOOUT_H

#include "TaskManage.h"


/************************Front left wheel*************************************************/
//#define FrontLeftForwardRetreatPort               GPIOB
//#define FrontLeftForwardRetreatPin                GPIO_Pin_12
//#define outFrontLeftForward(  )                   GPIO_SetBits( FrontLeftForwardRetreatPort, FrontLeftForwardRetreatPin )
//#define outFrontLeftRetreat(  )                   GPIO_ResetBits( FrontLeftForwardRetreatPort, FrontLeftForwardRetreatPin )
//#define outFrontLeftForwardRetreatBlink(  )       FrontLeftForwardRetreatPort->ODR ^= FrontLeftForwardRetreatPin
//#define outFrontLeftForwardRetreatState(  )       GPIO_ReadOutputDataBit( FrontLeftForwardRetreatPort, FrontLeftForwardRetreatPin )

//#define FrontLeftEnablePort                       GPIOD
//#define FrontLeftEnablePin                        GPIO_Pin_2
//#define outFrontLeftEnable(  )                    GPIO_SetBits( FrontLeftEnablePort, FrontLeftEnablePin )
//#define outFrontLeftDisable(  )                   GPIO_ResetBits( FrontLeftEnablePort, FrontLeftEnablePin )
//#define outFrontLeftEnableBlink(  )               FrontLeftEnablePort->ODR ^= FrontLeftEnablePin
//#define outFrontLeftEnableState(  )               GPIO_ReadOutputDataBit( FrontLeftEnablePort, FrontLeftEnablePin )

//#define FrontLeftBreakPort                        GPIOB
//#define FrontLeftBreakPin                         GPIO_Pin_5
//#define outFrontLeftBreak(  )                     GPIO_SetBits( FrontLeftBreakPort, FrontLeftBreakPin )
//#define outFrontLeftBreakOut(  )                  GPIO_ResetBits( FrontLeftBreakPort, FrontLeftBreakPin )
//#define outFrontLeftBreakBlink(  )                FrontLeftBreakPort->ODR ^= FrontLeftBreakPin
//#define outFrontLeftBreakState(  )                GPIO_ReadOutputDataBit( FrontLeftBreakPort, FrontLeftBreakPin )

//#define outFrontLeftWheelForward(  )              outFrontLeftForward(  );outFrontLeftDisable(  );outFrontLeftBreakOut(  )
//#define outFrontLeftWheelRetreat(  )              outFrontLeftRetreat(  );outFrontLeftDisable(  );outFrontLeftBreakOut(  )
//#define outFrontLeftWheelStop(  )                 outFrontLeftEnable(  );outFrontLeftBreak(  );SetFrontLeftMotorDriverDuty( DutyValue )


/************************Front right wheel*************************************************/
#define FrontRightForwardRetreatPort               GPIOC
#define FrontRightForwardRetreatPin                GPIO_Pin_12
#define outFrontRightForward(  )                   GPIO_ResetBits( FrontRightForwardRetreatPort, FrontRightForwardRetreatPin )
#define outFrontRightRetreat(  )                   GPIO_SetBits( FrontRightForwardRetreatPort, FrontRightForwardRetreatPin )
#define outFrontRightForwardRetreatBlink(  )       FrontRightForwardRetreatPort->ODR ^= FrontRightForwardRetreatPin
#define outFrontRightForwardRetreatState(  )       GPIO_ReadOutputDataBit( FrontRightForwardRetreatPort, FrontRightForwardRetreatPin )

#define FrontRightEnablePort                       GPIOD
#define FrontRightEnablePin                        GPIO_Pin_2
#define outFrontRightEnable(  )                    GPIO_SetBits( FrontRightEnablePort, FrontRightEnablePin )
#define outFrontRightDisable(  )                   GPIO_ResetBits( FrontRightEnablePort, FrontRightEnablePin )
#define outFrontRightEnableBlink(  )               FrontRightEnablePort->ODR ^= FrontRightEnablePin
#define outFrontRightEnableState(  )               GPIO_ReadOutputDataBit( FrontRightEnablePort, FrontRightEnablePin )

#define FrontRightBreakPort                        GPIOB
#define FrontRightBreakPin                         GPIO_Pin_5
#define outFrontRightBreak(  )                     GPIO_ResetBits( FrontRightBreakPort, FrontRightBreakPin )
#define outFrontRightBreakOut(  )                  GPIO_SetBits( FrontRightBreakPort, FrontRightBreakPin )
#define outFrontRightBreakBlink(  )                FrontRightBreakPort->ODR ^= FrontRightBreakPin
#define outFrontRightBreakState(  )                GPIO_ReadOutputDataBit( FrontRightBreakPort, FrontRightBreakPin )

#define outFrontRightWheelForward(  )              outFrontRightForward(  );outFrontRightDisable(  );outFrontRightBreakOut(  )
#define outFrontRightWheelRetreat(  )              outFrontRightRetreat(  );outFrontRightDisable(  );outFrontRightBreakOut(  )
#define outFrontRightWheelStop(  )                 outFrontRightEnable(  );outFrontRightBreak(  );SetFrontRightMotorDriverDuty( 0 )



/************************Behind left wheel*************************************************/
#define BehindLeftForwardRetreatPort               GPIOC
#define BehindLeftForwardRetreatPin                GPIO_Pin_4
#define outBehindLeftForward(  )                   GPIO_SetBits( BehindLeftForwardRetreatPort, BehindLeftForwardRetreatPin )
#define outBehindLeftRetreat(  )                   GPIO_ResetBits( BehindLeftForwardRetreatPort, BehindLeftForwardRetreatPin )
#define outBehindLeftForwardRetreatBlink(  )       BehindLeftForwardRetreatPort->ODR ^= BehindLeftForwardRetreatPin
#define outBehindLeftForwardRetreatState(  )       GPIO_ReadOutputDataBit( BehindLeftForwardRetreatPort, BehindLeftForwardRetreatPin )

#define BehindLeftEnablePort                       GPIOC
#define BehindLeftEnablePin                        GPIO_Pin_5
#define outBehindLeftEnable(  )                    GPIO_SetBits( BehindLeftEnablePort, BehindLeftEnablePin )
#define outBehindLeftDisable(  )                   GPIO_ResetBits( BehindLeftEnablePort, BehindLeftEnablePin )
#define outBehindLeftEnableBlink(  )               BehindLeftEnablePort->ODR ^= BehindLeftEnablePin
#define outBehindLeftEnableState(  )               GPIO_ReadOutputDataBit( BehindLeftEnablePort, BehindLeftEnablePin )

#define BehindLeftBreakPort                        GPIOB
#define BehindLeftBreakPin                         GPIO_Pin_0
#define outBehindLeftBreak(  )                     GPIO_ResetBits( BehindLeftBreakPort, BehindLeftBreakPin )
#define outBehindLeftBreakOut(  )                  GPIO_SetBits( BehindLeftBreakPort, BehindLeftBreakPin )
#define outBehindLeftBreakBlink(  )                BehindLeftBreakPort->ODR ^= BehindLeftBreakPin
#define outBehindLeftBreakState(  )                GPIO_ReadOutputDataBit( BehindLeftBreakPort, BehindLeftBreakPin )

#define outBehindLeftWheelForward(  )              outBehindLeftForward(  );outBehindLeftDisable(  );outBehindLeftBreakOut(  )
#define outBehindLeftWheelRetreat(  )              outBehindLeftRetreat(  );outBehindLeftDisable(  );outBehindLeftBreakOut(  )
#define outBehindLeftWheelStop(  )                 outBehindLeftEnable(  );outBehindLeftBreak(  );SetBehindLeftMotorDriverDuty( 0 ); behindLeftWheelPid.SetPoint = 0; MecanumChassisSetPoint.behindLeftWheelSpeed = 0


/************************Behind right wheel*************************************************/
#define BehindRightForwardRetreatPort               GPIOC
#define BehindRightForwardRetreatPin                GPIO_Pin_0
#define outBehindRightForward(  )                   GPIO_ResetBits( BehindRightForwardRetreatPort, BehindRightForwardRetreatPin )
#define outBehindRightRetreat(  )                   GPIO_SetBits( BehindRightForwardRetreatPort, BehindRightForwardRetreatPin )
#define outBehindRightForwardRetreatBlink(  )       BehindRightForwardRetreatPort->ODR ^= BehindRightForwardRetreatPin
#define outBehindRightForwardRetreatState(  )       GPIO_ReadOutputDataBit( BehindRightForwardRetreatPort, BehindRightForwardRetreatPin )

#define BehindRightEnablePort                       GPIOC
#define BehindRightEnablePin                        GPIO_Pin_1
#define outBehindRightEnable(  )                    GPIO_SetBits( BehindRightEnablePort, BehindRightEnablePin )
#define outBehindRightDisable(  )                   GPIO_ResetBits( BehindRightEnablePort, BehindRightEnablePin )
#define outBehindRightEnableBlink(  )               BehindRightEnablePort->ODR ^= BehindRightEnablePin
#define outBehindRightEnableState(  )               GPIO_ReadOutputDataBit( BehindRightEnablePort, BehindRightEnablePin )

#define BehindRightBreakPort                        GPIOC
#define BehindRightBreakPin                         GPIO_Pin_15
#define outBehindRightBreak(  )                     GPIO_ResetBits( BehindRightBreakPort, BehindRightBreakPin )
#define outBehindRightBreakOut(  )                  GPIO_SetBits( BehindRightBreakPort, BehindRightBreakPin )
#define outBehindRightBreakBlink(  )                BehindRightBreakPort->ODR ^= BehindRightBreakPin
#define outBehindRightBreakState(  )                GPIO_ReadOutputDataBit( BehindRightBreakPort, BehindRightBreakPin )

#define outBehindRightWheelForward(  )              outBehindRightForward(  );outBehindRightDisable(  );outBehindRightBreakOut(  )
#define outBehindRightWheelRetreat(  )              outBehindRightRetreat(  );outBehindRightDisable(  );outBehindRightBreakOut(  )
#define outBehindRightWheelStop(  )                 outBehindRightEnable(  );outBehindRightBreak(  );SetBehindRightMotorDriverDuty( 0 ); behindRightWheelPid.SetPoint = 0; MecanumChassisSetPoint.behindRightWheelSpeed = 0


#define BuzzerContrlPort                            GPIOA
#define BuzzerContrlPin                             GPIO_Pin_15
#define outBuzzerON(  )                             GPIO_SetBits( BuzzerContrlPort, BuzzerContrlPin )
#define outBuzzerOFF(  )                            GPIO_ResetBits( BuzzerContrlPort, BuzzerContrlPin )
#define outBuzzerBlink(  )                          BuzzerContrlPort->ODR ^= BuzzerContrlPin



void vAllIoOutputConfig( void );




#endif



