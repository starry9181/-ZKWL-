#ifndef __DRIVERRUN_H
#define __DRIVERRUN_H

#include "TaskManage.h"

void HardwareDriverInit( void );
void SystemHardwareWorkTask( void *Parammenters );

#endif
