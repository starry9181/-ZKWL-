#ifndef __SPI_H
#define __SPI_H
#include "TaskManage.h"


#define Dummy_Byte                0xFF


#define SPI_CLK                       RCC_APB2Periph_SPI1
#define SPI_GPIO_CLK                  RCC_APB2Periph_GPIOA
#define SPI_GPIO_PORT                 GPIOA                       /* GPIOA */
#define SPI_CE_PIN                    GPIO_Pin_4                  /* PC.04 */
#define SPI_SCK_PIN                   GPIO_Pin_5                  /* PA.05 */
#define SPI_MISO_PIN                  GPIO_Pin_6                  /* PA.06 */
#define SPI_MOSI_PIN                  GPIO_Pin_7                  /* PA.07 */


#define SPI_CE_LOW()       GPIO_ResetBits(SPI_GPIO_PORT, SPI_CE_PIN)
#define SPI_CE_HIGH()      GPIO_SetBits(SPI_GPIO_PORT, SPI_CE_PIN)



void STM32SPI_Init(void);
uint8_t SPI_ExchangeByte(uint8_t data);



#endif
