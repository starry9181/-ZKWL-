#ifndef __IWDG_H
#define __IWDG_H

#include "TaskManage.h"


void IWDG_DefaultConfiguration( void );
void IWDG_FeedDog( void );
void IWDG_Start( void );

#endif
