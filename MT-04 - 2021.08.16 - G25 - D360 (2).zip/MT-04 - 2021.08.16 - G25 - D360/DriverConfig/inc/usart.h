#ifndef __USART_H
#define __USART_H
	
#include "TaskManage.h"



#define  Debug //USART1���Կ���
//#define  DebugTest 
#define  USART1_RX

#define USE_USART2      1
#define USE_USART3      1
#define USE_UART4       1


//#define USE_USART3_INTERRUPT

typedef enum {USART_DMA_UNDONE = 0, USART_DMA_DONE = !USART_DMA_UNDONE} USART_DMAState;


#define  USART1_TRANSMIT_GROOVE_SIZE    10
#define  USART1_TRANSMIT_BUFFER_SIZE    128
#define  USART1_RECEIVE_GROOVE_SIZE     5
#define  USART1_RECEIVE_BUFFER_SIZE     30 

#define  USART2_TRANSMIT_GROOVE_SIZE    5
#define  USART2_TRANSMIT_BUFFER_SIZE    30
#define  USART2_RECEIVE_GROOVE_SIZE     5
#define  USART2_RECEIVE_BUFFER_SIZE     30

#define  USART3_TRANSMIT_GROOVE_SIZE    5
#define  USART3_TRANSMIT_BUFFER_SIZE    20
#define  USART3_RECEIVE_GROOVE_SIZE     5
#define  USART3_RECEIVE_BUFFER_SIZE     20

#define  UART4_TRANSMIT_GROOVE_SIZE    5
#define  UART4_TRANSMIT_BUFFER_SIZE    20
#define  UART4_RECEIVE_GROOVE_SIZE     5
#define  UART4_RECEIVE_BUFFER_SIZE     40

#define  UART5_TRANSMIT_GROOVE_SIZE    20
#define  UART5_TRANSMIT_BUFFER_SIZE    10
#define  UART5_RECEIVE_GROOVE_SIZE     20
#define  UART5_RECEIVE_BUFFER_SIZE     10

/******************************************����д�뻺�������*********************************************/
#define WriteDataToUSART1TraismitBufferDone(  ) USART1_TransmitWritingBytePointer = 0; \
        WtiteDataToUSART1TransmitGrooveIndex = ((WtiteDataToUSART1TransmitGrooveIndex+1) == USART1_TRANSMIT_GROOVE_SIZE) ? 0 :  (WtiteDataToUSART1TransmitGrooveIndex+1)

/*********************************************DMA���ʹ������*************************************************/
#define DMA1_Channel4TransmitDone(  )  \
        DMA1_Channel4TransmitGrooveIndex = ((DMA1_Channel4TransmitGrooveIndex+1) == USART1_TRANSMIT_GROOVE_SIZE) ? 0 :  (DMA1_Channel4TransmitGrooveIndex+1)
        
/*********************************************DMA���մ������*************************************************/
#define DMA1_Channel5ReceiveDone(  ) \
		DMA1_Channel5ReceiveGrooveIndex = ( (DMA1_Channel5ReceiveGrooveIndex+1) == USART1_RECEIVE_GROOVE_SIZE ) ? 0 : (DMA1_Channel5ReceiveGrooveIndex+1); \
        USART1_ReceiveMessageNumber++
/************************************************����������*************************************************/
#define USART1_ReceiveReadDataDone(  ) \
		USART1ReceiveReadIndex = ( (USART1ReceiveReadIndex+1) == USART1_RECEIVE_GROOVE_SIZE ) ? 0 : (USART1ReceiveReadIndex+1); \
        USART1_ReceiveMessageNumber--        
 

#define GetUSART1ReceiveNumber(  )  USART1_ReceiveMessageNumber

/******************************************����д�뻺�������*********************************************/        
#define WriteDataToUSART2TraismitBufferDone(  ) \
        WtiteDataToUSART2TransmitGrooveIndex = ((WtiteDataToUSART2TransmitGrooveIndex+1) == USART2_TRANSMIT_GROOVE_SIZE) ? 0 :  (WtiteDataToUSART2TransmitGrooveIndex+1)

/*********************************************DMA���ʹ������*************************************************/
#define DMA1_Channel7TransmitDone(  )  \
        DMA1_Channel7TransmitGrooveIndex = ((DMA1_Channel7TransmitGrooveIndex+1) == USART2_TRANSMIT_GROOVE_SIZE) ? 0 :  (DMA1_Channel7TransmitGrooveIndex+1)

/*********************************************DMA���մ������*************************************************/
#define DMA1_Channel6ReceiveDone(  ) \
		DMA1_Channel6ReceiveGrooveIndex = ( (DMA1_Channel6ReceiveGrooveIndex+1) == USART2_RECEIVE_GROOVE_SIZE ) ? 0 : (DMA1_Channel6ReceiveGrooveIndex+1); \
        USART2_ReceiveMessageNumber++
/************************************************����������*************************************************/
#define USART2_ReceiveReadDataDone(  ) \
		USART2ReceiveReadIndex = ( (USART2ReceiveReadIndex+1) == USART2_RECEIVE_GROOVE_SIZE ) ? 0 : (USART2ReceiveReadIndex+1); \
        USART2_ReceiveMessageNumber--

#define GetUSART2ReceiveNumber(  )  USART2_ReceiveMessageNumber






/*********************************************DMA���ʹ������*************************************************/
#define DMA1_Channel2TransmitDone(  )  \
        DMA1_Channel2TransmitGrooveIndex = ((DMA1_Channel2TransmitGrooveIndex+1) == USART3_TRANSMIT_GROOVE_SIZE) ? 0 :  (DMA1_Channel2TransmitGrooveIndex+1)
        
/******************************************����д�뻺�������*********************************************/        
#define WriteDataToUSART3TraismitBufferDone(  ) \
        WtiteDataToUSART3TransmitGrooveIndex = ((WtiteDataToUSART3TransmitGrooveIndex+1) == USART3_TRANSMIT_GROOVE_SIZE) ? 0 :  (WtiteDataToUSART3TransmitGrooveIndex+1)

/******************************************����������Ϣ���*********************************************/ 
#define DMA1_Channel3ReceiveDone(  ) \
        DMA1_Channel3ReceiveGrooveIndex = ( (DMA1_Channel3ReceiveGrooveIndex+1) == USART3_RECEIVE_GROOVE_SIZE)? 0 : (DMA1_Channel3ReceiveGrooveIndex+1); \
        USART3_ReceiveMessageNumber++
 
/******************************************��ȡ������Ϣ���*********************************************/  
#define USART3_ReceiveReadDataDone(  ) \
        USART3ReceiveReadIndex = ( (USART3ReceiveReadIndex+1) == USART3_RECEIVE_GROOVE_SIZE)? 0 : (USART3ReceiveReadIndex+1); \
        USART3_ReceiveMessageNumber--

#define GetUSART3ReceiveNumber(  )  USART3_ReceiveMessageNumber




/*********************************************DMA���ʹ������*************************************************/
#define DMA2_Channel5TransmitDone(  )  \
        DMA2_Channel5TransmitGrooveIndex = ((DMA2_Channel5TransmitGrooveIndex+1) == UART4_TRANSMIT_GROOVE_SIZE) ? 0 :  (DMA2_Channel5TransmitGrooveIndex+1)
        
/******************************************����д�뻺�������*********************************************/        
#define WriteDataToUART4TraismitBufferDone(  ) \
        WtiteDataToUART4TransmitGrooveIndex = ((WtiteDataToUART4TransmitGrooveIndex+1) == UART4_TRANSMIT_GROOVE_SIZE) ? 0 :  (WtiteDataToUART4TransmitGrooveIndex+1)

/******************************************����������Ϣ���*********************************************/ 
#define DMA2_Channel3ReceiveDone(  ) \
        DMA2_Channel3ReceiveGrooveIndex = ( (DMA2_Channel3ReceiveGrooveIndex+1) == UART4_RECEIVE_GROOVE_SIZE)? 0 : (DMA2_Channel3ReceiveGrooveIndex+1); \
        UART4_ReceiveMessageNumber++
 
/******************************************��ȡ������Ϣ���*********************************************/  
#define UART4_ReceiveReadDataDone(  ) \
        UART4ReceiveReadIndex = ( (UART4ReceiveReadIndex+1) == UART4_RECEIVE_GROOVE_SIZE)? 0 : (UART4ReceiveReadIndex+1); \
        UART4_ReceiveMessageNumber--

#define GetUART4ReceiveNumber(  )  UART4_ReceiveMessageNumber





/******************************************************�����ⲿ����**************************************************************/		

extern uint8_t USART1_ReceiveMessageNumber;
extern uint8_t USART2_ReceiveMessageNumber;
extern uint8_t USART3_ReceiveMessageNumber;
extern uint8_t UART4_ReceiveMessageNumber;

void  Usart1Init(uint32_t bound);
void  Usart2Init(uint32_t bound);
void  Usart3Init(uint32_t bound);
void  Uart4Init(uint32_t bound);
void  Usart1PrintfTask(void );
void  Usart2TransmitAndReceive( void );
void  Usart3TransmitAndReceive( void );
void  Uart4TransmitAndReceive( void );

void WriteDataToUSART1TrainsmitBuffer( uint8_t Buffer[], uint8_t BufferLength );
void WriteDataToUSART2TrainsmitBuffer(uint8_t Buffer[], uint8_t BufferLength);
void WriteDataToUSART3TrainsmitBuffer(uint8_t Buffer[], uint8_t BufferLength);
void WriteDataToUART4TrainsmitBuffer(uint8_t Buffer[], uint8_t BufferLength);

uint8_t ucReadBufferDataFromUSART1( uint8_t *pucBuffer );
uint8_t ucReadBufferDataFromUSART2( uint8_t *pucBuffer );
uint8_t ucReadBufferCharDataFromUSART2( void );
uint8_t ucReadBufferDataFromUSART3( uint8_t *pucBuffer );
uint8_t ucReadBufferDataFromUART4( uint8_t *pucBuffer );


#endif


