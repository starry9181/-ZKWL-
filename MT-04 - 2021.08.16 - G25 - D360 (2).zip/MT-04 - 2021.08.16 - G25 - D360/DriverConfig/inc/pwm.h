#ifndef __PWM_H
#define __PWM_H

#include "TaskManage.h"


#define TIM_PEROID      (uint16_t)36000  

#define SetFrontLeftMotorDriverDuty( DutyValue )              TIM_SetCompare1( TIM8, DutyValue )
#define SetFrontRightMotorDriverDuty( DutyValue )             TIM_SetCompare2( TIM8, DutyValue )
#define SetBehindLeftMotorDriverDuty( DutyValue )             TIM_SetCompare3( TIM8, DutyValue )
#define SetBehindRightMotorDriverDuty( DutyValue )            TIM_SetCompare4( TIM8, DutyValue )
    




#define pwmChargeMotorEnable1(  )                     TIM_SetCompare1(TIM5, TIM_PEROID/2)
#define pwmChargeMotorDisable1(  )                    TIM_SetCompare1(TIM5, TIM_PEROID+1)

#define pwmChargeMotorEnable2(  )                     TIM_SetCompare2(TIM5, TIM_PEROID/2)
#define pwmChargeMotorDisable2(  )                    TIM_SetCompare2(TIM5, TIM_PEROID+1)

#define pwmAddWaterMotorEnable1(  )                   TIM_SetCompare1(TIM3, TIM_PEROID/2)
#define pwmAddWaterMotorDisable1(  )                  TIM_SetCompare1(TIM3, TIM_PEROID+1)

#define pwmAddWaterMotorEnable2(  )                   TIM_SetCompare2(TIM3, TIM_PEROID/2)
#define pwmAddWaterMotorDisable2(  )                  TIM_SetCompare2(TIM3, TIM_PEROID+1)

#define pwmDrainWaterMotorEnable1(  )                 TIM_SetCompare3(TIM3, TIM_PEROID/2)
#define pwmDrainWaterMotorDisable1(  )                TIM_SetCompare3(TIM3, TIM_PEROID+1)

#define pwmDrainWaterMotorEnable2(  )                 TIM_SetCompare4(TIM3, TIM_PEROID/2)
#define pwmDrainWaterMotorDisable2(  )                TIM_SetCompare4(TIM3, TIM_PEROID+1)



#define pwmChargeMotorStretch(  )                     pwmChargeMotorDisable2(  );pwmChargeMotorEnable1(  )
#define pwmChargeMotorShrink(  )                      pwmChargeMotorDisable1(  );pwmChargeMotorEnable2(  ) 

#define pwmAddWaterMotorStretch(  )                   pwmAddWaterMotorDisable2(  );pwmAddWaterMotorEnable1(  )
#define pwmAddWaterMotorShrink(  )                    pwmAddWaterMotorDisable1(  );pwmAddWaterMotorEnable2(  ) 

#define pwmDrainWaterMotorStretch(  )                 pwmDrainWaterMotorDisable2(  );pwmDrainWaterMotorEnable1(  )
#define pwmDrainWaterMotorShrink(  )                  pwmDrainWaterMotorDisable1(  );pwmDrainWaterMotorEnable2(  )


#define pwmLeftEncodeEnable(  )                       TIM_CCxCmd(TIM4, TIM_Channel_1, TIM_CCx_Enable ) 
#define pwmLeftEncodeDisnable(  )                     TIM_CCxCmd(TIM4, TIM_Channel_1, TIM_CCx_Disable )

#define pwmLeftCentreEncodeEnable(  )                 TIM_CCxCmd(TIM4, TIM_Channel_2, TIM_CCx_Enable ) 
#define pwmLeftCentreEncodeDisnable(  )               TIM_CCxCmd(TIM4, TIM_Channel_2, TIM_CCx_Disable )

#define pwmRightCentreEncodeEnable(  )                TIM_CCxCmd(TIM4, TIM_Channel_3, TIM_CCx_Enable ) 
#define pwmRightCentreEncodeDisnable(  )              TIM_CCxCmd(TIM4, TIM_Channel_3, TIM_CCx_Disable )

#define pwmRightEncodeEnable(  )                      TIM_CCxCmd(TIM4, TIM_Channel_4, TIM_CCx_Enable ) 
#define pwmRightEncodeDisnable(  )                    TIM_CCxCmd(TIM4, TIM_Channel_4, TIM_CCx_Disable )

#define pwmTimer4Channel_2Enable(  )                   TIM_SetCompare2(TIM4, TIM_PEROID/3)
#define pwmTimer4Channel_2Disable(  )                  TIM_SetCompare2(TIM4, 0)

#define pwmTimer4Channel_3Enable(  )                   TIM_SetCompare3(TIM4, TIM_PEROID/3)
#define pwmTimer4Channel_3Disable(  )                  TIM_SetCompare3(TIM4, 0)

void TIM3_PWMModeConfig( void );
void TIM4_PWMModeConfig( void );
void TIM8_PWMModeConfig( void );
#endif
