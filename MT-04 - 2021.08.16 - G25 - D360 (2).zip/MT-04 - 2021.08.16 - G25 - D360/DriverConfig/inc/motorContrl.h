#ifndef __MOTORCONTRL_H
#define __MOTORCONTRL_H
#include "TaskManage.h"

#define REDUCTION_RATIO       (uint16_t)40        //���Ӽ�������ٱ�

#define LEFT_REDUCTION_RATIO       (uint16_t)25        //���Ӽ�������ٱ�
#define RIGHT_REDUCTION_RATIO       (uint16_t)25       //���Ӽ�������ٱ�

#define RETURN_REDUCTION_RATIO       (uint16_t)40        //���Ӽ�������ٱ�

#define WHEEL_DIAMETER        (uint16_t)360       //����ֱ��mm
#define ENCODE_LINE_NUMBER    (uint16_t)1000      //����������


typedef struct{ 
//    int16_t frontLeftWheelRotationRate;
//    int16_t frontRightWheelRotationRate;
//    int16_t behindLeftWheelRotationRate;
//    int16_t behindRightWheelRotationRate;
    int16_t frontLeftWheelSpeed;     //��ǰ���ٶ�
    int16_t frontRightWheelSpeed;    //��ǰ���ٶ�
    int16_t behindLeftWheelSpeed;    //������ٶ�
    int16_t behindRightWheelSpeed;   //�Һ����ٶ�
//    uint8_t frontLeftWheelPidEnable : 1;
//    uint8_t frontRightWheelPidEnable : 1;
//    uint8_t behindLeftWheelPidEnable : 1;
//    uint8_t behindRightWheelPidEnable : 1;
//    uint8_t Reserve : 4;
}robotChassisParameter;


typedef struct{
    float leftAngle;
    float rightAngle;
    float centreAngle;
}AngleStruct;




#define motorSetFrontLeftWheelRotationRate( Speed )                    MecanumChassisNew.frontLeftWheelSpeed = Speed
#define motorSetFrontRightWheelRotationRate( Speed )                   MecanumChassisNew.frontRightWheelSpeed = Speed
#define motorSetBehindLeftWheelRotationRate( Speed )                   MecanumChassisNew.behindLeftWheelSpeed = Speed
#define motorSetBehindRightWheelRotationRate( Speed )                  MecanumChassisNew.behindRightWheelSpeed = Speed
  
#define motorSetFrontLeftWheelSpeed( Speed )                            do{ \
                                                                            MecanumChassisSetPoint.frontLeftWheelSpeed = (Speed); MecanumChassisNew.frontLeftWheelSpeed = (Speed); \
                                                                            if( MecanumChassisSetPoint.frontLeftWheelSpeed > 0 ) {outFrontLeftWheelForward(  ); } \
                                                                            else if( MecanumChassisSetPoint.frontLeftWheelSpeed < 0 ) {outFrontLeftWheelRetreat(  );} \
                                                                            else { MecanumChassisReal.frontLeftWheelPidEnable = DISABLE;outFrontLeftWheelStop(  );SetFrontLeftMotorDriverDuty( 0 );} \
                                                                        }while(0)

#define motorSetFrontRightWheelSpeed( Speed )                           do{ \
                                                                            MecanumChassisSetPoint.frontRightWheelSpeed = (Speed); frontRightWheelPid.SetPoint = (Speed); \
                                                                            if( MecanumChassisSetPoint.frontRightWheelSpeed > 0 ) {outFrontRightWheelForward(  ); } \
                                                                            else if( MecanumChassisSetPoint.frontRightWheelSpeed < 0 ) {outFrontRightWheelRetreat(  );} \
                                                                        }while(0)

#define motorSetBehindLeftWheelSpeed( Speed )                           do{ \
                                                                            MecanumChassisSetPoint.behindLeftWheelSpeed = (Speed); \
                                                                        }while(0)

#define motorSetBehindRightWheelSpeed( Speed )                          do{ \
                                                                            MecanumChassisSetPoint.behindRightWheelSpeed = (Speed); \
                                                                        }while(0)


extern robotChassisParameter MecanumChassisNew, MecanumChassisOld, MecanumChassisSetPoint,MecanumChassisReal;
extern AngleStruct EncdoeAngle;
                                                                        
void robotSlowChangeSpeed( void );
void SpeedToRotationSpeed( void *Struct );
void RotationSpeedToSpeed( void *Struct );
void EncodeSpeedReturnBack( void );
                                                                        

#endif
