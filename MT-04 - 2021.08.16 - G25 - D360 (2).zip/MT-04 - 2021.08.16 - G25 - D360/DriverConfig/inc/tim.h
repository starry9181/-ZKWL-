#ifndef __TIM_H
#define __TIM_H

#include "TaskManage.h"

#define TIM6_PERIOD     (uint16_t)20000


void Timer6Init(void);


#endif
