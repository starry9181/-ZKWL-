#ifndef __IOINPUT_H
#define __IOINPUT_H

#include "TaskManage.h"


/********************motor driver error check******************/
#define FrontLeftALMCheckPort                           GPIOB
#define FrontLeftALMCheckPin                            GPIO_Pin_15
#define inputFrontLeftALMCheck(  )                      GPIO_ReadInputDataBit( FrontLeftALMCheckPort, FrontLeftALMCheckPin )

#define FrontRightALMCheckPort                          GPIOB
#define FrontRightALMCheckPin                           GPIO_Pin_4
#define inputFrontRightALMCheck(  )                     GPIO_ReadInputDataBit( FrontRightALMCheckPort, FrontRightALMCheckPin )

#define BehindLeftALMCheckPort                          GPIOB
#define BehindLeftALMCheckPin                           GPIO_Pin_1
#define inputBehindLeftALMCheck(  )                     GPIO_ReadInputDataBit( BehindLeftALMCheckPort, BehindLeftALMCheckPin )

#define BehindRightALMCheckPort                         GPIOC
#define BehindRightALMCheckPin                          GPIO_Pin_3
#define inputBehindRightALMCheck(  )                    GPIO_ReadInputDataBit( BehindRightALMCheckPort, BehindRightALMCheckPin )

#define RobotStopCheckPort                              GPIOA
#define RobotStopCheckPin                               GPIO_Pin_8
#define inputRobotStopCheck(  )                         GPIO_ReadInputDataBit( RobotStopCheckPort, RobotStopCheckPin )

#define FrontTouchCheckPort                             GPIOB
#define FrontTouchCheckPin                              GPIO_Pin_14
#define inputFrontTouchCheck(  )                        GPIO_ReadInputDataBit( FrontTouchCheckPort, FrontTouchCheckPin )

#define BehindTouchCheckPort                            GPIOB
#define BehindTouchCheckPin                             GPIO_Pin_13
#define inputBehindTouchCheck(  )                       GPIO_ReadInputDataBit( BehindTouchCheckPort, BehindTouchCheckPin )

#define LimitSwitchCheckPort                            GPIOB
#define LimitSwitchCheckPin                             GPIO_Pin_15
#define inputLimitSwitchCheck(  )                       GPIO_ReadInputDataBit( LimitSwitchCheckPort, LimitSwitchCheckPin )






/********************��λ����******************/
#define LimitSwitchPort                           GPIOD
#define LimitSwitchPortClock                      RCC_APB2Periph_GPIOD

#define ChagreLimitSwitchInPin                    GPIO_Pin_15
#define ChagreLimitSwitchOutPin                   GPIO_Pin_14
#define AddWaterLimitSwitchInPin                  GPIO_Pin_13
#define AddWaterLimitSwitchOutPin                 GPIO_Pin_12
#define DrainWaterLimitSwitchInPin                GPIO_Pin_11
#define DrainWaterLimitSwitchOutPin               GPIO_Pin_10


#define inCheckChagreLimitSwitchIn(  )            GPIO_ReadInputDataBit( LimitSwitchPort, ChagreLimitSwitchInPin )
#define inCheckChagreLimitSwitchOut(  )           GPIO_ReadInputDataBit( LimitSwitchPort, ChagreLimitSwitchOutPin )

#define inCheckAddWaterLimitSwitchIn(  )          GPIO_ReadInputDataBit( LimitSwitchPort, AddWaterLimitSwitchInPin )
#define inCheckAddWaterLimitSwitchOut(  )         GPIO_ReadInputDataBit( LimitSwitchPort, AddWaterLimitSwitchOutPin )

#define inCheckDrainWaterLimitSwitchIn(  )        GPIO_ReadInputDataBit( LimitSwitchPort, DrainWaterLimitSwitchInPin )
#define inCheckDrainWaterLimitSwitchOut(  )       GPIO_ReadInputDataBit( LimitSwitchPort, DrainWaterLimitSwitchOutPin )


/********************��λ����******************/
#define CanBoardIDPort                           GPIOB
#define CanBoardIDPortClock                      RCC_APB2Periph_GPIOB

#define CanBoardIDPin                            GPIO_Pin_11
#define inCheckCanBoardIDState(  )               GPIO_ReadInputDataBit( CanBoardIDPort, CanBoardIDPin )



void vAllIoInputConfig( void );
void gpioInputCheck( void );
void Clear_Crash_Flag(void);

#endif
