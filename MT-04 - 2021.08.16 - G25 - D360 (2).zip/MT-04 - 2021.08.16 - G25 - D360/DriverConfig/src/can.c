 /**********************************************************************************
 * Filename   ��can.c
 * Author     : Liu Tusheng       
 * Version    : 1.0
 * Date       : 2017.12.7
 * Discription : can base driver API
 * hardware connect:
**********************************************************************************/
#include "can.h"

//extern "C"
//{


CanReceive CanMessage;
//char SelectAddress = 0;

/*******************************************************************************
* Function Name  : CanInterfaceInitConfig
* Description    : 
* Input          :          
* Output         : None
* Return         : None
*******************************************************************************/
void CanInterfaceInitConfig( void )
{
	GPIO_InitTypeDef GPIO_InitStruct;
	NVIC_InitTypeDef NVIC_InitStructure;
	CAN_InitTypeDef CAN_InitStructure;
	CAN_FilterInitTypeDef CAN_FilterInitStructure;
	
	RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOA, ENABLE );
	RCC_APB1PeriphClockCmd( RCC_APB1Periph_CAN1, ENABLE );
	//Can Rx
	GPIO_InitStruct.GPIO_Pin  =  GPIO_Pin_11;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStruct.GPIO_Mode =  GPIO_Mode_IPU;
	GPIO_Init(GPIOA,&GPIO_InitStruct);
	//Can Tx
	GPIO_InitStruct.GPIO_Pin  =  GPIO_Pin_12;
	GPIO_InitStruct.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStruct.GPIO_Mode =  GPIO_Mode_AF_PP;
	GPIO_Init( GPIOA, &GPIO_InitStruct );

	/* CAN cell init */ //36MHz 500Kbps
	CAN_DeInit( CAN1 );
	CAN_StructInit( &CAN_InitStructure );
	CAN_InitStructure.CAN_TTCM=DISABLE;			   //MCR-TTCM  �ر�ʱ�䴥��ͨ��ģʽʹ��
	CAN_InitStructure.CAN_ABOM=ENABLE;			   //MCR-ABOM  �Զ����߹��� 
	CAN_InitStructure.CAN_AWUM=DISABLE;			   //MCR-AWUM  ʹ���Զ�����ģʽ
	CAN_InitStructure.CAN_NART=DISABLE;			   //MCR-NART  ��ֹ�����Զ��ش�	  DISABLE-�Զ��ش�
	CAN_InitStructure.CAN_RFLM=DISABLE;			   //MCR-RFLM  ����FIFO ����ģʽ  DISABLE-���ʱ�±��ĻḲ��ԭ�б���  
	CAN_InitStructure.CAN_TXFP=DISABLE;			   //MCR-TXFP  ����FIFO���ȼ� DISABLE-���ȼ�ȡ���ڱ��ı�ʾ�� 
	
#if CAN_DEBUG
	CAN_InitStructure.CAN_Mode= CAN_Mode_LoopBack;
#else
	CAN_InitStructure.CAN_Mode= CAN_Mode_Normal; 
#endif


    /*        ������ = 36M/(CAN_SJW+CAN_BS1+CAN_BS2)/CAN_Prescaler        */
#if CAN_250kbps
	CAN_InitStructure.CAN_SJW=CAN_SJW_1tq;     //����ͬ����Ծһ��ʱ�䵥λ����
	CAN_InitStructure.CAN_BS1=CAN_BS1_9tq;    //ʱ���1Ϊ12��ʱ�䵥λ
	CAN_InitStructure.CAN_BS2=CAN_BS2_8tq;     //ʱ���1Ϊ3��ʱ�䵥λ
	CAN_InitStructure.CAN_Prescaler= 8;        //36M/(1+12+3)/9= 250kbps
											       //36M/(1+5+2)/9 = 500kbps										//36M(1+2+1)/9 = 1M
#endif

#if CAN_500kbps
	CAN_InitStructure.CAN_SJW=CAN_SJW_1tq;
	CAN_InitStructure.CAN_BS1=CAN_BS1_9tq;
	CAN_InitStructure.CAN_BS2=CAN_BS2_8tq;
	CAN_InitStructure.CAN_Prescaler= 4;        //36M/(1+9+8)/4= 500kbps
#endif

#if CAN_1Mbps
	CAN_InitStructure.CAN_SJW=CAN_SJW_2tq;
	CAN_InitStructure.CAN_BS1=CAN_BS1_5tq;
	CAN_InitStructure.CAN_BS2=CAN_BS2_3tq;
	CAN_InitStructure.CAN_Prescaler= 4;       //36M/(1+5+3)/4= 1Mbps
#endif

	CAN_Init(CAN1,&CAN_InitStructure); 
									 
	/* CAN filter init */
	CAN_FilterInitStructure.CAN_FilterNumber=0;                       //ɸѡ����0
	CAN_FilterInitStructure.CAN_FilterMode=CAN_FilterMode_IdMask;     //����������ģʽ
	CAN_FilterInitStructure.CAN_FilterScale=CAN_FilterScale_32bit;    //ɸѡ��λ��Ϊ����32λ,
	/* ʹ��ɸѡ�������ձ�־�����ݽ��бȶ�ɸѡ����չID�������µľ����������ǵĻ��������FIFO0�� */
	CAN_FilterInitStructure.CAN_FilterIdHigh=0; //((((u32)AckermanChassisID<<3)|CAN_ID_EXT|CAN_RTR_DATA)&0xFFFF0000)>>16;                  //Ҫɸѡ��ID��λ 
	CAN_FilterInitStructure.CAN_FilterIdLow=AckermanChassisID; //(((u32)AckermanChassisID<<3)|CAN_ID_EXT|CAN_RTR_DATA)&0xFFFF;                   //Ҫɸѡ��ID��λ 
	CAN_FilterInitStructure.CAN_FilterMaskIdHigh=0;              //ɸѡ����16λÿλ����ƥ��
	CAN_FilterInitStructure.CAN_FilterMaskIdLow=0;
	CAN_FilterInitStructure.CAN_FilterFIFOAssignment=CAN_FIFO0;       //ɸѡ����16λÿλ����ƥ��
	CAN_FilterInitStructure.CAN_FilterActivation=ENABLE;              //ʹ��ɸѡ��
	CAN_FilterInit(&CAN_FilterInitStructure);
	
	/* CAN filter init */
//	CAN_FilterInitStructure.CAN_FilterNumber=2;                       //ɸѡ����6
//	CAN_FilterInitStructure.CAN_FilterMode=CAN_FilterMode_IdMask;     //����������ģʽ
//	CAN_FilterInitStructure.CAN_FilterScale=CAN_FilterScale_32bit;    //ɸѡ��λ��Ϊ����32λ,
//	/* ʹ��ɸѡ�������ձ�־�����ݽ��бȶ�ɸѡ����չID�������µľ����������ǵĻ��������FIFO0�� */
//	CAN_FilterInitStructure.CAN_FilterIdHigh=((((u32)SelectAddress<<3)|CAN_ID_EXT|CAN_RTR_DATA)&0xFFFF0000)>>16;                  //Ҫɸѡ��ID��λ 
//	CAN_FilterInitStructure.CAN_FilterIdLow=(((u32)SelectAddress<<3)|CAN_ID_EXT|CAN_RTR_DATA)&0xFFFF;                   //Ҫɸѡ��ID��λ 
//	CAN_FilterInitStructure.CAN_FilterMaskIdHigh=0xFFFF;              //ɸѡ����16λÿλ����ƥ��
//	CAN_FilterInitStructure.CAN_FilterMaskIdLow=0xFFFF;
//	CAN_FilterInitStructure.CAN_FilterFIFOAssignment=CAN_FIFO0;       //ɸѡ����16λÿλ����ƥ��
//	CAN_FilterInitStructure.CAN_FilterActivation=ENABLE;              //ʹ��ɸѡ��
//	CAN_FilterInit(&CAN_FilterInitStructure);
	
	/* Enable CAN RX0 interrupt IRQ channel */
	NVIC_InitStructure.NVIC_IRQChannel = USB_LP_CAN1_RX0_IRQn;
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&NVIC_InitStructure);
	
//	NVIC_InitStructure.NVIC_IRQChannel = CAN1_RX1_IRQn;
//	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
//	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
//	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//	NVIC_Init(&NVIC_InitStructure);	
	
//	NVIC_InitStructure.NVIC_IRQChannel = USB_HP_CAN1_TX_IRQn;
//	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 2;
//	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;
//	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;
//	NVIC_Init(&NVIC_InitStructure);
	/*CANͨ���ж�ʹ��*/
	CAN_ITConfig( CAN1, CAN_IT_FMP0, ENABLE );
//	CAN_ITConfig(CAN1,CAN_IT_FMP0 | CAN_IT_FF0 | CAN_IT_FOV0,ENABLE);
//	CAN_ITConfig(CAN1,CAN_IT_FMP1 | CAN_IT_FF1 | CAN_IT_FOV1,ENABLE);	//FIFO��Ϣ�Һ��ж�����
	
}




/*******************************************************************************
* Function Name  : CanSendDataPackage
* Description    : 
* Input          : - bound:         
* Output         : None
* Return         : None
*******************************************************************************/
bool CanSendDataPackage( uint32_t TargetID, uint8_t buffer[] )
{
    uint8_t i;
    CanTxMsg CanPacket;
    /* transmit */
	
	CanPacket.StdId=TargetID;       //��׼��ʶ����ID��
	CanPacket.ExtId=TargetID; 		//��չ��ʶ����ID��
    CanPacket.RTR=CAN_RTR_DATA;     //������Ϣ��֡����
    CanPacket.IDE=CAN_ID_STD;       //��ʶ��������
    CanPacket.DLC=8; 				//���ݳ���

	for( i=0; i<8; i++ )
	{
		CanPacket.Data[i] = buffer[i];
	}
	if( CAN_Transmit( CAN1, &CanPacket ) == CAN_NO_MB )
	{
		return false;
	}
    
    return true;
}



/*******************************************************************************
* Function Name  : CanRceiveDataPackage
* Description    : initialise USART1 and receive interrupt.
* Input          : - bound: USART1 bound             
* Output         : None
* Return         : None
*******************************************************************************/
void CanRceiveDataPackage( void )
{     
    static CanRxMsg RxMessage;
    /*�������ж�������*/
    
    CAN_Receive( CAN1, CAN_FIFO0, &RxMessage );
    if(RxMessage.StdId == 0x01 && RxMessage.IDE == CAN_ID_STD)
    {
        memcpy( CanMessage.buffer[CanMessage.ReceiveIndex], RxMessage.Data, 8 );
        ReceiveCanMessageDone();
    }
}


/*******************************************************************************
* Function Name  : ReadCanMessageNumber
* Description    : 
* Input          :        
* Output         : None
* Return         : None
*******************************************************************************/
uint8_t ReadCanMessageNumber( void )
{
	return CanMessage.MessageNumber;
}


/*******************************************************************************
* Function Name  : ReadCanMessageNumber
* Description    : 
* Input          :        
* Output         : None
* Return         : None
*******************************************************************************/
bool ReadCanPackageMessage( uint8_t *pBuffer )
{
	
	memcpy( pBuffer, CanMessage.buffer[CanMessage.ReadIndex], 8 );
	ReadCanMessageDone(  );
	
	return true;
}


/*******************************************************************************
* Function Name  : USB_HP_CAN1_TX_IRQHandler
* Description    : initialise USART1 and receive interrupt.
* Input          : - bound: USART1 bound             
* Output         : None
* Return         : None
*******************************************************************************/
void USB_HP_CAN1_TX_IRQHandler( void )
{
	
}





/*******************************************************************************
* Function Name  : USB_LP_CAN1_RX0_IRQHandler
* Description    : initialise USART1 and receive interrupt.
* Input          : - bound: USART1 bound             
* Output         : None
* Return         : None
*******************************************************************************/
void USB_LP_CAN1_RX0_IRQHandler( void )
{
	
	CanRceiveDataPackage(  );
//	if( CAN_GetFlagStatus( CAN1, CAN_IT_FMP0 ) == SET ) /*!< FIFO 0 message pending Interrupt*/
//	{
//		CAN_ClearITPendingBit( CAN1, CAN_IT_FMP0 );
//		CanRceiveDataPackage( &RxMessage );
//	}
//	else if( CAN_GetFlagStatus( CAN1, CAN_IT_FOV0 ) == SET ) /*!< FIFO 0 overrun Interrupt*/
//	{
//		CAN_ClearITPendingBit( CAN1, CAN_IT_FOV0 );
//	}
//	else if( CAN_GetFlagStatus( CAN1, CAN_IT_FF0 ) == SET ) /*!< FIFO 0 full Interrupt*/
//	{
//		CAN_ClearITPendingBit( CAN1, CAN_IT_FF0 );
//	}
//	else
//	{
//	
//	}
}





/*******************************************************************************
* Function Name  : CAN1_RX1_IRQHandler
* Description    : 
* Input          : - bound: USART1 bound             
* Output         : None
* Return         : None
*******************************************************************************/
void CAN1_RX1_IRQHandler( void )
{
	if( CAN_GetFlagStatus( CAN1, CAN_IT_FMP1 ) == SET ) /*!< FIFO 1 message pending Interrupt*/
	{
		CAN_ClearITPendingBit( CAN1, CAN_IT_FMP1 );
		CanRceiveDataPackage(  );
	}
	else if( CAN_GetFlagStatus( CAN1, CAN_IT_FOV1 ) == SET ) /*!< FIFO 1 overrun Interrupt*/
	{
		CAN_ClearITPendingBit( CAN1, CAN_IT_FOV1 );
	}
	else if( CAN_GetFlagStatus( CAN1, CAN_IT_FF1 ) == SET ) /*!< FIFO 1 full Interrupt*/
	{
		CAN_ClearITPendingBit( CAN1, CAN_IT_FF1 );
	}
	else
	{
	
	}
}



//} //end extern "C"




