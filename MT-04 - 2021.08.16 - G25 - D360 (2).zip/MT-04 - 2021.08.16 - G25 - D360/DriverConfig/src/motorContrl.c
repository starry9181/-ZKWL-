/**********************************************************************************
 * Filename   ��motorContrl.c
 * Author     : Liu Tusheng       
 * Version    : 1.0
 * Date       : 2019.5.21
 * Discription : 
 * Hardware Connet:
**********************************************************************************/ 
#include "motorContrl.h"

#define SPEED_STEP   20
#define ROTATION_SPEED_STEP 3

AngleStruct EncdoeAngle;

robotChassisParameter MecanumChassisNew = {0}, MecanumChassisOld = {0}, MecanumChassisSetPoint = {0}, MecanumChassisReal = {0};



void EncodeSpeedReturnBack( void );






/*******************************************************************************
* Function Name  : robotSlowChangeSpeed
* Description    : ���ת����PWMռ�ձȹ�ϵ��Rm = 40P*100
                   ռ�ձȣ�P = X/TIM_PEROID
                   ����ת������ת�ٹ�ϵ��Rw = Rm/20
                   �����Ϲ�ϵ����ö�ʱ���Ƚ�ֵ��X = Rw*TIM_PEROID/200;
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/


void EncodeSpeedReturnBack( void )
{
//    MecanumChassisReal.frontLeftWheelSpeed = (int32_t)((3.14*WHEEL_DIAMETER*TimerEmcode.frontLeftEncode*1000000.0)/(REDUCTION_RATIO*ENCODE_LINE_NUMBER*TIM6_PERIOD));  //��λ��mm/s
//    MecanumChassisReal.frontLeftWheelSpeed /= 4; 
    
    MecanumChassisReal.frontRightWheelSpeed = (int32_t)((3.14*WHEEL_DIAMETER*TimerEmcode.frontRightEncode*1000000.0)/(RETURN_REDUCTION_RATIO*ENCODE_LINE_NUMBER*TIM6_PERIOD));  //��λ��mm/s
    MecanumChassisReal.frontRightWheelSpeed /= 4;
    
    MecanumChassisReal.behindLeftWheelSpeed = (int32_t)((3.14*WHEEL_DIAMETER*TimerEmcode.behindLeftEncode*1000000.0)/(LEFT_REDUCTION_RATIO*ENCODE_LINE_NUMBER*TIM6_PERIOD));  //��λ��mm/s
    MecanumChassisReal.behindLeftWheelSpeed /= 4;
    
    MecanumChassisReal.behindRightWheelSpeed = (int32_t)((3.14*WHEEL_DIAMETER*TimerEmcode.behindRightEncode*1000000.0)/(RIGHT_REDUCTION_RATIO*ENCODE_LINE_NUMBER*TIM6_PERIOD));  //��λ��mm/s
    MecanumChassisReal.behindRightWheelSpeed /= 4;

}


