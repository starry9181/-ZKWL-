/******************************************************************************
* �ļ���  ��tim.c
* �ļ�������
* ������  ��Liu Tusheng
* ��    �գ�2016��2��29��
* 
* Ӳ�����ӣ�
*
******************************************************************************/
#include "tim.h"


int32_t Enconde = 0;



/*******************************************************************************
* Function Name  : Timer2Init
* Description    : Timer2 Init.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void Timer6Init(void)
{
	TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
	
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6, ENABLE);
	
	TIM_TimeBaseStructure.TIM_Period = TIM6_PERIOD;                     //��������һ�������¼�װ�����Զ���װ�ؼĴ������ڵ�ֵ
	TIM_TimeBaseStructure.TIM_Prescaler =72-1;                     //����������ΪTIMxʱ��Ƶ�ʳ�����Ԥ��Ƶֵ
	TIM_TimeBaseStructure.TIM_ClockDivision = 0;                   //����ʱ�ӷָ�:TDTS = Tck_tim
	TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;    //TIM���ϼ���ģʽ
	TIM_TimeBaseInit(TIM6, &TIM_TimeBaseStructure);                //����TIM_TimeBaseInitStruct��ָ���Ĳ�����ʼ��TIMx��ʱ�������λ
	
	TIM_ITConfig(TIM6,TIM_IT_Update,ENABLE ); 
	NVIC_InitStructure.NVIC_IRQChannel = TIM6_IRQn;  
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;  
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;  
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; 
	NVIC_Init(&NVIC_InitStructure);  
	TIM_Cmd(TIM6, ENABLE);
	
}






/*******************************************************************************
* Function Name  : TIM6_IRQHandler
* Description    : TIM6_IRQHandler.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void TIM6_IRQHandler(void)   
{
    int32_t EncondeCount = 0;
    
    taskENTER_CRITICAL(  );
    
	if (TIM_GetITStatus(TIM6, TIM_IT_Update) != RESET)  
	{
		TIM_ClearITPendingBit(TIM6, TIM_IT_Update);  
       
//        TimerEmcode.frontLeftEncodeNew = TIM_GetCounter( TIM1 );
//        if( TimerEmcode.frontLeftUpdateFlag != true )
//        {
//            if( (TimerEmcode.frontLeftEncodeNew-TimerEmcode.frontLeftEncodeOld) > 0 ) 
//            {
//                TimerEmcode.frontLeftEncode = (int32_t)(TimerEmcode.frontLeftEncodeNew - TimerEmcode.frontLeftEncodeOld );
//            }
//            else 
//            {
//                TimerEmcode.frontLeftEncode = (int32_t)(TimerEmcode.frontLeftEncodeNew - TimerEmcode.frontLeftEncodeOld);
//            }
//        }
//        else if( TimerEmcode.frontLeftUpdateFlag == true )
//        {
//            TimerEmcode.frontLeftUpdateFlag = false;
//            if( (TimerEmcode.frontLeftEncodeNew-TimerEmcode.frontLeftEncodeOld) > 0 ) 
//            {
//                TimerEmcode.frontLeftEncode = -(int32_t)( 0xFFFF - TimerEmcode.frontLeftEncodeNew + TimerEmcode.frontLeftEncodeOld );
//            }
//            else 
//            {
//                TimerEmcode.frontLeftEncode = (int32_t)( TimerEmcode.frontLeftEncodeNew + 0xFFFF - TimerEmcode.frontLeftEncodeOld);
//            }
//        }
//        TimerEmcode.frontLeftEncodeOld = TimerEmcode.frontLeftEncodeNew;
//        
        /************************************************************************************************************************************/
        TimerEmcode.frontRightEncodeNew = TIM_GetCounter( TIM4 );
        if( TimerEmcode.frontRightUpdateFlag != true )
        {
            if( (TimerEmcode.frontRightEncodeNew-TimerEmcode.frontRightEncodeOld) > 0 ) 
            {
                TimerEmcode.frontRightEncode = -(int32_t)(TimerEmcode.frontRightEncodeNew - TimerEmcode.frontRightEncodeOld );
            }
            else 
            {
                TimerEmcode.frontRightEncode = -(int32_t)(TimerEmcode.frontRightEncodeNew - TimerEmcode.frontRightEncodeOld);
            }
        }
        else if( TimerEmcode.frontRightUpdateFlag == true )
        {
            TimerEmcode.frontRightUpdateFlag = false;
            if( (TimerEmcode.frontRightEncodeNew-TimerEmcode.frontRightEncodeOld) > 0 ) 
            {
                TimerEmcode.frontRightEncode = (int32_t)( 0xFFFF - TimerEmcode.frontRightEncodeNew + TimerEmcode.frontRightEncodeOld );
            }
            else 
            {
                TimerEmcode.frontRightEncode = -(int32_t)( TimerEmcode.frontRightEncodeNew + 0xFFFF - TimerEmcode.frontRightEncodeOld);
            }
        }
        TimerEmcode.frontRightEncodeOld = TimerEmcode.frontRightEncodeNew;
        
        /************************************************************************************************************************************/
        TimerEmcode.behindLeftEncodeNew = TIM_GetCounter( TIM3 );
        if( TimerEmcode.behindLeftUpdateFlag != true )
        {
            if( (TimerEmcode.behindLeftEncodeNew-TimerEmcode.behindLeftEncodeOld) > 0 ) 
            {
                TimerEmcode.behindLeftEncode = (int32_t)(TimerEmcode.behindLeftEncodeNew - TimerEmcode.behindLeftEncodeOld );
            }
            else 
            {
                TimerEmcode.behindLeftEncode = (int32_t)(TimerEmcode.behindLeftEncodeNew - TimerEmcode.behindLeftEncodeOld);
            }
        }
        else if( TimerEmcode.behindLeftUpdateFlag == true )
        {
            TimerEmcode.behindLeftUpdateFlag = false;
//            if( (TimerEmcode.behindLeftEncodeNew-TimerEmcode.frontLeftEncodeOld) > 0 ) 
//            {
//                TimerEmcode.behindLeftEncode = -(int32_t)( 0xFFFF - TimerEmcode.behindLeftEncodeNew + TimerEmcode.behindLeftEncodeOld );
//            }
//            else 
//            {
//                TimerEmcode.behindLeftEncode = (int32_t)( TimerEmcode.behindLeftEncodeNew + 0xFFFF - TimerEmcode.behindLeftEncodeOld);
//            }
        }
        TimerEmcode.behindLeftEncodeOld = TimerEmcode.behindLeftEncodeNew;
        
        
        /************************************************************************************************************************************/
        TimerEmcode.behindRightEncodeNew = TIM_GetCounter( TIM2 );
        if( TimerEmcode.behindRightUpdateFlag != true )
        {
            if( (TimerEmcode.behindRightEncodeNew-TimerEmcode.behindRightEncodeOld) > 0 ) 
            {
                TimerEmcode.behindRightEncode = -(int32_t)(TimerEmcode.behindRightEncodeNew - TimerEmcode.behindRightEncodeOld );
            }
            else 
            {
                TimerEmcode.behindRightEncode = -(int32_t)(TimerEmcode.behindRightEncodeNew - TimerEmcode.behindRightEncodeOld);
            }
        }
        else if( TimerEmcode.behindRightUpdateFlag == true )
        {
            TimerEmcode.behindRightUpdateFlag = false;
//            if( (TimerEmcode.behindRightEncodeNew-TimerEmcode.frontRightEncodeOld) > 0 ) 
//            {
//                TimerEmcode.behindRightEncode = (int32_t)( 0xFFFF - TimerEmcode.behindRightEncodeNew + TimerEmcode.behindRightEncodeOld );
//            }
//            else 
//            {
//                TimerEmcode.behindRightEncode = -(int32_t)( TimerEmcode.behindRightEncodeNew + 0xFFFF - TimerEmcode.behindRightEncodeOld);
//            }
        }
        TimerEmcode.behindRightEncodeOld = TimerEmcode.behindRightEncodeNew;
//        Enconde += TimerEmcode.behindRightEncode;
        EncodeSpeedReturnBack(  );

            vWheelSpeedAdjust(  );
        

//        sendRealyData(  );
	}

    taskEXIT_CRITICAL(  );
} 





