/*******************************************************************************
* �ļ���  : 
* ��    ��: Initializes the peripherals used by the SPI nRF24L01 driver.
* ��    ��: 
* �ļ�����: 
* Ӳ������: 
*******************************************************************************/
#include "spi.h"




/*******************************************************************************
* Function Name  : STM32SPI_Init
* Description    : Initializes the peripherals used by the SPI nRF24L01 driver.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void STM32SPI_Init(void)
{
    SPI_InitTypeDef  SPI_InitStructure;
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_APB2PeriphClockCmd(SPI_GPIO_CLK | SPI_CLK | RCC_APB2Periph_AFIO, ENABLE);
    //    RCC_APB1PeriphClockCmd(SPI_CLK, ENABLE);

    /*!< Configure SPI_FLASH_SPI pins: SCK | MOSI*/
    GPIO_InitStructure.GPIO_Pin = SPI_SCK_PIN | SPI_MOSI_PIN;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;
    GPIO_Init(SPI_GPIO_PORT, &GPIO_InitStructure);

    GPIO_InitStructure.GPIO_Pin = SPI_MISO_PIN;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IN_FLOATING;
    GPIO_Init(SPI_GPIO_PORT, &GPIO_InitStructure);
    
    GPIO_InitStructure.GPIO_Pin = SPI_CE_PIN;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
    GPIO_Init(SPI_GPIO_PORT, &GPIO_InitStructure);
    SPI_CE_HIGH();

    SPI_InitStructure.SPI_Direction = SPI_Direction_2Lines_FullDuplex; //ȫ˫��
    SPI_InitStructure.SPI_Mode = SPI_Mode_Master;
    SPI_InitStructure.SPI_DataSize = SPI_DataSize_8b;
    SPI_InitStructure.SPI_CPOL = SPI_CPOL_Low;       //SPI_CPOL_High=ģʽ3��ʱ�ӿ���Ϊ�� //SPI_CPOL_Low=ģʽ0��ʱ�ӿ���Ϊ��
    SPI_InitStructure.SPI_CPHA = SPI_CPHA_1Edge;     //SPI_CPHA_2Edge;//SPI_CPHA_1Edge, SPI_CPHA_2Edge;
    SPI_InitStructure.SPI_NSS = SPI_NSS_Soft;        //SPI_NSS_Soft;//SPI_NSS_Hard
    SPI_InitStructure.SPI_BaudRatePrescaler = SPI_BaudRatePrescaler_4; //SPI_BaudRatePrescaler_2=9M;//SPI_BaudRatePrescaler_4=9MHz
    SPI_InitStructure.SPI_FirstBit = SPI_FirstBit_MSB; //���ݴӸ�λ��ʼ����
    SPI_InitStructure.SPI_CRCPolynomial = 7;
    SPI_Init(SPI1, &SPI_InitStructure);

    /* Enable SPI1  */
    SPI_Cmd(SPI1, ENABLE);
}




/*******************************************************************************
* Function Name  : SPI_WriteByte
* Description    : Sends a byte through the SPI interface and return the byte
*                  received from the SPI bus.
* Input          : byte : byte to send.
* Output         : None
* Return         : The value of the received byte.
*******************************************************************************/
uint8_t SPI_ExchangeByte(uint8_t data)
{
    static uint8_t SpiFlag = 0;
    uint8_t Data = 0;
    
    taskENTER_CRITICAL(  );
    /* Loop while DR register in not emplty */
    while( SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_TXE) == RESET );
    /* Send byte through the SPI1 peripheral */
    SPI_I2S_SendData(SPI1, data);
    /* Wait to receive a byte */
    while(SPI_I2S_GetFlagStatus(SPI1, SPI_I2S_FLAG_RXNE) == RESET);
    /* Return the byte read from the SPI bus */
    Data = SPI_I2S_ReceiveData(SPI1);
    taskEXIT_CRITICAL(  );
//    printf("Write Data = %d\r\n",Data);
    /* Loop while DR register in not emplty */
    return Data;
    
}








