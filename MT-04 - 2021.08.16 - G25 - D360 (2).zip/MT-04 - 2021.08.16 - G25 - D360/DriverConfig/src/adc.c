/******************************************************************************
* �ļ���  ��adc.c
* �ļ�����������Ť�ؼ��㣺
*           T = 9549*P/n
*           T : Ť�أ���λ:N*m
*           P : ���ʣ���λ��kW
*           n : ת�٣���λ��ת/min
*           C ���ܳ�����λ��mm
*           n = V(mm/s)*60(s)/C(mm)
*           �� T(N*mm) = 9549*P(W)/n
*             
* ������  ��Liu Tusheng
* ��    �գ�2016��2��29��
* Ӳ�����ӣ�
* PC0--ADC1->Channel_10 : ��ˢ��������ɼ�
* PC1--ADC1->Channel_11 : ���ֵ�������ɼ�
* PC2--ADC1->Channel_12 : ���ֵ�������ɼ�
* PC3--ADC1->Channel_13 : ���ˢ��������ɼ�
* PC4--ADC1->Channel_14 : �ұ�ˢ��������ɼ�
* PC5--ADC1->Channel_15 : �����������ɼ�
* 
******************************************************************************/
#include "adc.h"


uint16_t ADCValue[ADC_CONV_COUNT][ADC_CH_NUM] = {0};  //װ��ADC �ģͣ���������
uint16_t LowStateValue[ADC_CH_NUM] = {0};             //װ�ص�״̬�ɼ�������
uint16_t HighStateValue[ADC_CH_NUM] = {0};            //װ�ظ�״̬�ɼ�������
uint8_t ADCTestDoneFlag = 0;                          //ADC������ɱ�־

void TestNumberHandle( void );

/************��ֵ�ź���***************/
xSemaphoreHandle xSemaphoreADC1;

//����18K���裬����1K����

/*******************************************************************************
* Function Name  : AdcDataHandle
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void AdcDataHandle( void *Parammenters )
{
//    vSemaphoreCreateBinary( xSemaphoreADC1 ); //������ֵ�ź���
    
    ADC1_DMA2ChannelConfig(  );
    ADC_SoftwareStartConvCmd( ADC1, ENABLE ); 
    
    while( 1 )
    {
        if( ADCTestDoneFlag == 1 )
        {
//            ADC_Cmd( ADC1, DISABLE );
            TestNumberHandle(  );
            ADCTestDoneFlag = 0;
            ADC_Cmd( ADC1, ENABLE );
            ADC_SoftwareStartConvCmd( ADC1, ENABLE ); 
            
        }
                       
    }

}





/*******************************************************************************
* Function Name  : TestNumberHandle
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void TestNumberHandle( void )
{
#define HIGH_LOW_DIFFER_VALUE 1000  

    
    static uint16_t AxtractData[ADC_CH_NUM][ADC_CONV_COUNT] = {0},Average,voltage;
    uint8_t i,j;
    uint32_t sum[ADC_CH_NUM] = {0};
    
    
    /******************��ȡ����*********************/
    for(i=0;i<ADC_CONV_COUNT;i++)
    {
        for(j=0;j<ADC_CH_NUM;j++)
        {
            AxtractData[j][i] = ADCValue[i][j];
        }
        
    }
    /******************������ƽ��ֵ*********************/
    for(i=0;i<ADC_CH_NUM;i++)
    {
        for(j=0;j<ADC_CONV_COUNT;j++)
        {
            sum[i] += AxtractData[i][j];
        }

    }
     
    /*******
    48V 3127
    54.6V 3562
    **/
    Average = sum[0]/ADC_CONV_COUNT;    
    voltage = Average*3313*19/4096;
    
    
    if( voltage >= 48000 )
    {
        robotMotion.battery = 100*(voltage-48000)/6600;
        if( robotMotion.battery > 100 ) robotMotion.battery = 100;
    }
//    else if( Average >= 3440 )
//    {
//        robotMotion.battery = 100;
//    }
//    else
//    {
//        robotMotion.battery = (Average - 3000) / 4;
//        if( robotMotion.battery > 100 ) robotMotion.battery = 100;
//    }
    
    
    
}







/*******************************************************************************
* Function Name  : ADC1_DMA2Channel0Config
* Description    : ADC��ʼ����ADC���ݲ��ãģͣ����䷽ʽ.
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void ADC1_DMA2ChannelConfig( void )
{
    
    ADC_InitTypeDef       ADC_InitStructure;
    DMA_InitTypeDef       DMA_InitStructure;
    GPIO_InitTypeDef      GPIO_InitStructure;
    NVIC_InitTypeDef      NVIC_InitStructure; 

    /******************** Enable ADCx, DMA and GPIO clocks *********************/ 
    RCC_AHBPeriphClockCmd( RCC_AHBPeriph_DMA1, ENABLE );
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_ADC1|RCC_APB2Periph_GPIOA, ENABLE );
    
    /************** Configure ADC1 Channel pin as analog input *****************/
	  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
    GPIO_Init( GPIOA, &GPIO_InitStructure );
    
	
//		 GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
//    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
//    GPIO_Init( GPIOA, &GPIO_InitStructure );
	
//    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1;
//    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
//    GPIO_Init( GPIOB, &GPIO_InitStructure );
//    
//    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0|GPIO_Pin_1|GPIO_Pin_2|GPIO_Pin_3|GPIO_Pin_4|GPIO_Pin_5;
//    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AIN;
//    GPIO_Init( GPIOC, &GPIO_InitStructure );
       
    /******************************* ADC Common Init ****************************/    
    ADC_InitStructure.ADC_Mode = ADC_Mode_Independent;                      //ADC1��ADC2�����ڶ���ģʽ
    ADC_InitStructure.ADC_ScanConvMode = ENABLE;                            //����ɨ��ģʽ
    ADC_InitStructure.ADC_ContinuousConvMode = ENABLE;                     //����ת��ģʽ   
    ADC_InitStructure.ADC_ExternalTrigConv = ADC_ExternalTrigConv_None;     //�ر��ⲿ����
    ADC_InitStructure.ADC_DataAlign = ADC_DataAlign_Right;                  //ADC�����Ҷ���
    ADC_InitStructure.ADC_NbrOfChannel = ADC_CH_NUM;                        //ADCת��ͨ����
    ADC_Init(ADC1, &ADC_InitStructure);

    /* ADC1 regular channel configuration */ 
    ADC_RegularChannelConfig( ADC1, ADC_Channel_4 , 1 , ADC_SampleTime_13Cycles5 );
		//ADC_RegularChannelConfig( ADC1, ADC_Channel_5 , 6 , ADC_SampleTime_13Cycles5 );
		
//    ADC_RegularChannelConfig( ADC1, ADC_Channel_6 , 2 , ADC_SampleTime_13Cycles5 );
//    ADC_RegularChannelConfig( ADC1, ADC_Channel_7 , 3 , ADC_SampleTime_13Cycles5 );
//    ADC_RegularChannelConfig( ADC1, ADC_Channel_8 , 4 , ADC_SampleTime_13Cycles5 );
//    ADC_RegularChannelConfig( ADC1, ADC_Channel_9 , 5 , ADC_SampleTime_13Cycles5 );
//    ADC_RegularChannelConfig( ADC1, ADC_Channel_10, 6 , ADC_SampleTime_13Cycles5 );
//    ADC_RegularChannelConfig( ADC1, ADC_Channel_11, 7 , ADC_SampleTime_13Cycles5 );
//    ADC_RegularChannelConfig( ADC1, ADC_Channel_12, 8 , ADC_SampleTime_13Cycles5 );
//    ADC_RegularChannelConfig( ADC1, ADC_Channel_13, 9 , ADC_SampleTime_13Cycles5 );
//    ADC_RegularChannelConfig( ADC1, ADC_Channel_14, 10, ADC_SampleTime_13Cycles5 );
//    ADC_RegularChannelConfig( ADC1, ADC_Channel_15, 11, ADC_SampleTime_13Cycles5 );
   
    /********************************** ADC1 Init *******************************/       
    DMA_DeInit( DMA1_Channel1 );                           
    DMA_InitStructure.DMA_PeripheralBaseAddr = (uint32_t)&(ADC1->DR);       //ADC���ݼĴ�����ַ      
    DMA_InitStructure.DMA_MemoryBaseAddr = (uint32_t)&ADCValue;             //�ڴ����ַ
    DMA_InitStructure.DMA_DIR = DMA_DIR_PeripheralSRC;                      //���ݴ��䷽�� 
    DMA_InitStructure.DMA_BufferSize = ADC_CH_NUM * ADC_CONV_COUNT;         //�ڴ泤��
    DMA_InitStructure.DMA_PeripheralInc = DMA_PeripheralInc_Disable;        //����Ĵ�����ַ���� 
    DMA_InitStructure.DMA_MemoryInc = DMA_MemoryInc_Enable;                 //�ڴ��ַ����   
    DMA_InitStructure.DMA_PeripheralDataSize = DMA_PeripheralDataSize_HalfWord; //�������ݿ���
    DMA_InitStructure.DMA_MemoryDataSize = DMA_MemoryDataSize_HalfWord;     //�������ݿ���     
    DMA_InitStructure.DMA_Mode = DMA_Mode_Circular;                         //ѭ������ģʽ
    DMA_InitStructure.DMA_Priority = DMA_Priority_High;                     //�ģͣ�ͨ�������ȼ�
    DMA_InitStructure.DMA_M2M = DMA_M2M_Disable;                            //�ر��ڴ浽�ڴ�Ĵ���
    DMA_Init(DMA1_Channel1, &DMA_InitStructure); 

    /********************************** ADC DMA Interrupt *******************************/  
    DMA_ClearITPendingBit( DMA1_IT_GL1 );
    DMA_ITConfig( DMA1_Channel1,DMA_IT_TC,ENABLE );
    NVIC_InitStructure.NVIC_IRQChannel=DMA1_Channel1_IRQn;
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=1;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority=0;
    NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
    NVIC_Init( &NVIC_InitStructure );

    ADC_DMACmd( ADC1, ENABLE );
    DMA_Cmd( DMA1_Channel1,ENABLE );                                          //ʹ��DMAͨ��1
    ADC_Cmd( ADC1, ENABLE );
    
    ADC_ResetCalibration( ADC1 ); 
    while( ADC_GetResetCalibrationStatus( ADC1 ) ); 
    ADC_StartCalibration( ADC1 ); 
    while( ADC_GetCalibrationStatus( ADC1 ) ); 
//    /* Start ADC1 Software Conversion */ 
//    ADC_SoftwareStartConvCmd( ADC1, ENABLE );  
    
}






void DMA1_Channel1_IRQHandler( void )
{
//    portBASE_TYPE TaskWokenADC1 = pdFALSE;
    
    ADC_Cmd( ADC1, DISABLE );
    DMA_ClearITPendingBit(DMA1_IT_GL1);
    ADCTestDoneFlag = 1;
//    xSemaphoreGiveFromISR( xSemaphoreADC1, &TaskWokenADC1 );
    
}












