/**********************************************************************************
 * Filename   ��USART.c
 * Author     : Liu Tusheng       
 * Version    : 1.0
 * Date       : 2015.11.24
 *Discription : Usart base driver API
 **********************************************************************************/
#include "ChipID.h"








/***************************************************************************
 * ��������GetChipID
 * ����  ����ȡоƬID
 * ����  ����
 * ���  ����
 **************************************************************************/
void GetChipID(uint32_t ChipUniqueID[ ])
{
	ChipUniqueID[0] = *(__IO u32 *)(0X1FFFF7F0); // ���ֽ�
	ChipUniqueID[1] = *(__IO u32 *)(0X1FFFF7EC); // ���ֽ�
	ChipUniqueID[2] = *(__IO u32 *)(0X1FFFF7E8); // ���ֽ�
}



/*******************************************************************************
* Function Name  : GetChipProgramWord
* Description    : ��ȡоƬIDһ����.
* Input          : None             
* Output         : None
* Return         : IDһ����
*******************************************************************************/
uint32_t GetChipProgramWord(uint32_t registeraddress)
{
    uint32_t ChipProgramWord;
    
    if(registeraddress == CHIPIDHIGHBYTEREGISTERADDRESS)
    {
        ChipProgramWord = (*(__IO uint32_t *)(registeraddress)) ^ 0x01234567;
    }
    else if(registeraddress == CHIPIDMEDIUMBYTEREGISTERADDRESS)
    {
         ChipProgramWord = (*(__IO uint32_t *)(registeraddress)) ^ 0x89ABCDEF;
    }
    else if(registeraddress == CHIPIDLOWBYTEREGISTERADDRESS)
    {
         ChipProgramWord = (*(__IO uint32_t *)(registeraddress)) ^ 0x87654321;
    }
    else
    {
    
    }
    return ChipProgramWord; 
}





/*******************************************************************************
* Function Name  : WriteProgramWordtoFlash
* Description    : дһ���ֵ�flash.
* Input          : - address:Ҫд���flash��ַ   
*                  - data   ��Ҫд�������
* Output         : None
* Return         : None
*******************************************************************************/
void WriteProgramWordtoFlash(uint32_t address, uint32_t data)
{
    uint32_t eraseaddress;
    
    FLASH_Unlock( );
    if(address % FLASHPAGESIZE)
    {
        eraseaddress = address - address % FLASHPAGESIZE;
        FLASH_ErasePage(eraseaddress);
    }
    else
    {
        FLASH_ErasePage(address);
    }   
    FLASH_ProgramWord(address, data);
    FLASH_Lock( );
}


/*******************************************************************************
* Function Name  : ReadChipIDFromFlash
* Description    : ��flash�ж�ȡоƬID��һ����.
* Input          : - address:Ҫ��ȡ��flash��ַ   
* Output         : None
* Return         : None
*******************************************************************************/
void ChipEncryptionFunction(void)
{
    if(ReadProgramWordFromFlash(ENCRYPTFLAGADDRESSA) == 0xFFFFFFFF && ReadProgramWordFromFlash(ENCRYPTFLAGADDRESSB) == 0xFFFFFFFF)
    {
        uint32_t ChipUniqueID[3];
        /*��ȡоƬID*/
        GetChipID(ChipUniqueID);
        ChipUniqueID[0] ^= 0x01234567;
        ChipUniqueID[1] ^= 0x89ABCDEF;
        ChipUniqueID[2] ^= 0x87654321;
        /**********************��оƬIDд��Flash************************/
        WriteProgramWordtoFlash(CHIPIDHIGHBYTEADDRESS, ChipUniqueID[0]);
        WriteProgramWordtoFlash(CHIPIDMEDIUMBYTEADDRESS, ChipUniqueID[1]);
        WriteProgramWordtoFlash(CHIpIDLOWBYTEADDRESS, ChipUniqueID[2]);
        /***********************���Ϊ�Ѿ��Ϲ���************************/
        WriteProgramWordtoFlash(ENCRYPTFLAGADDRESSA, 0x12345678);
        WriteProgramWordtoFlash(ENCRYPTFLAGADDRESSB, 0x87654321); 
        printf("LINE--%d:Encryption success.\r\n",__LINE__);
    }
    else
    {
        if( (GetChipProgramWord(CHIPIDHIGHBYTEREGISTERADDRESS) != ReadProgramWordFromFlash(CHIPIDHIGHBYTEADDRESS))
            || (GetChipProgramWord(CHIPIDMEDIUMBYTEREGISTERADDRESS) != ReadProgramWordFromFlash(CHIPIDMEDIUMBYTEADDRESS))
            || (GetChipProgramWord(CHIPIDLOWBYTEREGISTERADDRESS) != ReadProgramWordFromFlash(CHIpIDLOWBYTEADDRESS)) )
        {
            printf("LINE--%d:GetChipProgramWord != ReadProgramWordFromFlash\r\n",__LINE__);
            while(1);
        }
        else
        {
            printf("LINE--%d:Decode success,0x%x,0x%x\r\n",__LINE__, 
            ReadProgramWordFromFlash(ENCRYPTFLAGADDRESSA), ReadProgramWordFromFlash(ENCRYPTFLAGADDRESSB));
        }               
    }
}



