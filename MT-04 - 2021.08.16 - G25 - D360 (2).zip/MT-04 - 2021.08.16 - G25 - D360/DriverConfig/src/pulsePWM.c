/******************************************************************************
* �ļ���  ��pulsePWM.c
* �ļ�������
* ������  ��Liu Tusheng
* ��    �գ�2016��2��29��
* 
* Ӳ�����ӣ�
*
******************************************************************************/
#include "pulsePWM.h"



void test(void);


void TIM1_config(u32 Cycle)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    TIM_OCInitTypeDef  TIM_OCInitStructure;
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA|RCC_APB2Periph_TIM1 , ENABLE); 

    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8;                   //TIM1_CH4 PA11
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;             //??????
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_Init(GPIOA, &GPIO_InitStructure);

    TIM_TimeBaseStructure.TIM_Period = Cycle-1;                                                   
    TIM_TimeBaseStructure.TIM_Prescaler =71;                    //??????TIMx???????????                                                     
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;     //??????:TDTS= Tck_tim            
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up; //TIM??????
    TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;            //????,???=0!!!
    TIM_TimeBaseInit(TIM1, &TIM_TimeBaseStructure);                                       

    TIM_OCInitStructure.TIM_OCMode = TIM_OCMode_PWM1;          //???????:TIM????????1       
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable; //??????
    TIM_OCInitStructure.TIM_Pulse = Cycle/2-1;                    //??????????????                                   
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_Low;      //????       

    TIM_OC1Init(TIM1, &TIM_OCInitStructure);                                                         

    TIM_SelectMasterSlaveMode(TIM1, TIM_MasterSlaveMode_Enable);
    TIM_SelectOutputTrigger(TIM1, TIM_TRGOSource_Update);
    

    TIM_OC1PreloadConfig(TIM1, TIM_OCPreload_Enable);                              
    TIM_ARRPreloadConfig(TIM1, ENABLE);
    
}
/***???2???***/
void TIM2_config(u32 PulseNum)
{
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    NVIC_InitTypeDef NVIC_InitStructure; 
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);

    TIM_TimeBaseStructure.TIM_Period = PulseNum-1;   
    TIM_TimeBaseStructure.TIM_Prescaler =0;    
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;     
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;  
    TIM_TimeBaseInit(TIM2, &TIM_TimeBaseStructure);  

    TIM_SelectInputTrigger(TIM2, TIM_TS_ITR0);
    //TIM_InternalClockConfig(TIM3);
    TIM2->SMCR|=0x07;                                  //???????? 
    //TIM_ITRxExternalClockConfig(TIM2, TIM_TS_ITR0);

    //TIM_ARRPreloadConfig(TIM3, ENABLE);         
    TIM_ITConfig(TIM2,TIM_IT_Update,DISABLE);

   // NVIC_PriorityGroupConfig(NVIC_PriorityGroup_3);
    NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;        
    NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 0;
    NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;     
    NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE; 
    NVIC_Init(&NVIC_InitStructure);
}



void Pulse_output(u32 Cycle,u32 PulseNum)
{
    TIM2_config(PulseNum);
    TIM_Cmd(TIM2, ENABLE);
    TIM_ClearITPendingBit(TIM2,TIM_IT_Update);
    TIM_ITConfig(TIM2,TIM_IT_Update,ENABLE);
    TIM1_config(Cycle);
    
    TIM_Cmd(TIM1, ENABLE);
    TIM_CtrlPWMOutputs(TIM1, ENABLE);   //??????????,?????
}


//void TIM2_IRQHandler(void) 
//{ 
//    if (TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)     // TIM_IT_CC1
//    { 
//        TIM_ClearITPendingBit(TIM2, TIM_IT_Update); // ??????? 
//        TIM_CtrlPWMOutputs(TIM1, DISABLE);  //?????
//        TIM_Cmd(TIM1, DISABLE); // ????? 
//        TIM_Cmd(TIM2, DISABLE); // ????? 
//        TIM_ITConfig(TIM2, TIM_IT_Update, DISABLE); 
//        
//    } 
//} 













/******************************************************************************
*������  ��TIM3_PWMModeConfig
*�������ܣ�TIM3 PWM��ʼ�������ڵ������
*��    ������
*����ֵ  ����
******************************************************************************/
void TIM4_Master__TIM3_Slave_Configuration(u32 PulseFrequency)
{
    GPIO_InitTypeDef GPIO_InitStructure;
    TIM_TimeBaseInitTypeDef TIM_TimeBaseStructure;
    TIM_OCInitTypeDef       TIM_OCInitStructure;
	NVIC_InitTypeDef NVIC_InitStructure;
    
	//	GPIO_InitTypeDef GPIO_InitStructure; 
  
    u16 nPDTemp ;
    /* -----------------------------------------------------------------------
    TIMx Configuration: generate 4 PWM signals with 4 different duty cycles:
    TIMxCLK = 72 MHz, Prescaler = 0x0, TIMx counter clock = 72 MHz
    TIMx ARR Register = 0 => TIMx Frequency = TIMx counter clock/(ARR + 1)
    TIMx Frequency = 72MHz.
    ----------------------------------------------------------------------- */
    
    //nPDTemp = 72000000UL/PulseFrequency;  
	nPDTemp = 10000; 
	
   RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4|RCC_APB1Periph_TIM3, ENABLE);  //��ʹ�ܶ�ʱ��4ʱ�� 
   RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB, ENABLE);  //ʹ��GPIO�����AFIO���ù���ģ��ʱ��ʹ��
	//GPIO_PinRemapConfig(GPIO_Remap_TIM4, ENABLE); //����ӳ�� TIM4_CH2->PB5      
   GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6|GPIO_Pin_7|GPIO_Pin_8|GPIO_Pin_9;             //TIM_CH2 
   GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AF_PP;//�����������
   GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz; 
   GPIO_Init(GPIOB, &GPIO_InitStructure);                //�ٳ�ʼ��GPIO 
  

    // ʱ�����ã�����PWM�����ʱ��----TIM4
    /* Time base configuration */
    TIM_TimeBaseStructure.TIM_Period= nPDTemp;
    TIM_TimeBaseStructure.TIM_Prescaler= 0;
    TIM_TimeBaseStructure.TIM_ClockDivision= 0;
    TIM_TimeBaseStructure.TIM_CounterMode= TIM_CounterMode_Up;
    TIM_TimeBaseStructure.TIM_RepetitionCounter= 0;
    TIM_TimeBaseInit(TIM4, &TIM_TimeBaseStructure);    
    //������ã�����PWM�����ʱ��
    /* PWM1 Mode configuration: Channel1 */
    TIM_OCInitStructure.TIM_OCMode= TIM_OCMode_PWM1;
    TIM_OCInitStructure.TIM_OCPolarity= TIM_OCPolarity_High;    
    TIM_OCInitStructure.TIM_OutputState= TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse= nPDTemp>>1;//50%

    TIM_OC1Init(TIM4, &TIM_OCInitStructure);
    TIM_OC1PreloadConfig(TIM4, TIM_OCPreload_Enable);
    TIM_OC2Init(TIM4, &TIM_OCInitStructure);
    TIM_OC2PreloadConfig(TIM4, TIM_OCPreload_Enable);
    TIM_OC3Init(TIM4, &TIM_OCInitStructure);
    TIM_OC3PreloadConfig(TIM4, TIM_OCPreload_Enable);
    TIM_OC4Init(TIM4, &TIM_OCInitStructure);
    TIM_OC4PreloadConfig(TIM4, TIM_OCPreload_Enable);

    //����TIM4Ϊ����ʱ��
    /* Select the Master Slave Mode */
    TIM_SelectMasterSlaveMode(TIM4, TIM_MasterSlaveMode_Enable);
    /* Master Mode selection */
    TIM_SelectOutputTrigger(TIM4, TIM_TRGOSource_Update);
    

// ʱ�����ã�������������Ĵ���-TIM3
    TIM_TimeBaseStructure.TIM_Period= 0xFFFF;
    TIM_TimeBaseStructure.TIM_Prescaler= 0;
    TIM_TimeBaseStructure.TIM_ClockDivision= 0;
    TIM_TimeBaseStructure.TIM_CounterMode= TIM_CounterMode_Up;
    TIM_TimeBaseStructure.TIM_RepetitionCounter = 0;
    TIM_TimeBaseInit(TIM3, &TIM_TimeBaseStructure);    
    
        //����TIM3Ϊ�Ӷ�ʱ��
    /* Slave Mode selection: TIM3 */
    TIM_SelectInputTrigger(TIM3, TIM_TS_ITR3);
    TIM_SelectSlaveMode(TIM3, TIM_SlaveMode_External1);
    
    
    /* Output Compare Active Mode configuration: Channel1 */
    TIM_OCInitStructure.TIM_OCMode= TIM_OCMode_Inactive;
    TIM_OCInitStructure.TIM_OCPolarity = TIM_OCPolarity_High;
    TIM_OCInitStructure.TIM_OutputState = TIM_OutputState_Enable;
    TIM_OCInitStructure.TIM_Pulse = 0xFFFF;   // �����������岻��
    
    TIM_OC1Init(TIM3, &TIM_OCInitStructure);
    TIM_OC2Init(TIM3, &TIM_OCInitStructure);
	TIM_OC3Init(TIM3, &TIM_OCInitStructure);
	TIM_OC4Init(TIM3, &TIM_OCInitStructure);

    TIM_ClearITPendingBit( TIM3, TIM_IT_CC1|TIM_IT_CC2|TIM_IT_CC3|TIM_IT_CC4 ); 
    NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;   
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;   
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;   
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;  
	NVIC_Init(&NVIC_InitStructure);   

    TIM_ITConfig(TIM3, TIM_IT_CC1|TIM_IT_CC2|TIM_IT_CC3|TIM_IT_CC4, ENABLE);
    
    TIM3->CCR1  = 10000;
    TIM3->CCR2  = 20000;
    TIM3->CCR3  = 30000;
    TIM3->CCR4  = 40000;
    
    TIM3->CNT   = 0;
    
    TIM_Cmd(TIM4, ENABLE);
    TIM_Cmd(TIM3, ENABLE);
}

#if 0

//�жϷ���������£�
u8  TIM4_Pulse_TIM3_Counter_OK = 0;
void TIM3_IRQHandler(void)
{
    if (TIM_GetITStatus(TIM3, TIM_IT_CC1) != RESET)
    {
        TIM_ClearITPendingBit(TIM3, TIM_IT_CC1); //����жϱ�־λ
        TIM3->CCR1  = 0;
        TIM_Cmd(TIM4, DISABLE); //�رն�ʱ��
        TIM_Cmd(TIM3, DISABLE); //�رն�ʱ��
        
        TIM4_Pulse_TIM3_Counter_OK = 1;
    }
    if (TIM_GetITStatus(TIM3, TIM_IT_CC2) != RESET)
    {
        TIM_ClearITPendingBit(TIM3, TIM_IT_CC2); //����жϱ�־λ
         TIM3->CCR2  = 0;
//        TIM_Cmd(TIM4, DISABLE); //�رն�ʱ��
//        TIM_Cmd(TIM3, DISABLE); //�رն�ʱ��
        
        TIM4_Pulse_TIM3_Counter_OK = 1;
    }
    if (TIM_GetITStatus(TIM3, TIM_IT_CC2) != RESET)
    {
        TIM_ClearITPendingBit(TIM3, TIM_IT_CC2); //����жϱ�־λ
        
//        TIM_Cmd(TIM4, DISABLE); //�رն�ʱ��
//        TIM_Cmd(TIM3, DISABLE); //�رն�ʱ��
        
        TIM4_Pulse_TIM3_Counter_OK = 1;
    }
    
    if (TIM_GetITStatus(TIM3, TIM_IT_CC4) != RESET)
    {
        TIM_ClearITPendingBit(TIM3, TIM_IT_CC4); //����жϱ�־λ
        
//        TIM_Cmd(TIM4, DISABLE); //�رն�ʱ��
//        TIM_Cmd(TIM3, DISABLE); //�رն�ʱ��
        
        TIM4_Pulse_TIM3_Counter_OK = 1;
    }
}


#endif


void test( void )
{
    while( 1 )
    {
        TIM_ITConfig(TIM3, TIM_IT_CC1, DISABLE); /* TIM enable counter */
        TIM_Cmd(TIM3, ENABLE);
        TIM3->CCR1  = 10000;
        TIM3->CNT   = 0;
        TIM_ITConfig(TIM3, TIM_IT_CC1, ENABLE);
        TIM_Cmd(TIM4, ENABLE);   /* TIM enable counter */ 
//        while(TIM4_Pulse_TIM3_Counter_OK  == 0);
    }
     
}