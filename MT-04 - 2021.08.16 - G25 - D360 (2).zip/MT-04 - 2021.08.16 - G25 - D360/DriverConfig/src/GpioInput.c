/******************************************************************************
* �ļ���  ��IoInput.c
* �ļ�����:
* ������  ��Liu Tusheng
* ��    �գ�2016��2��29��
* Ӳ�����ӣ�
* 
******************************************************************************/
#include "GpioInput.h"

extern robotMotionPostrue robotMotion;

static void prvRobotGpioInputInitalize( void );
static void prvCanIDInitalize( void );


/*******************************************************************************
* Function Name  : vAllIoInputConfig
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void vAllIoInputConfig( void )
{

//    prvLimitSwitchInitalize(  );

    prvRobotGpioInputInitalize(  );
}






/*******************************************************************************
* Function Name  : prvLimitSwitchInitalize
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
static void prvRobotGpioInputInitalize( void )
{
    GPIO_InitTypeDef      GPIO_InitStructure;
        
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB|RCC_APB2Periph_GPIOC|RCC_APB2Periph_GPIOD, ENABLE );
        /* Release PA15 PB3 PB4 */
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_AFIO, ENABLE ); 
	GPIO_PinRemapConfig( GPIO_Remap_SWJ_JTAGDisable, ENABLE );  
                 
    GPIO_InitStructure.GPIO_Pin = FrontLeftALMCheckPin; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;	
	GPIO_Init( FrontLeftALMCheckPort, &GPIO_InitStructure ); 
    
    GPIO_InitStructure.GPIO_Pin = FrontRightALMCheckPin; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;	
	GPIO_Init( FrontRightALMCheckPort, &GPIO_InitStructure ); 
    
    GPIO_InitStructure.GPIO_Pin = BehindLeftALMCheckPin; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;	
	GPIO_Init( BehindLeftALMCheckPort, &GPIO_InitStructure ); 
    
    GPIO_InitStructure.GPIO_Pin = BehindRightALMCheckPin; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;	
	GPIO_Init( BehindRightALMCheckPort, &GPIO_InitStructure ); 
    
    GPIO_InitStructure.GPIO_Pin = RobotStopCheckPin; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;	
	GPIO_Init( RobotStopCheckPort, &GPIO_InitStructure ); 
    
    GPIO_InitStructure.GPIO_Pin = FrontTouchCheckPin; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;	
	GPIO_Init( FrontTouchCheckPort, &GPIO_InitStructure ); 
    
    GPIO_InitStructure.GPIO_Pin = BehindTouchCheckPin; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;	
	GPIO_Init( BehindTouchCheckPort, &GPIO_InitStructure ); 
    
    GPIO_InitStructure.GPIO_Pin = LimitSwitchCheckPin; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;	
	GPIO_Init( LimitSwitchCheckPort, &GPIO_InitStructure ); 
    
}




/*******************************************************************************
* Function Name  : prvCanIDInitalize
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
static bool frontCrash = false, behindCrash = false;
void gpioInputCheck( void )
{
    
    static TickType_t frontCrashTime = 0, behindCrashTime = 0;
    
    static Flag_Filter_Type FTouch_Filter , BTouch_Filter;
    
    static uint8_t FTouch = 0 , BTouch = 0;
    
    
    FTouch = Flag_Filter(&FTouch_Filter , inputFrontTouchCheck(  ) , 10);
    BTouch = Flag_Filter(&BTouch_Filter , inputBehindTouchCheck(  ) , 10);
    
//    if( inputFrontLeftALMCheck(  ) == Bit_RESET )
//    {
//        robotMotion.frontLeftWheelError = BitReset;
//    }
//    else
//    {
//       robotMotion.frontLeftWheelError = BitSet;
//    }
    
    if( inputFrontRightALMCheck(  ) == Bit_SET )
    {
        robotMotion.frontRightWheelError = BitReset;
    }
    else
    {
        robotMotion.frontRightWheelError = BitSet;
    }
    
    if( inputBehindLeftALMCheck(  ) == Bit_SET )
    {
        robotMotion.behindLeftWheelError = BitReset;
    }
    else
    {
        robotMotion.behindLeftWheelError = BitSet;
    }
    
    if( inputBehindRightALMCheck(  ) == Bit_SET )
    {
        robotMotion.behindRightWheelError = BitReset;
    }
    else
    {
       robotMotion.behindRightWheelError = BitSet;
    }
    
    if( inputRobotStopCheck(  ) == Bit_SET )
    {
        robotMotion.scram = BitSet;
        robotMotion.robotVelocity = 0;
        robotMotion.speed = 0;
        robotMotion.robotAckermanAngle = 0;
//        robotMotion.robotVelocityLeft = 0;
//        robotMotion.robotVelocityRight = 0;
//        MecanumChassisSetPoint.behindLeftWheelSpeed = 0;
//        MecanumChassisSetPoint.behindRightWheelSpeed = 0;
        
        robotMotion.frontCrash = BitReset;
        robotMotion.behindCrash = BitReset;
        frontCrash = false;
        behindCrash = false;
//        outBehindLeftWheelStop(  );
//        outBehindRightWheelStop(  );
    }
    else
    {
        robotMotion.scram = BitReset;
    }

    //��ײ����
    if( (frontCrash == false) && (FTouch == Bit_RESET) && robotMotion.speed > 0)  //ǰ���ߴ���
    {
        robotMotion.frontCrash = BitSet;
//        robotMotion.robotAckermanAngle = 0;
        robotMotion.robotVelocity = 0;
        robotMotion.speed = 0;
        motorSetBehindLeftWheelSpeed(0);  
        motorSetBehindRightWheelSpeed(0);
    }
    else if( (frontCrash == true) && ( SingleTimeoutCheck( frontCrashTime, 1500 ) == TimeOut ) )
    {
//        robotMotion.frontCrash = BitReset;
        robotMotion.robotVelocity = 0;
        robotMotion.speed = 0;
        motorSetBehindLeftWheelSpeed(0);  
        motorSetBehindRightWheelSpeed(0);
    }
    else if( (frontCrash == false) && robotMotion.frontCrash == BitSet )  //ң��������λ���ٶ������ٶ�Ϊ0
    {
        
        frontCrashTime = GetOSRunTimeNow(  );
        frontCrash = true;
        motorSetBehindLeftWheelSpeed(0);  //-200
        motorSetBehindRightWheelSpeed(0); //-200
    }
   
    
    if( (behindCrash == false) && (BTouch == Bit_RESET) && robotMotion.speed < 0 ) 
    {
        robotMotion.behindCrash = BitSet;
//        robotMotion.robotAckermanAngle = 0;
        robotMotion.robotVelocity = 0;
        robotMotion.speed = 0;
        motorSetBehindLeftWheelSpeed(0);
        motorSetBehindRightWheelSpeed(0);
    }
    else if( (behindCrash == true) && ( SingleTimeoutCheck( behindCrashTime, 1500 ) == TimeOut ) )
    {
//        robotMotion.behindCrash = BitReset;
        robotMotion.robotVelocity = 0;
        robotMotion.speed = 0;
        motorSetBehindLeftWheelSpeed(0);  
        motorSetBehindRightWheelSpeed(0);
    }
    else if( (behindCrash == false) && (robotMotion.behindCrash == BitSet))  //ң��������λ���ٶ������ٶ�Ϊ0
    {
        behindCrash = true;
        behindCrashTime = GetOSRunTimeNow(  );
        motorSetBehindLeftWheelSpeed(0);  //200
        motorSetBehindRightWheelSpeed(0); //200
    }

}

void Clear_Crash_Flag(void)
{
    robotMotion.frontCrash = BitReset;
    robotMotion.behindCrash = BitReset;
    frontCrash = false;
    behindCrash = false;
}






