/**********************************************************************************
 * Filename   ��GpioOut.c
 * Author     : Liu Tusheng       
 * Version    : 1.0
 * Date       : 2017.12.7
 * Discription : MCU gpio out driver config
 * hardware connect:
**********************************************************************************/
#include "GpioOut.h"




static void svMotorContrlGpioOutputConfig( void );




/*******************************************************************************
* Function Name  : 
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void vAllIoOutputConfig( void )
{
    svMotorContrlGpioOutputConfig(  );
//    prvMotorContrlInitalize(  );
    
    
}



/*******************************************************************************
* Function Name  : svMotorContrlGpioOutputConfig
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
static void svMotorContrlGpioOutputConfig( void )
{
    GPIO_InitTypeDef GPIO_InitStructure;
	
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOA|RCC_APB2Periph_GPIOB|RCC_APB2Periph_GPIOC|RCC_APB2Periph_GPIOD, ENABLE );
        /* Release PA15 PB3 PB4 */
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_AFIO, ENABLE ); 
	GPIO_PinRemapConfig( GPIO_Remap_SWJ_JTAGDisable, ENABLE );  
    
    /**************************front left wheel************************************/
//    GPIO_InitStructure.GPIO_Pin = FrontLeftForwardRetreatPin; 
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
//	GPIO_Init( FrontLeftForwardRetreatPort, &GPIO_InitStructure );
//    
//    GPIO_InitStructure.GPIO_Pin = FrontLeftEnablePin; 
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
//	GPIO_Init( FrontLeftEnablePort, &GPIO_InitStructure );
//    
//    GPIO_InitStructure.GPIO_Pin = FrontLeftBreakPin; 
//	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
//	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_OD;
//	GPIO_Init( FrontLeftBreakPort, &GPIO_InitStructure );
    
    /**************************front right wheel************************************/
    GPIO_InitStructure.GPIO_Pin = FrontRightForwardRetreatPin; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init( FrontRightForwardRetreatPort, &GPIO_InitStructure );
    
    GPIO_InitStructure.GPIO_Pin = FrontRightEnablePin; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init( FrontRightEnablePort, &GPIO_InitStructure );
    
    GPIO_InitStructure.GPIO_Pin = FrontRightBreakPin; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init( FrontRightBreakPort, &GPIO_InitStructure );
    
    /**************************behind left wheel************************************/
    GPIO_InitStructure.GPIO_Pin = BehindLeftForwardRetreatPin; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init( BehindLeftForwardRetreatPort, &GPIO_InitStructure );
    
    GPIO_InitStructure.GPIO_Pin = BehindLeftEnablePin; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init( BehindLeftEnablePort, &GPIO_InitStructure );
    
    GPIO_InitStructure.GPIO_Pin = BehindLeftBreakPin; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init( BehindLeftBreakPort, &GPIO_InitStructure );
    
    /**************************behind right wheel************************************/
    GPIO_InitStructure.GPIO_Pin = BehindRightForwardRetreatPin; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init( BehindRightForwardRetreatPort, &GPIO_InitStructure );
    
    GPIO_InitStructure.GPIO_Pin = BehindRightEnablePin; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init( BehindRightEnablePort, &GPIO_InitStructure );
    
    GPIO_InitStructure.GPIO_Pin = BehindRightBreakPin; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init( BehindRightBreakPort, &GPIO_InitStructure );
    
    GPIO_InitStructure.GPIO_Pin = BuzzerContrlPin; 
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_Init( BuzzerContrlPort, &GPIO_InitStructure );
    
//    outFrontLeftWheelStop(  );
    outFrontRightWheelStop(  );
    outBehindLeftWheelStop(  );
    outBehindRightWheelStop(  );
    outBuzzerON(  );
}





