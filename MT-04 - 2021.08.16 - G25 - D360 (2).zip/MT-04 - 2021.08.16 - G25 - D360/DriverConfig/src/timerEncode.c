/**********************************************************************************
 * Filename   ��timerEcode.c
 * Author     : Liu Tusheng       
 * Version    : 1.0
 * Date       : 2019.5.23
 * Discription : 
 * Hardware Connet:
**********************************************************************************/ 
#include "timerEncode.h"

Encode TimerEmcode = {0};




/*******************************************************************************
* Function Name  : Timer1EncoderInitialize
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void Timer1EncoderInitialize( void )  
{  
          
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;  
    TIM_ICInitTypeDef TIM_ICInitStructure;  
    NVIC_InitTypeDef NVIC_InitStructure;
    
    GPIO_InitTypeDef GPIO_InitStructure;  
    //NVIC_InitTypeDef NVIC_InitStructure;
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_TIM1, ENABLE );//??TIM1??
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOA, ENABLE );//??GPIOA??

    GPIO_StructInit( &GPIO_InitStructure );  
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9;  
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;//PA8 PA9????
    GPIO_Init( GPIOA, &GPIO_InitStructure );  
    
    TIM_DeInit( TIM1 );  
    TIM_TimeBaseStructInit( &TIM_TimeBaseStructure );  
    TIM_TimeBaseStructure.TIM_Prescaler = 0x0;  // No prescaling 
    TIM_TimeBaseStructure.TIM_Period = 0xFFFF;  
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;//?????? T_dts = T_ck_int 
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;   //TIM????
    TIM_TimeBaseInit( TIM1, &TIM_TimeBaseStructure);  
    TIM_EncoderInterfaceConfig( TIM1, TIM_EncoderMode_TI12, TIM_ICPolarity_Rising, TIM_ICPolarity_Rising );//???????3
    TIM_ICStructInit(&TIM_ICInitStructure);  
    TIM_ICInitStructure.TIM_ICFilter =0x08;//?????????
    TIM_ICInit( TIM1, &TIM_ICInitStructure);  
    
    TIM_ClearITPendingBit( TIM1, TIM_IT_Update );  
    TIM_ITConfig( TIM1, TIM_IT_Update, ENABLE ); 
	NVIC_InitStructure.NVIC_IRQChannel = TIM1_UP_IRQn;   
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;   
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;   
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;  
	NVIC_Init(&NVIC_InitStructure);   
    
    //Reset counter
    TIM1->CNT = 0;  
    //CurrentCount = TIM1->CNT;
    TIM_Cmd( TIM1, ENABLE);  
    TimerEmcode.frontLeftUpdateFlag = false;
    
}  



/*******************************************************************************
* Function Name  : Timer1EncoderInitialize
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void Timer2EncoderInitialize( void )  
{  
          
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;  
    TIM_ICInitTypeDef TIM_ICInitStructure;  
    NVIC_InitTypeDef NVIC_InitStructure;
    
    GPIO_InitTypeDef GPIO_InitStructure;  
    //NVIC_InitTypeDef NVIC_InitStructure;
    RCC_APB1PeriphClockCmd( RCC_APB1Periph_TIM2, ENABLE );//??TIM1??
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOA, ENABLE );//??GPIOA??

    GPIO_StructInit( &GPIO_InitStructure );  
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;  
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;//PA8 PA9????
    GPIO_Init( GPIOA, &GPIO_InitStructure );  
    
    TIM_DeInit( TIM2 );  
    TIM_TimeBaseStructInit( &TIM_TimeBaseStructure );  
    TIM_TimeBaseStructure.TIM_Prescaler = 0x0;  // No prescaling 
    TIM_TimeBaseStructure.TIM_Period = 0xFFFF;  
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;//?????? T_dts = T_ck_int 
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;   //TIM????
    TIM_TimeBaseInit( TIM2, &TIM_TimeBaseStructure);  
    TIM_EncoderInterfaceConfig( TIM2, TIM_EncoderMode_TI12, TIM_ICPolarity_Rising, TIM_ICPolarity_Rising );//???????3
    TIM_ICStructInit(&TIM_ICInitStructure);  
    TIM_ICInitStructure.TIM_ICFilter =0x05;//?????????
    TIM_ICInit( TIM2, &TIM_ICInitStructure);  
    
    TIM_ClearITPendingBit( TIM2, TIM_IT_Update );  
    TIM_ITConfig( TIM2, TIM_IT_Update, ENABLE ); 
	NVIC_InitStructure.NVIC_IRQChannel = TIM2_IRQn;   
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;   
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;   
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;  
	NVIC_Init(&NVIC_InitStructure);   
    
    //Reset counter
    TIM2->CNT = 0;  
    //CurrentCount = TIM1->CNT;
    TIM_Cmd( TIM2, ENABLE);  
    
    TimerEmcode.behindRightUpdateFlag = false;
    
}  


/*******************************************************************************
* Function Name  : Timer1EncoderInitialize
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void Timer3EncoderInitialize( void )  
{  
          
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;  
    TIM_ICInitTypeDef TIM_ICInitStructure;  
    NVIC_InitTypeDef NVIC_InitStructure;
    
    GPIO_InitTypeDef GPIO_InitStructure;  
    //NVIC_InitTypeDef NVIC_InitStructure;
    RCC_APB1PeriphClockCmd( RCC_APB1Periph_TIM3, ENABLE );//??TIM1??
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOA, ENABLE );//??GPIOA??

    GPIO_StructInit( &GPIO_InitStructure );  
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;  
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;//PA8 PA9????
    GPIO_Init( GPIOA, &GPIO_InitStructure );  
    
    TIM_DeInit( TIM3 );  
    TIM_TimeBaseStructInit( &TIM_TimeBaseStructure );  
    TIM_TimeBaseStructure.TIM_Prescaler = 0x0;  // No prescaling 
    TIM_TimeBaseStructure.TIM_Period = 0xFFFF;  
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;//?????? T_dts = T_ck_int 
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;   //TIM????
    TIM_TimeBaseInit( TIM3, &TIM_TimeBaseStructure);  
    TIM_EncoderInterfaceConfig( TIM3, TIM_EncoderMode_TI12, TIM_ICPolarity_Rising, TIM_ICPolarity_Rising );//???????3
    TIM_ICStructInit(&TIM_ICInitStructure);  
    TIM_ICInitStructure.TIM_ICFilter =0x05;//?????????
    TIM_ICInit( TIM3, &TIM_ICInitStructure);  
    
    TIM_ClearITPendingBit( TIM3, TIM_IT_Update ); 
    TIM_ITConfig( TIM3, TIM_IT_Update, ENABLE ); 
	NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;   
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;   
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;   
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;  
	NVIC_Init(&NVIC_InitStructure);   
    
    TIM3->CNT = 0;  
    //CurrentCount = TIM1->CNT;
    TIM_Cmd( TIM3, ENABLE);  
    
    TimerEmcode.behindLeftUpdateFlag = false;
    
}  




/*******************************************************************************
* Function Name  : Timer1EncoderInitialize
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void Timer4EncoderInitialize( void )  
{  
          
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;  
    TIM_ICInitTypeDef TIM_ICInitStructure;  
    NVIC_InitTypeDef NVIC_InitStructure;
    
    GPIO_InitTypeDef GPIO_InitStructure;  
    //NVIC_InitTypeDef NVIC_InitStructure;
    RCC_APB1PeriphClockCmd( RCC_APB1Periph_TIM4, ENABLE );//??TIM1??
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOB, ENABLE );//??GPIOA??

    GPIO_StructInit( &GPIO_InitStructure );  
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;  
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPD;//PA8 PA9????
    GPIO_Init( GPIOB, &GPIO_InitStructure );  
    
    TIM_DeInit( TIM4 );  
    TIM_TimeBaseStructInit( &TIM_TimeBaseStructure );  
    TIM_TimeBaseStructure.TIM_Prescaler = 0x0;  // No prescaling 
    TIM_TimeBaseStructure.TIM_Period = 0xFFFF;  
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;//?????? T_dts = T_ck_int 
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;   //TIM????
    TIM_TimeBaseInit( TIM4, &TIM_TimeBaseStructure);  
    TIM_EncoderInterfaceConfig( TIM4, TIM_EncoderMode_TI12, TIM_ICPolarity_Rising, TIM_ICPolarity_Rising );//???????3
    TIM_ICStructInit(&TIM_ICInitStructure);  
    TIM_ICInitStructure.TIM_ICFilter =0x05;//?????????
    TIM_ICInit( TIM4, &TIM_ICInitStructure);  
    
    TIM_ClearITPendingBit( TIM4, TIM_IT_Update ); 
    TIM_ITConfig( TIM4, TIM_IT_Update, ENABLE ); 
	NVIC_InitStructure.NVIC_IRQChannel = TIM4_IRQn;   
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;   
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;   
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;  
	NVIC_Init(&NVIC_InitStructure);   
    
    TIM4->CNT = 0;  
    //CurrentCount = TIM1->CNT;
    TIM_Cmd( TIM4, ENABLE);  
    
    TimerEmcode.frontRightUpdateFlag = false;
    
}  

uint16_t testConunt = 0;

/*******************************************************************************
* Function Name  : TIM1_UP_IRQHandler
* Description    : TIM1 �����жϷ�����
*******************************************************************************/
void TIM1_UP_IRQHandler( void )
{
    taskENTER_CRITICAL(  );
    
    if( TIM_GetITStatus( TIM1, TIM_IT_Update ) != RESET )
    {
        TimerEmcode.frontLeftUpdateFlag = true;
    }
    TIM_ClearITPendingBit( TIM1, TIM_IT_Update ); 
    
    taskEXIT_CRITICAL(  );
}

#if 1

/*******************************************************************************
* Function Name  : TIM2_IRQHandler
* Description    : TIM2 �����жϷ�����
*******************************************************************************/
void TIM2_IRQHandler( void )
{
    taskENTER_CRITICAL(  );
    
    if( TIM_GetITStatus( TIM2, TIM_IT_Update ) != RESET )
    {
        TimerEmcode.behindRightUpdateFlag = true;
    }
    TIM_ClearITPendingBit( TIM2, TIM_IT_Update ); 
    
    taskEXIT_CRITICAL(  );
}



/*******************************************************************************
* Function Name  : TIM3_IRQHandler
* Description    : TIM3 �����жϷ�����
*******************************************************************************/
void TIM3_IRQHandler( void )
{
    taskENTER_CRITICAL(  );
    
    if( TIM_GetITStatus( TIM3, TIM_IT_Update ) != RESET )
    {
        TimerEmcode.behindLeftUpdateFlag = true;
    }
    TIM_ClearITPendingBit( TIM3, TIM_IT_Update ); 
    
    taskEXIT_CRITICAL(  );
}

#endif

/*******************************************************************************
* Function Name  : TIM1_CC_IRQHandler
* Description    : TIM1 �����жϷ�����
*******************************************************************************/
void TIM4_IRQHandler( void )
{
    taskENTER_CRITICAL(  );
    
    if( TIM_GetITStatus( TIM4, TIM_IT_Update ) != RESET )
    {
        TimerEmcode.frontRightUpdateFlag = true;
    }
    TIM_ClearITPendingBit( TIM4, TIM_IT_Update ); 
    
    taskEXIT_CRITICAL(  );
}