/**********************************************************************************
 * Filename   ��flash.c
 * Author     : Liu Tusheng       
 * Version    : 1.0
 * Date       : 2015.10.24
 *Discription : 
**********************************************************************************/ 

#include "flash.h" 


//uint32_t FlashAddressAddress  __attribute__ ((at(FLASH_DATA_BASE_ADDRESS)));// = USERDATAADDRESS;//���ݴ洢��ַ�ĵ�ַ,����ڵ�һ����ַ��




/*******************************************************************************
* Function Name  : ReadProgramWordBufferFromFlash
* Description    : Read flash data
* Input          : None
* Output         : None
* Return         : flash data
*******************************************************************************/
uint32_t ReadProgramWordFromFlash( uint32_t address )
{  
	  //��ȡ�û�����
    return  (uint32_t )(*(uint32_t *)address);
}



/*******************************************************************************
* Function Name  : ReadSTM32FlashData
* Description    : Read flash data
* Input          : None
* Output         : None
* Return         : flash data
*******************************************************************************/
void ReadProgramWordBufferFromFlash( uint32_t address, uint32_t buffer[ ], int length )
{
    int i;
    uint32_t Address = address;
    
    for( i=0;i<length;i++ )
    {
        buffer[i] = ReadProgramWordFromFlash( Address );
        Address += 4;
    }
    
}



/*******************************************************************************
* Function Name  : ReadProgramHalfWordDataFromSTM32Flash
* Description    : Read flash data
* Input          : None
* Output         : None
* Return         : flash data
*******************************************************************************/
uint16_t ReadProgramHalfWordDataFromSTM32Flash( uint32_t address )
{
    //��ȡ�û�����
    return  (uint16_t)(*(uint32_t *)address);
    
}



/*******************************************************************************
* Function Name  : ReadBufferFromSTM32Flash
* Description    : 
* Input          : None
* Output         : None
* Return         : 
*******************************************************************************/
void ReadProgramOptionByteBufferFromSTM32Flash( uint32_t address,uint8_t buffer[], uint8_t length )
{  
    uint8_t i;
    
    for( i=0;i<length;i++ )
    {
        buffer[i] = (uint8_t)( *(uint32_t *)(address+i) );
    }
    
}





/*******************************************************************************
* Function Name  : WriteProgramWordDataToSTM32Flash
* Description    : 
* Input          : None
* Output         : None
* Return         : flash data
*******************************************************************************/
void WriteProgramWordDataToSTM32Flash( uint32_t address, uint32_t data )
{
    
    if( address < STM32_FLASH_BASE_ADDRESS )
    {
        return;
    }
    FLASH_Unlock(  );					//���� 
   
    if( (address % STM32_FLASH_PAGE_SIZE) == 0 ) 
    {
        FLASH_ErasePage(address);
        
    }
    FLASH_ProgramWord( address, data );
    FLASH_Lock(  );						//����
}







