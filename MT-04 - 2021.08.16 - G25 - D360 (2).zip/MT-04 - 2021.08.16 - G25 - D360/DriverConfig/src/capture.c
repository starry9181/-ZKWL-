/******************************************************************************
* �ļ���  ��pwm.c
* �ļ�������
* ������  ��Liu Tusheng
* ��    �գ�2016��2��29��
* 
* Ӳ�����ӣ�
 TIM output pwm control:
 *          ----------------------------------------- 
 *         | PA8-TIM1-Channel_1:      ���ֱ��벶��   |
 *         | PA11-TIM1-Channel_4 :    ���ֱ��벶��   |
 *         | PC6-TIM8-Channel_1:      ��Ѱ�����     |
 *         | PC7-TIM8-Channel_2:      ����Ѱ�����   |
 *         | PC8-TIM8-Channel_3:      ����Ѱ�����   |
 *         | PC9-TIM8-Channel_4:      ��Ѱ�����     |
 *          -----------------------------------------
*
******************************************************************************/
#include "capture.h"




TimCapture TimCapture1 = {0},TimCapture2 = {0},TimCapture3 = {0},TimCapture4 = {0},TimCapture5 = {0},TimCapture6 = {0},
        TimCapture7 = {0},TimCapture8 = {0},TimCapture9 = {0},TimCapture10 = {0},TimCapture11 = {0},TimCapture12 = {0}; 

ultrasonic Ultrasonic1, Ultrasonic2, Ultrasonic3, Ultrasonic4, Ultrasonic5, Ultrasonic6,
        Ultrasonic7, Ultrasonic8, Ultrasonic9, Ultrasonic10, Ultrasonic11, Ultrasonic12;

SystemUltrasonic systemUltrasonic = {0}; 
        
static void TIM3CaptureInit( u16 Period, u16 Prescaler );
static void TIM4CaptureInit( u16 Period, u16 Prescaler );
static void TIM5CaptureInit( u16 Period, u16 Prescaler );
static void TIM8CaptureInit( u16 Period, u16 Prescaler );
//void DoubleEdgeTim3Capture( void );
//void DoubleEdgeTim4Capture( void );


/*******************************************************************************
* Function Name  : vAllTimCaptureInit
* Description    : ϵͳ���ж�ʱ�������ʼ��
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void vAllTimCaptureInit( void )
{
//    TIM3CaptureInit( CapturePeriod, 71 );
//    TIM4CaptureInit( CapturePeriod, 71 );
//    TIM5CaptureInit( CapturePeriod, 71 );
//    TIM8CaptureInit( CapturePeriod, 71 );
}



/*******************************************************************************
* Function Name  : ShotintBufferCopy
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
bool ShotintBufferCopy( uint16_t *pTarget, uint16_t *pSource, uint8_t length )
{
    uint8_t i;
    
    for( i=0;i<length;i++ )
    {
        pTarget[i] = pSource[i];
    }
    
    return true;
    
}

/*******************************************************************************
* Function Name  : CalculateDistance
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
bool CalculateDistance( void )
{
#define ULTRASONIC_TIME  1000
    uint16_t AverageTime = 0,i;
    static TickType_t UltrasonicTime = 0;
    uint16_t buffer[UCAPTURE_BUFFER_SIZE];
	uint16_t LeftUltrasonic = 0xFFFF,CentreUltrasonic = 0xFFFF,RightUltrasonic = 0xFFFF;
    
    for( i=0;i<UCAPTURE_BUFFER_SIZE;i++ )
    {
//        Ultrasonic1.Buffer[i] = TimCapture1.Buffer[i];
//        Ultrasonic2.Buffer[i] = TimCapture2.Buffer[i];
//        Ultrasonic3.Buffer[i] = TimCapture3.Buffer[i];
//        Ultrasonic4.Buffer[i] = TimCapture4.Buffer[i];
//        Ultrasonic5.Buffer[i] = TimCapture5.Buffer[i];
//        Ultrasonic6.Buffer[i] = TimCapture6.Buffer[i];
//        Ultrasonic7.Buffer[i] = TimCapture7.Buffer[i];
//        Ultrasonic8.Buffer[i] = TimCapture8.Buffer[i];
        Ultrasonic9.Buffer[i] = TimCapture9.Buffer[i];
        Ultrasonic10.Buffer[i] = TimCapture10.Buffer[i];
        Ultrasonic11.Buffer[i] = TimCapture11.Buffer[i];
        Ultrasonic12.Buffer[i] = TimCapture12.Buffer[i];
    }
//    Ultrasonic1.Sum = 0;
//    Ultrasonic2.Sum = 0;
//    Ultrasonic3.Sum = 0;
//    Ultrasonic4.Sum = 0;
//    Ultrasonic5.Sum = 0;
//    Ultrasonic6.Sum = 0;
//    Ultrasonic7.Sum = 0;
//    Ultrasonic8.Sum = 0;
    Ultrasonic9.Sum = 0;
    Ultrasonic10.Sum = 0;
    Ultrasonic11.Sum = 0;
    Ultrasonic12.Sum = 0;

    for( i=0;i<UCAPTURE_BUFFER_SIZE;i++ )
    {
//        Ultrasonic1.Sum += Ultrasonic1.Buffer[i];
//		Ultrasonic2.Sum += Ultrasonic2.Buffer[i];
//        Ultrasonic3.Sum += Ultrasonic3.Buffer[i];
//        Ultrasonic4.Sum += Ultrasonic4.Buffer[i];
//        Ultrasonic5.Sum += Ultrasonic5.Buffer[i];
//        Ultrasonic6.Sum += Ultrasonic6.Buffer[i];     
//        Ultrasonic7.Sum += Ultrasonic7.Buffer[i];
//		Ultrasonic8.Sum += Ultrasonic8.Buffer[i];
        Ultrasonic9.Sum += Ultrasonic9.Buffer[i];
        Ultrasonic10.Sum += Ultrasonic10.Buffer[i];
        Ultrasonic11.Sum += Ultrasonic11.Buffer[i];
        Ultrasonic12.Sum += Ultrasonic12.Buffer[i];     
    }
    
//    AverageTime = Ultrasonic1.Sum/UCAPTURE_BUFFER_SIZE;
//    if( SingleTimeoutCheck( TimCapture1.Time, ULTRASONIC_TIME ) == TimeOut )
//    {
//        Ultrasonic1.Distance = 0xFFFF;
//    }
//    else
//    {
//        Ultrasonic1.Distance = AverageTime/58;
//        if( Ultrasonic1.Distance<RightUltrasonic ) RightUltrasonic = Ultrasonic1.Distance;
//    }

//    AverageTime = Ultrasonic2.Sum/UCAPTURE_BUFFER_SIZE;
//	if( SingleTimeoutCheck( TimCapture2.Time, ULTRASONIC_TIME ) == TimeOut )
//    {
//        Ultrasonic2.Distance = 0xFFFF;
//    }
//    else
//    {
//        Ultrasonic2.Distance = AverageTime/58;
//        if( Ultrasonic2.Distance<RightUltrasonic ) RightUltrasonic = Ultrasonic2.Distance;
//    }
//    
//    AverageTime = Ultrasonic3.Sum/UCAPTURE_BUFFER_SIZE;
//	if( SingleTimeoutCheck( TimCapture3.Time, ULTRASONIC_TIME ) == TimeOut )
//    {
//        Ultrasonic3.Distance = 0xFFFF;
//    }
//    else
//    {
//        Ultrasonic3.Distance = AverageTime/58;
//        if( Ultrasonic3.Distance<RightUltrasonic ) RightUltrasonic = Ultrasonic3.Distance;
//    }
//    
//    AverageTime = Ultrasonic4.Sum/UCAPTURE_BUFFER_SIZE;
//    if( SingleTimeoutCheck( TimCapture4.Time, ULTRASONIC_TIME ) == TimeOut )
//    {
//        Ultrasonic4.Distance = 0xFFFF;
//    }
//    else
//    {
//        Ultrasonic4.Distance = AverageTime/58;
//        if( Ultrasonic4.Distance<LeftUltrasonic ) CentreUltrasonic = Ultrasonic4.Distance;     
//    }
//    
//    AverageTime = Ultrasonic5.Sum/UCAPTURE_BUFFER_SIZE;
//    if( SingleTimeoutCheck( TimCapture5.Time, ULTRASONIC_TIME ) == TimeOut )
//    {
//        Ultrasonic5.Distance = 0xFFFF;
//    }
//    else
//    {
//        Ultrasonic5.Distance = AverageTime/58;
//        if( Ultrasonic5.Distance<LeftUltrasonic ) LeftUltrasonic = Ultrasonic5.Distance;
//    }
//    
//    AverageTime = Ultrasonic6.Sum/UCAPTURE_BUFFER_SIZE;
//    if( SingleTimeoutCheck( TimCapture6.Time, ULTRASONIC_TIME ) == TimeOut )
//    {
//        Ultrasonic6.Distance = 0xFFFF;
//    }
//    else
//    {
//        Ultrasonic6.Distance = AverageTime/58;
//        if( Ultrasonic6.Distance<LeftUltrasonic ) LeftUltrasonic = Ultrasonic6.Distance;
//    }

//    AverageTime = Ultrasonic7.Sum/UCAPTURE_BUFFER_SIZE;
//    if( SingleTimeoutCheck( TimCapture7.Time, ULTRASONIC_TIME ) == TimeOut )
//    {
//        Ultrasonic7.Distance = 0xFFFF;
//    }
//    else
//    {
//        Ultrasonic7.Distance = AverageTime/58;
//        if( Ultrasonic7.Distance<LeftUltrasonic ) LeftUltrasonic = Ultrasonic7.Distance;
//    }
//	
//    
//    AverageTime = Ultrasonic8.Sum/UCAPTURE_BUFFER_SIZE;
//	if( SingleTimeoutCheck( TimCapture8.Time, ULTRASONIC_TIME ) == TimeOut )
//    {
//        Ultrasonic8.Distance = 0xFFFF;
//    }
//    else
//    {
//        Ultrasonic8.Distance = AverageTime/58;
////        if( Ultrasonic8.Distance<LeftUltrasonic ) LeftUltrasonic = Ultrasonic8.Distance;
//    }
    
    AverageTime = Ultrasonic9.Sum/UCAPTURE_BUFFER_SIZE;
	if( SingleTimeoutCheck( TimCapture9.Time, ULTRASONIC_TIME ) == TimeOut )
    {
        Ultrasonic9.Distance = 0xFFFF;
    }
    else
    {
        Ultrasonic9.Distance = AverageTime*34/100;
        systemUltrasonic.Data[systemUltrasonic.MachineNumber++] = Ultrasonic9.Distance;
//        if( Ultrasonic9.Distance<RightUltrasonic ) RightUltrasonic = Ultrasonic9.Distance;
    }
    
    AverageTime = Ultrasonic10.Sum/UCAPTURE_BUFFER_SIZE;
    if( SingleTimeoutCheck( TimCapture10.Time, ULTRASONIC_TIME ) == TimeOut )
    {
        Ultrasonic10.Distance = 0xFFFF;
    }
    else
    {
        Ultrasonic10.Distance = AverageTime*34/100;
        systemUltrasonic.Data[systemUltrasonic.MachineNumber++] = Ultrasonic10.Distance;
    }
    
    AverageTime = Ultrasonic11.Sum/UCAPTURE_BUFFER_SIZE;
    if( SingleTimeoutCheck( TimCapture11.Time, ULTRASONIC_TIME ) == TimeOut )
    {
        Ultrasonic11.Distance = 0xFFFF;
    }
    else
    {
        Ultrasonic11.Distance = AverageTime*34/100;
        systemUltrasonic.Data[systemUltrasonic.MachineNumber++] = Ultrasonic11.Distance;
    }
    
    AverageTime = Ultrasonic12.Sum/UCAPTURE_BUFFER_SIZE;
    if( SingleTimeoutCheck( TimCapture12.Time, ULTRASONIC_TIME ) == TimeOut )
    {
        Ultrasonic12.Distance = 0xFFFF;
    }
    else
    {
        Ultrasonic12.Distance = AverageTime*34/100;
        systemUltrasonic.Data[systemUltrasonic.MachineNumber++] = Ultrasonic12.Distance;
    }   
    
    if( systemUltrasonic.MachineNumber )
    {
        systemUltrasonic.AllDistance = 0;
        for( i=0; i<systemUltrasonic.MachineNumber; i++ )
        {
            systemUltrasonic.AllDistance += systemUltrasonic.Data[i];
        }
        systemUltrasonic.AverageDistance = systemUltrasonic.AllDistance/systemUltrasonic.MachineNumber;
        systemUltrasonic.MachineNumber = 0;
    }
    
    
    return true;
}


/*******************************************************************************
* Function Name  : DoubleEdgeCapture
* Description    : 
* Input          : arr:��װֵ
*                  psc:Ԥ��Ƶ
* Output         : None
* Return         : None
*******************************************************************************/
void DoubleEdgeTim3Capture( void )
{
	if( TIM_GetITStatus(TIM3, TIM_IT_CC1) != RESET )
    {
        TIM_ClearITPendingBit( TIM3, TIM_IT_CC1); //����жϱ�־λ  
        
		if( GPIO_ReadInputDataBit( GPIOA, GPIO_Pin_6 ) == Bit_RESET )
		{
			TIM3->CCER &= (uint16_t)~((uint16_t)TIM_CCER_CC1P);             //����Ϊ�����ز���
			TimCapture1.NewNumber = TIM_GetCapture1( TIM3 );
			if( TimCapture1.NewNumber < TimCapture1.OldNumber )
			{
				TimCapture1.Buffer[TimCapture1.WriteDataPoint] = TimCapture1.NewNumber+CapturePeriod-TimCapture1.OldNumber+1;
			}
			else
			{
				TimCapture1.Buffer[TimCapture1.WriteDataPoint] = TimCapture1.NewNumber-TimCapture1.OldNumber;
			}
            capUltrasonicWriteByteDone( TimCapture1.WriteDataPoint );
		}
		else if( GPIO_ReadInputDataBit( GPIOA, GPIO_Pin_6 ) == Bit_SET )
		{
			TIM3->CCER |= (uint16_t)TIM_CCER_CC1P;             //����Ϊ�½��ز���	
			TimCapture1.OldNumber = TIM_GetCapture1( TIM3 );
		}
        TimCapture1.Time = GetOSRunTimeNow(  );
    }
    
    if( TIM_GetITStatus( TIM3, TIM_IT_CC2 ) != RESET )
    {
        TIM_ClearITPendingBit( TIM3, TIM_IT_CC2 ); //����жϱ�־λ  
        
		if( GPIO_ReadInputDataBit( GPIOA, GPIO_Pin_7 ) == Bit_RESET )
		{
			TIM3->CCER &= (uint16_t)~((uint16_t)TIM_CCER_CC2P);             //����Ϊ�����ز���
			TimCapture2.NewNumber = TIM_GetCapture2( TIM3 );
			if( TimCapture2.NewNumber < TimCapture2.OldNumber )
			{
				TimCapture2.Buffer[TimCapture2.WriteDataPoint] = TimCapture2.NewNumber+CapturePeriod-TimCapture2.OldNumber+1;
			}
			else
			{
				TimCapture2.Buffer[TimCapture2.WriteDataPoint] = TimCapture2.NewNumber-TimCapture2.OldNumber;
			}
			capUltrasonicWriteByteDone( TimCapture2.WriteDataPoint );
		}
		else if( GPIO_ReadInputDataBit( GPIOA, GPIO_Pin_7 ) == Bit_SET )
		{
			TIM3->CCER |= (uint16_t)TIM_CCER_CC2P;             //����Ϊ�½��ز���	
			TimCapture2.OldNumber = TIM_GetCapture2( TIM3 );
		}
        TimCapture2.Time = GetOSRunTimeNow(  );
    }
    
    if( TIM_GetITStatus( TIM3, TIM_IT_CC3 ) != RESET )
    {
        TIM_ClearITPendingBit( TIM3, TIM_IT_CC3 ); //����жϱ�־λ  
        
		if( GPIO_ReadInputDataBit( GPIOB, GPIO_Pin_0 ) == Bit_RESET )
		{
			TIM3->CCER &= (uint16_t)~((uint16_t)TIM_CCER_CC3P);             //����Ϊ�����ز���
			TimCapture3.NewNumber = TIM_GetCapture3( TIM3 );
			if( TimCapture3.NewNumber < TimCapture3.OldNumber )
			{
				TimCapture3.Buffer[TimCapture3.WriteDataPoint] = TimCapture3.NewNumber+CapturePeriod-TimCapture3.OldNumber+1;
			}
			else
			{
				TimCapture3.Buffer[TimCapture3.WriteDataPoint] = TimCapture3.NewNumber-TimCapture3.OldNumber;
			}
			capUltrasonicWriteByteDone( TimCapture3.WriteDataPoint );
		}
		else if( GPIO_ReadInputDataBit( GPIOB, GPIO_Pin_0 ) == Bit_SET )
		{
			TIM3->CCER |= (uint16_t)TIM_CCER_CC3P;             //����Ϊ�½��ز���	
			TimCapture3.OldNumber = TIM_GetCapture3( TIM3 );
		}
        TimCapture3.Time = GetOSRunTimeNow(  );
    }
    
    
    if( TIM_GetITStatus( TIM3, TIM_IT_CC4 ) != RESET )
    {
        TIM_ClearITPendingBit( TIM3, TIM_IT_CC4 ); //����жϱ�־λ  
        
		if( GPIO_ReadInputDataBit( GPIOB, GPIO_Pin_1 ) == Bit_RESET )
		{
			TIM3->CCER &= (uint16_t)~((uint16_t)TIM_CCER_CC4P);             //����Ϊ�����ز���
			TimCapture4.NewNumber = TIM_GetCapture4( TIM3 );
			if( TimCapture4.NewNumber < TimCapture4.OldNumber )
			{
				TimCapture4.Buffer[TimCapture4.WriteDataPoint] = TimCapture4.NewNumber+CapturePeriod-TimCapture4.OldNumber+1;
			}
			else
			{
				TimCapture4.Buffer[TimCapture4.WriteDataPoint] = TimCapture4.NewNumber-TimCapture4.OldNumber;
			}
			capUltrasonicWriteByteDone( TimCapture4.WriteDataPoint );
		}
		else if( GPIO_ReadInputDataBit( GPIOB, GPIO_Pin_1 ) == Bit_SET )
		{
			TIM3->CCER |= (uint16_t)TIM_CCER_CC4P;             //����Ϊ�½��ز���	
			TimCapture4.OldNumber = TIM_GetCapture4( TIM3 );
		}
        TimCapture4.Time = GetOSRunTimeNow(  );
    }
	
}




/*******************************************************************************
* Function Name  : DoubleEdgeCapture
* Description    : 
* Input          : arr:��װֵ
*                  psc:Ԥ��Ƶ
* Output         : None
* Return         : None
*******************************************************************************/
void DoubleEdgeTim4Capture( void )
{
	if( TIM_GetITStatus(TIM4, TIM_IT_CC1) != RESET )
    {
        TIM_ClearITPendingBit( TIM4, TIM_IT_CC1); //����жϱ�־λ  
        
		if( GPIO_ReadInputDataBit( GPIOB, GPIO_Pin_6 ) == Bit_RESET )
		{
			TIM4->CCER &= (uint16_t)~((uint16_t)TIM_CCER_CC1P);             //����Ϊ�����ز���
			TimCapture5.NewNumber = TIM_GetCapture1( TIM4 );
			if( TimCapture5.NewNumber < TimCapture5.OldNumber )
			{
				TimCapture5.Buffer[TimCapture5.WriteDataPoint] = TimCapture5.NewNumber+CapturePeriod-TimCapture5.OldNumber+1;
			}
			else
			{
				TimCapture5.Buffer[TimCapture5.WriteDataPoint] = TimCapture5.NewNumber-TimCapture5.OldNumber;
			}
			capUltrasonicWriteByteDone( TimCapture5.WriteDataPoint );
		}
		else if( GPIO_ReadInputDataBit( GPIOB, GPIO_Pin_6 ) == Bit_SET )
		{
			TIM4->CCER |= (uint16_t)TIM_CCER_CC1P;             //����Ϊ�½��ز���	
			TimCapture5.OldNumber = TIM_GetCapture1( TIM4 );
		}
        TimCapture5.Time = GetOSRunTimeNow(  );
    }
    
    if( TIM_GetITStatus( TIM4, TIM_IT_CC2 ) != RESET )
    {
        TIM_ClearITPendingBit( TIM4, TIM_IT_CC2 ); //����жϱ�־λ  
        
		if( GPIO_ReadInputDataBit( GPIOB, GPIO_Pin_7 ) == Bit_RESET )
		{
			TIM4->CCER &= (uint16_t)~((uint16_t)TIM_CCER_CC2P);             //����Ϊ�����ز���
			TimCapture6.NewNumber = TIM_GetCapture2( TIM4 );
			if( TimCapture6.NewNumber < TimCapture6.OldNumber )
			{
				TimCapture6.Buffer[TimCapture6.WriteDataPoint] = TimCapture6.NewNumber+CapturePeriod-TimCapture6.OldNumber+1;
			}
			else
			{
				TimCapture6.Buffer[TimCapture6.WriteDataPoint] = TimCapture6.NewNumber-TimCapture6.OldNumber;
			}
			capUltrasonicWriteByteDone( TimCapture6.WriteDataPoint );
		}
		else if( GPIO_ReadInputDataBit( GPIOB, GPIO_Pin_7 ) == Bit_SET )
		{
			TIM4->CCER |= (uint16_t)TIM_CCER_CC2P;             //����Ϊ�½��ز���	
			TimCapture6.OldNumber = TIM_GetCapture2( TIM4 );
		}
        TimCapture6.Time = GetOSRunTimeNow(  );
    }
    
    if( TIM_GetITStatus(TIM4, TIM_IT_CC3) != RESET )
    {
        TIM_ClearITPendingBit( TIM4, TIM_IT_CC3); //����жϱ�־λ  
        
		if( GPIO_ReadInputDataBit( GPIOB, GPIO_Pin_8 ) == Bit_RESET )
		{
			TIM4->CCER &= (uint16_t)~((uint16_t)TIM_CCER_CC3P);             //����Ϊ�����ز���
			TimCapture7.NewNumber = TIM_GetCapture3( TIM4 );
			if( TimCapture7.NewNumber < TimCapture7.OldNumber )
			{
				TimCapture7.Buffer[TimCapture7.WriteDataPoint] = TimCapture7.NewNumber+CapturePeriod-TimCapture7.OldNumber+1;
			}
			else
			{
				TimCapture7.Buffer[TimCapture7.WriteDataPoint] = TimCapture7.NewNumber-TimCapture7.OldNumber;
			}
			capUltrasonicWriteByteDone( TimCapture7.WriteDataPoint );
		}
		else if( GPIO_ReadInputDataBit( GPIOB, GPIO_Pin_8 ) == Bit_SET )
		{
			TIM4->CCER |= (uint16_t)TIM_CCER_CC3P;             //����Ϊ�½��ز���	
			TimCapture7.OldNumber = TIM_GetCapture3( TIM4 );
		}
        TimCapture7.Time = GetOSRunTimeNow(  );
    }
    
    if( TIM_GetITStatus( TIM4, TIM_IT_CC4 ) != RESET )
    {
        TIM_ClearITPendingBit( TIM4, TIM_IT_CC4 ); //����жϱ�־λ  
        
		if( GPIO_ReadInputDataBit( GPIOB, GPIO_Pin_9 ) == Bit_RESET )
		{
			TIM4->CCER &= (uint16_t)~((uint16_t)TIM_CCER_CC4P);             //����Ϊ�����ز���
			TimCapture8.NewNumber = TIM_GetCapture4( TIM4 );
			if( TimCapture8.NewNumber < TimCapture8.OldNumber )
			{
				TimCapture8.Buffer[TimCapture8.WriteDataPoint] = TimCapture8.NewNumber+CapturePeriod-TimCapture8.OldNumber+1;
			}
			else
			{
				TimCapture8.Buffer[TimCapture8.WriteDataPoint] = TimCapture8.NewNumber-TimCapture8.OldNumber;
			}
			capUltrasonicWriteByteDone( TimCapture8.WriteDataPoint );
		}
		else if( GPIO_ReadInputDataBit( GPIOB, GPIO_Pin_9 ) == Bit_SET )
		{
			TIM4->CCER |= (uint16_t)TIM_CCER_CC4P;             //����Ϊ�½��ز���	
			TimCapture8.OldNumber = TIM_GetCapture4( TIM4 );
		}
        TimCapture8.Time = GetOSRunTimeNow(  );
    }
	
}



/*******************************************************************************
* Function Name  : DoubleEdgeCapture
* Description    : 
* Input          : arr:��װֵ
*                  psc:Ԥ��Ƶ
* Output         : None
* Return         : None
*******************************************************************************/
void DoubleEdgeTim5Capture( void )
{
#if 0
	if( TIM_GetITStatus(TIM5, TIM_IT_CC1) != RESET )
    {
        TIM_ClearITPendingBit( TIM5, TIM_IT_CC1); //����жϱ�־λ  
        
		if( GPIO_ReadInputDataBit( GPIOA, GPIO_Pin_0 ) == Bit_RESET )
		{
			TIM5->CCER &= (uint16_t)~((uint16_t)TIM_CCER_CC1P);             //����Ϊ�����ز���
			TimCapture9.NewNumber = TIM_GetCapture1( TIM5 );
			if( TimCapture9.NewNumber < TimCapture9.OldNumber )
			{
				TimCapture9.Buffer[TimCapture9.WriteDataPoint] = TimCapture9.NewNumber+CapturePeriod-TimCapture9.OldNumber+1;
			}
			else
			{
				TimCapture9.Buffer[TimCapture9.WriteDataPoint] = TimCapture9.NewNumber-TimCapture9.OldNumber;
			}
			capUltrasonicWriteByteDone( TimCapture9.WriteDataPoint );
		}
		else if( GPIO_ReadInputDataBit( GPIOA, GPIO_Pin_0 ) == Bit_SET )
		{
			TIM5->CCER |= (uint16_t)TIM_CCER_CC1P;             //����Ϊ�½��ز���	
			TimCapture9.OldNumber = TIM_GetCapture1( TIM5 );
		}
        TimCapture9.Time = GetOSRunTimeNow(  );
    }
    
    if( TIM_GetITStatus( TIM5, TIM_IT_CC2 ) != RESET )
    {
        TIM_ClearITPendingBit( TIM5, TIM_IT_CC2 ); //����жϱ�־λ  
        
		if( GPIO_ReadInputDataBit( GPIOA, GPIO_Pin_1 ) == Bit_RESET )
		{
			TIM5->CCER &= (uint16_t)~((uint16_t)TIM_CCER_CC2P);             //����Ϊ�����ز���
			TimCapture10.NewNumber = TIM_GetCapture2( TIM5 );
			if( TimCapture10.NewNumber < TimCapture10.OldNumber )
			{
				TimCapture10.Buffer[TimCapture10.WriteDataPoint] = TimCapture10.NewNumber+CapturePeriod-TimCapture10.OldNumber+1;
			}
			else
			{
				TimCapture10.Buffer[TimCapture10.WriteDataPoint] = TimCapture10.NewNumber-TimCapture10.OldNumber;
			}
			capUltrasonicWriteByteDone( TimCapture10.WriteDataPoint );
		}
		else if( GPIO_ReadInputDataBit( GPIOA, GPIO_Pin_1 ) == Bit_SET )
		{
			TIM5->CCER |= (uint16_t)TIM_CCER_CC2P;             //����Ϊ�½��ز���	
			TimCapture10.OldNumber = TIM_GetCapture2( TIM5 );
		}
        TimCapture10.Time = GetOSRunTimeNow(  );
    }
#endif	
}


/*******************************************************************************
* Function Name  : DoubleEdgeCapture
* Description    : 
* Input          : arr:��װֵ
*                  psc:Ԥ��Ƶ
* Output         : None
* Return         : None
*******************************************************************************/
void DoubleEdgeTim8Capture( void )
{
    if( TIM_GetITStatus(TIM8, TIM_IT_CC1) != RESET )
    {
        TIM_ClearITPendingBit( TIM8, TIM_IT_CC1); //����жϱ�־λ  
        
		if( GPIO_ReadInputDataBit( GPIOC, GPIO_Pin_6 ) == Bit_RESET )
		{
			TIM8->CCER &= (uint16_t)~((uint16_t)TIM_CCER_CC1P);             //����Ϊ�����ز���
			TimCapture9.NewNumber = TIM_GetCapture1( TIM8 );
			if( TimCapture9.NewNumber < TimCapture9.OldNumber )
			{
				TimCapture9.Buffer[TimCapture9.WriteDataPoint] = TimCapture9.NewNumber+CapturePeriod-TimCapture9.OldNumber+1;
			}
			else
			{
				TimCapture9.Buffer[TimCapture9.WriteDataPoint] = TimCapture9.NewNumber-TimCapture9.OldNumber;
			}
			capUltrasonicWriteByteDone( TimCapture9.WriteDataPoint );
		}
		else if( GPIO_ReadInputDataBit( GPIOC, GPIO_Pin_6 ) == Bit_SET )
		{
			TIM8->CCER |= (uint16_t)TIM_CCER_CC1P;             //����Ϊ�½��ز���	
			TimCapture9.OldNumber = TIM_GetCapture1( TIM8 );
		}
        TimCapture9.Time = GetOSRunTimeNow(  );
    }
    
    if( TIM_GetITStatus(TIM8, TIM_IT_CC2) != RESET )
    {
        TIM_ClearITPendingBit( TIM8, TIM_IT_CC2); //����жϱ�־λ  
        
		if( GPIO_ReadInputDataBit( GPIOC, GPIO_Pin_7 ) == Bit_RESET )
		{
			TIM8->CCER &= (uint16_t)~((uint16_t)TIM_CCER_CC2P);             //����Ϊ�����ز���
			TimCapture10.NewNumber = TIM_GetCapture2( TIM8 );
			if( TimCapture10.NewNumber < TimCapture9.OldNumber )
			{
				TimCapture10.Buffer[TimCapture10.WriteDataPoint] = TimCapture10.NewNumber+CapturePeriod-TimCapture10.OldNumber+1;
			}
			else
			{
				TimCapture10.Buffer[TimCapture10.WriteDataPoint] = TimCapture10.NewNumber-TimCapture10.OldNumber;
			}
			capUltrasonicWriteByteDone( TimCapture10.WriteDataPoint );
		}
		else if( GPIO_ReadInputDataBit( GPIOC, GPIO_Pin_7 ) == Bit_SET )
		{
			TIM8->CCER |= (uint16_t)TIM_CCER_CC2P;             //����Ϊ�½��ز���	
			TimCapture10.OldNumber = TIM_GetCapture2( TIM8 );
		}
        TimCapture10.Time = GetOSRunTimeNow(  );
    }
    
	if( TIM_GetITStatus(TIM8, TIM_IT_CC3) != RESET )
    {
        TIM_ClearITPendingBit( TIM8, TIM_IT_CC3); //����жϱ�־λ  
        
		if( GPIO_ReadInputDataBit( GPIOC, GPIO_Pin_8 ) == Bit_RESET )
		{
			TIM8->CCER &= (uint16_t)~((uint16_t)TIM_CCER_CC3P);             //����Ϊ�����ز���
			TimCapture11.NewNumber = TIM_GetCapture3( TIM8 );
			if( TimCapture11.NewNumber < TimCapture11.OldNumber )
			{
				TimCapture11.Buffer[TimCapture11.WriteDataPoint] = TimCapture11.NewNumber+CapturePeriod-TimCapture11.OldNumber+1;
			}
			else
			{
				TimCapture11.Buffer[TimCapture11.WriteDataPoint] = TimCapture11.NewNumber-TimCapture11.OldNumber;
			}
			capUltrasonicWriteByteDone( TimCapture11.WriteDataPoint );
		}
		else if( GPIO_ReadInputDataBit( GPIOC, GPIO_Pin_8 ) == Bit_SET )
		{
			TIM8->CCER |= (uint16_t)TIM_CCER_CC3P;             //����Ϊ�½��ز���	
			TimCapture11.OldNumber = TIM_GetCapture3( TIM8 );
		}
        TimCapture11.Time = GetOSRunTimeNow(  );
    }
    
    if( TIM_GetITStatus( TIM8, TIM_IT_CC4 ) != RESET )
    {
        TIM_ClearITPendingBit( TIM8, TIM_IT_CC4 ); //����жϱ�־λ  
        
		if( GPIO_ReadInputDataBit( GPIOC, GPIO_Pin_9 ) == Bit_RESET )
		{
			TIM8->CCER &= (uint16_t)~((uint16_t)TIM_CCER_CC4P);             //����Ϊ�����ز���
			TimCapture12.NewNumber = TIM_GetCapture4( TIM8 );
			if( TimCapture12.NewNumber < TimCapture12.OldNumber )
			{
				TimCapture12.Buffer[TimCapture12.WriteDataPoint] = TimCapture12.NewNumber+CapturePeriod-TimCapture12.OldNumber+1;
			}
			else
			{
				TimCapture12.Buffer[TimCapture12.WriteDataPoint] = TimCapture12.NewNumber-TimCapture12.OldNumber;
			}
			capUltrasonicWriteByteDone( TimCapture12.WriteDataPoint );
		}
		else if( GPIO_ReadInputDataBit( GPIOC, GPIO_Pin_9 ) == Bit_SET )
		{
			TIM8->CCER |= (uint16_t)TIM_CCER_CC4P;             //����Ϊ�½��ز���	
			TimCapture12.OldNumber = TIM_GetCapture4( TIM8 );
		}
        TimCapture12.Time = GetOSRunTimeNow(  );
    }
	
}




/*******************************************************************************
* Function Name  : TIM1_CC_IRQHandler
* Description    : TIM1 �����жϷ�����
*******************************************************************************/
//void TIM3_IRQHandler( void )
//{
//    DoubleEdgeTim3Capture(  );
//}


/*******************************************************************************
* Function Name  : TIM1_CC_IRQHandler
* Description    : TIM1 �����жϷ�����
*******************************************************************************/
//void TIM4_IRQHandler( void )
//{
//    DoubleEdgeTim4Capture(  );
//}


/*******************************************************************************
* Function Name  : TIM1_CC_IRQHandler
* Description    : TIM1 �����жϷ�����
*******************************************************************************/
void TIM5_IRQHandler( void )
{
    DoubleEdgeTim5Capture(  );
}


/*******************************************************************************
* Function Name  : TIM1_CC_IRQHandler
* Description    : TIM1 �����жϷ�����
*******************************************************************************/
void TIM8_CC_IRQHandler( void )
{
    DoubleEdgeTim8Capture(  );
}



/*******************************************************************************
* Function Name  : TIM3CaptureInit
* Description    : ��ʱ��2�����ܳ�ʼ��
* Input          : arr:��װֵ
*                  psc:Ԥ��Ƶ
* Output         : None
* Return         : None
*******************************************************************************/
static void TIM3CaptureInit( u16 Period, u16 Prescaler )
{
    GPIO_InitTypeDef  GPIO_InitStructure; 
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    TIM_ICInitTypeDef  TIM_ICInitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
     
    RCC_APB1PeriphClockCmd( RCC_APB1Periph_TIM3, ENABLE);	 
    RCC_APB2PeriphClockCmd(  RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB, ENABLE);	 
       
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7;				 
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;	     
    GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IPD;	     
    GPIO_Init( GPIOA, &GPIO_InitStructure );	 
    
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;				 
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;	     
    GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IPD;	     
    GPIO_Init( GPIOB, &GPIO_InitStructure );
  
    TIM_TimeBaseStructure.TIM_Period = Period;                        //�趨�������Զ���װֵ   
    TIM_TimeBaseStructure.TIM_Prescaler =Prescaler; 	              //Ԥ��Ƶ�� 	   
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;           //����ʱ�ӷָ�:TDTS = Tck_tim
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;       //TIM���ϼ���ģʽ
    TIM_TimeBaseInit( TIM3, &TIM_TimeBaseStructure );                 //����TIM_TimeBaseInitStruct��ָ���Ĳ�����ʼ��TIMx��ʱ�������λ
         	
  	TIM_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising;	      //�����ز���
  	TIM_ICInitStructure.TIM_ICSelection = TIM_ICSelection_DirectTI; 
  	TIM_ICInitStructure.TIM_ICPrescaler = TIM_ICPSC_DIV1;	          //���������Ƶ,����Ƶ 
  	TIM_ICInitStructure.TIM_ICFilter = 0x0F;                          //IC2F=0011 ���������˲��� 8����ʱ��ʱ�������˲�
  	
                        
    
    TIM_ICInitStructure.TIM_Channel = TIM_Channel_1;                 
    TIM_ICInit(TIM3, &TIM_ICInitStructure);   
    
    TIM_ICInitStructure.TIM_Channel = TIM_Channel_2;                 
    TIM_ICInit(TIM3, &TIM_ICInitStructure);   
    
    TIM_ICInitStructure.TIM_Channel = TIM_Channel_3;                  
    TIM_ICInit(TIM3, &TIM_ICInitStructure);  

    TIM_ICInitStructure.TIM_Channel = TIM_Channel_4;                  
    TIM_ICInit(TIM3, &TIM_ICInitStructure);

    //�жϷ����ʼ��
    TIM_ClearITPendingBit( TIM3, TIM_IT_CC1|TIM_IT_CC2|TIM_IT_CC3|TIM_IT_CC4 );  
    TIM_ITConfig( TIM3, TIM_IT_CC1|TIM_IT_CC2|TIM_IT_CC3|TIM_IT_CC4, ENABLE ); 
	NVIC_InitStructure.NVIC_IRQChannel = TIM3_IRQn;   
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;   
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;   
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;  
	NVIC_Init(&NVIC_InitStructure);   
	
    TIM_Cmd( TIM3, ENABLE ); 	
    
}







/*******************************************************************************
* Function Name  : TIM4CaptureInit
* Description    : ��ʱ��2�����ܳ�ʼ��
* Input          : arr:��װֵ
*                  psc:Ԥ��Ƶ
* Output         : None
* Return         : None
*******************************************************************************/
static void TIM4CaptureInit( u16 Period, u16 Prescaler )
{
    GPIO_InitTypeDef  GPIO_InitStructure; 
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    TIM_ICInitTypeDef  TIM_ICInitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
     
    RCC_APB1PeriphClockCmd( RCC_APB1Periph_TIM4, ENABLE);	 
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOB, ENABLE);	 
    
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7 | GPIO_Pin_8 | GPIO_Pin_9;				 
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;	     
    GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IPD;	     
    GPIO_Init( GPIOB, &GPIO_InitStructure );	                 
  
    TIM_TimeBaseStructure.TIM_Period = Period;                        //�趨�������Զ���װֵ   
    TIM_TimeBaseStructure.TIM_Prescaler =Prescaler; 	              //Ԥ��Ƶ�� 	   
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;           //����ʱ�ӷָ�:TDTS = Tck_tim
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;       //TIM���ϼ���ģʽ
    TIM_TimeBaseInit( TIM4, &TIM_TimeBaseStructure );                 //����TIM_TimeBaseInitStruct��ָ���Ĳ�����ʼ��TIMx��ʱ�������λ
         	
  	TIM_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising;	      //�����ز���
  	TIM_ICInitStructure.TIM_ICSelection = TIM_ICSelection_DirectTI; 
  	TIM_ICInitStructure.TIM_ICPrescaler = TIM_ICPSC_DIV1;	          //���������Ƶ,����Ƶ 
  	TIM_ICInitStructure.TIM_ICFilter = 0x0F;                          //IC2F=0011 ���������˲��� 8����ʱ��ʱ�������˲�
  	   
    
    TIM_ICInitStructure.TIM_Channel = TIM_Channel_1;                 
    TIM_ICInit(TIM4, &TIM_ICInitStructure);   
    
    TIM_ICInitStructure.TIM_Channel = TIM_Channel_2;                 
    TIM_ICInit(TIM4, &TIM_ICInitStructure);   
    
    TIM_ICInitStructure.TIM_Channel = TIM_Channel_3;                  
    TIM_ICInit(TIM4, &TIM_ICInitStructure);  

    TIM_ICInitStructure.TIM_Channel = TIM_Channel_4;                  
    TIM_ICInit(TIM4, &TIM_ICInitStructure);  
    
    //�жϷ����ʼ��
    TIM_ClearITPendingBit( TIM4, TIM_IT_CC1|TIM_IT_CC2|TIM_IT_CC3|TIM_IT_CC4 );  
    TIM_ITConfig( TIM4, TIM_IT_CC1|TIM_IT_CC2|TIM_IT_CC3|TIM_IT_CC4, ENABLE ); 
	NVIC_InitStructure.NVIC_IRQChannel = TIM4_IRQn;   
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;   
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;   
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;  
	NVIC_Init(&NVIC_InitStructure);   
	
    TIM_Cmd( TIM4, ENABLE ); 	
    
}






/*******************************************************************************
* Function Name  : TIM4CaptureInit
* Description    : ��ʱ��2�����ܳ�ʼ��
* Input          : arr:��װֵ
*                  psc:Ԥ��Ƶ
* Output         : None
* Return         : None
*******************************************************************************/
static void TIM5CaptureInit( u16 Period, u16 Prescaler )
{
    GPIO_InitTypeDef  GPIO_InitStructure; 
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    TIM_ICInitTypeDef  TIM_ICInitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
     
    RCC_APB1PeriphClockCmd( RCC_APB1Periph_TIM5, ENABLE);	
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOA, ENABLE);	
       
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_0 | GPIO_Pin_1;				 
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;	     
    GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IPD;	     
    GPIO_Init( GPIOA, &GPIO_InitStructure );	                 
  
    TIM_TimeBaseStructure.TIM_Period = Period;                        //�趨�������Զ���װֵ   
    TIM_TimeBaseStructure.TIM_Prescaler =Prescaler; 	              //Ԥ��Ƶ�� 	   
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;           //����ʱ�ӷָ�:TDTS = Tck_tim
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;       //TIM���ϼ���ģʽ
    TIM_TimeBaseInit( TIM5, &TIM_TimeBaseStructure );                 //����TIM_TimeBaseInitStruct��ָ���Ĳ�����ʼ��TIMx��ʱ�������λ
         	
  	TIM_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising;	      //�����ز���
  	TIM_ICInitStructure.TIM_ICSelection = TIM_ICSelection_DirectTI; 
  	TIM_ICInitStructure.TIM_ICPrescaler = TIM_ICPSC_DIV1;	          //���������Ƶ,����Ƶ 
  	TIM_ICInitStructure.TIM_ICFilter = 0x0F;                          //IC2F=0011 ���������˲��� 8����ʱ��ʱ�������˲�
  	  
    TIM_ICInitStructure.TIM_Channel = TIM_Channel_1;                 
    TIM_ICInit(TIM5, &TIM_ICInitStructure);   
    
    TIM_ICInitStructure.TIM_Channel = TIM_Channel_2;                 
    TIM_ICInit(TIM5, &TIM_ICInitStructure);   
    
//    TIM_ICInitStructure.TIM_Channel = TIM_Channel_4;                  
//    TIM_ICInit(TIM4, &TIM_ICInitStructure);                            
    
    //�жϷ����ʼ��
    TIM_ClearITPendingBit( TIM5, TIM_IT_CC1|TIM_IT_CC2 );  
    TIM_ITConfig( TIM5, TIM_IT_CC1|TIM_IT_CC2, ENABLE ); 
	NVIC_InitStructure.NVIC_IRQChannel = TIM5_IRQn;   
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;   
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;   
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;  
	NVIC_Init(&NVIC_InitStructure);   
	
    TIM_Cmd( TIM5, ENABLE ); 	
    
}






/*******************************************************************************
* Function Name  : TIM4CaptureInit
* Description    : ��ʱ��2�����ܳ�ʼ��
* Input          : arr:��װֵ
*                  psc:Ԥ��Ƶ
* Output         : None
* Return         : None
*******************************************************************************/
static void TIM8CaptureInit( u16 Period, u16 Prescaler )
{
    GPIO_InitTypeDef  GPIO_InitStructure; 
    TIM_TimeBaseInitTypeDef  TIM_TimeBaseStructure;
    TIM_ICInitTypeDef  TIM_ICInitStructure;
    NVIC_InitTypeDef NVIC_InitStructure;
     
    RCC_APB2PeriphClockCmd( RCC_APB2Periph_TIM8|RCC_APB2Periph_GPIOC, ENABLE);	 
       
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_6 | GPIO_Pin_7|GPIO_Pin_8 | GPIO_Pin_9;				 
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_2MHz;	     
    GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IPD;	     
    GPIO_Init( GPIOC, &GPIO_InitStructure );	                 
  
    TIM_TimeBaseStructure.TIM_Period = Period;                        //�趨�������Զ���װֵ   
    TIM_TimeBaseStructure.TIM_Prescaler =Prescaler; 	              //Ԥ��Ƶ�� 	   
    TIM_TimeBaseStructure.TIM_ClockDivision = TIM_CKD_DIV1;           //����ʱ�ӷָ�:TDTS = Tck_tim
    TIM_TimeBaseStructure.TIM_CounterMode = TIM_CounterMode_Up;       //TIM���ϼ���ģʽ
    TIM_TimeBaseInit( TIM8, &TIM_TimeBaseStructure );                 //����TIM_TimeBaseInitStruct��ָ���Ĳ�����ʼ��TIMx��ʱ�������λ
         	
  	TIM_ICInitStructure.TIM_ICPolarity = TIM_ICPolarity_Rising;	      //�����ز���
  	TIM_ICInitStructure.TIM_ICSelection = TIM_ICSelection_DirectTI; 
  	TIM_ICInitStructure.TIM_ICPrescaler = TIM_ICPSC_DIV1;	          //���������Ƶ,����Ƶ 
  	TIM_ICInitStructure.TIM_ICFilter = 0x0F;                          //IC2F=0011 ���������˲��� 8����ʱ��ʱ�������˲�
  	
    TIM_ICInitStructure.TIM_Channel = TIM_Channel_1;                 
    TIM_ICInit(TIM8, &TIM_ICInitStructure);   
    
    TIM_ICInitStructure.TIM_Channel = TIM_Channel_2;                 
    TIM_ICInit(TIM8, &TIM_ICInitStructure);   
    
    TIM_ICInitStructure.TIM_Channel = TIM_Channel_3;                 
    TIM_ICInit(TIM8, &TIM_ICInitStructure);   
    
    TIM_ICInitStructure.TIM_Channel = TIM_Channel_4;                 
    TIM_ICInit(TIM8, &TIM_ICInitStructure);   
    
    //�жϷ����ʼ��
    TIM_ClearITPendingBit( TIM8, TIM_IT_CC1|TIM_IT_CC2|TIM_IT_CC3|TIM_IT_CC4 );  
    TIM_ITConfig( TIM8, TIM_IT_CC1|TIM_IT_CC2|TIM_IT_CC3|TIM_IT_CC4, ENABLE ); 
	NVIC_InitStructure.NVIC_IRQChannel = TIM8_CC_IRQn;   
	NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority = 1;   
	NVIC_InitStructure.NVIC_IRQChannelSubPriority = 0;   
	NVIC_InitStructure.NVIC_IRQChannelCmd = ENABLE;  
	NVIC_Init(&NVIC_InitStructure);   
	
    TIM_Cmd( TIM8, ENABLE ); 	
    
}






