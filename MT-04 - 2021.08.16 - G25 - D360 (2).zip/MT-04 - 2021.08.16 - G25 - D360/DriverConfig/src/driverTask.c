/**********************************************************************************
 * Filename   ��DriverRun.c
 * Author     : Liu Tusheng       
 * Version    : 1.0
 * Date       : 2017.9.8
 * Discription : 
 * Hardware Connet:
**********************************************************************************/ 
#include "driverTask.h"

void delay( uint32_t n )
{
    uint32_t m;
    
    for( ; n>0; n-- )
        for( m = 1000; m>0; m-- );
}


/****************************************************************************************************
������  ��HardwareDriverInit
��    ������
����ֵ  ����
����������Ӳ����ʼ��
****************************************************************************************************/
void HardwareDriverInit( void )
{
//    delay( 100000 );
    
    NVIC_PriorityGroupConfig(NVIC_PriorityGroup_4);	
    CanInterfaceInitConfig(  );
  	vAllIoInputConfig(  ); 	
    vAllIoOutputConfig(  );
    Timer6Init(  );
    Timer1EncoderInitialize(  );
    Timer2EncoderInitialize(  );
    Timer3EncoderInitialize(  );
    Timer4EncoderInitialize(  );
    TIM4_PWMModeConfig(  );
    TIM8_PWMModeConfig(  );
    Usart2Init( 115200 );
    Usart3Init( 19200 );
    Uart4Init( 115200 );
    MC6CInit(  );
	IWDG_DefaultConfiguration(  );
	IWDG_Start(  );
    
}



/*******************************************************************************
* Function Name  : SystemHardwareWorkTask
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SystemHardwareWorkTask( void *Parammenters )
{
    TickType_t Time = 0;
    uint32_t data = 0;
    uint8_t buffer[20] = {1,2,3,4,5,6,7,8,8,99,8,55,6};
    bool Buzzer = false;
//    motorSetFrontLeftWheelSpeed( 1200 );
//    motorSetFrontRightWheelSpeed( 20 );
    
//    motorSetBehindLeftWheelSpeed( 1000 );
//    motorSetBehindRightWheelSpeed( 1000 );
//    SetBehindLeftMotorDriverDuty( 18000 );             
//    SetBehindRightMotorDriverDuty( 18000 );
    
    while( 1 )
    {
        if( (Buzzer == false) && (SingleTimeoutCheck( 0, 200 ) == TimeOut) )
        {
            outBuzzerOFF(  );
            Buzzer = true;
        }
        
        Usart2TransmitAndReceive( );
        Usart3TransmitAndReceive( );
//        Uart4TransmitAndReceive( );
//        gpioInputCheck(  );
        IWDG_FeedDog(  );
    }
    
    
    
}
