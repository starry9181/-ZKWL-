/*****************************************************************************************************
PID�Ǳ��������֣�΢�ֵ���д��
Uo(N)=P*E(N)+I*[E(N)+E(N-1)+...+E(0)]+D*[E(N)-E(N-1)]

E-���
P--�ı�P�������Ӧ�ٶȣ���С��̬����̫������󳬵������ȶ�ʱ�䡣
I--��P�����û������ƣ���Ҫʹ��̬���Ϊ0������ʹ�û��֡�
D--��P,I�������෴����Ҫ��Ϊ�˼�С��������С�ȶ�ʱ�䡣

��������Ҫ�ۺϿ��ǣ�һ���Ƚ�I,D��Ϊ0������P,�ﵽ��������Ӧ�ٶȺ����ټ���I,ʹ���Ϊ0����ʱ�ټ���D,
��������Ҫ�������ԣ����մﵽ�ϺõĽ������ͬ�Ŀ��ƶ��󣬵��Ե��Ѷ����ܴ�ף���ˣ�

���Ǵ�����������һ���Ƚϵ��͵�PID����������ʹ�õ�Ƭ����Ϊ����cpuʱ���������򻯣������PID
���������ɾ������ͨ��ʵ��ȷ�������ڵ�Ƭ���Ĵ����ٶȺ�ram��Դ�����ƣ�һ�㲻���ø��������㣬
�������в���ȫ�������������㵽����ٳ���һ��2��N�η����ݣ��൱����λ���������ƶ��������㣬��
�����������ٶȣ����ݿ��ƾ��ȵĲ�ͬҪ�󣬵�����Ҫ��ܸ�ʱ��ע�Ᵽ����λ����ġ���������������
���������������ֻ��һ�㳣��pid�㷨�Ļ����ܹ���û�а�����������������֡�
******************************************************************************************************/
#include "pid.h"
#include "math.h"

PidStruct frontLeftWheelPid = {0};
PidStruct frontRightWheelPid = {0};
PidStruct behindLeftWheelPid = {0};
PidStruct behindRightWheelPid = {0};

PID_Type MBL_PID,MBR_PID;

static void Clear_PID_Temp(PID_Type * pid)
{
    pid->actual = pid->target = pid->ctrOut = pid->dCtrOut = pid->dErrD \
                = pid->dErrI = pid->dErrP = pid->errNow = pid->errOld1 = pid->errOld2 = 0;
}


static void Set_PID_Param(PID_Type * pid , float kp , float ki , float kd , float errILimit , float output_limit )
{
    pid->kp = kp;
    pid->ki = ki;
    pid->kd = kd;
    pid->errILim = errILimit;
    pid->output_max = output_limit;
}


void Set_BL_PID(float kp , float ki , float kd , float errILimit , float output_limit)
{
    Set_PID_Param(&MBL_PID,kp,ki,kd,errILimit,output_limit);
}

void Set_BR_PID(float kp , float ki , float kd , float errILimit , float output_limit)
{
    Set_PID_Param(&MBR_PID,kp,ki,kd,errILimit,output_limit);
}

//����ʽPID�㷨
void PID_IncrementMode(PID_Type* PID , uint8_t mode)
{

    if(PID->kp < 0)    PID->kp = -PID->kp;
    if(PID->ki < 0)	PID->ki = -PID->ki;
    if(PID->kd < 0)    PID->kd = -PID->kd;
    if(PID->errILim < 0)    PID->errILim = -PID->errILim;

    PID->errNow = PID->target - PID->actual;

    PID->dErrP = PID->errNow - PID->errOld1;
    PID->dErrI = PID->errNow ;

    PID->dErrD = PID->errNow - 2 * PID->errOld1 + PID->errOld2;

    PID->errOld2 = PID->errOld1;
    PID->errOld1 = PID->errNow;

    PID->dCtrOut = PID->kp * PID->dErrP + PID->ki * PID->dErrI + PID->kd * PID->dErrD;

    if(PID->kp == 0 && PID->ki == 0 && PID->kd == 0)   PID->ctrOut = 0;
    else PID->ctrOut += PID->dCtrOut;

    if(PID->output_max != 0)
    {
     if(PID->ctrOut>PID->output_max) PID->ctrOut = PID->output_max;
     if(PID->ctrOut<-PID->output_max) PID->ctrOut = -PID->output_max;
    }
    if(mode == one_way)
    {
        if(PID->target >= 0 && PID->ctrOut <= 100)
        {
                PID->ctrOut = 100;
        }
        else if(PID->target <= 0 && PID->ctrOut >= -100)
        {
                PID->ctrOut = -100;
        }
    }
}

/*******************************************************************************
* Function Name  : PidInit
* Description    : ��ʼ��PID��ر���
* Input          :
* Output         : None
* Return         : None
*******************************************************************************/
void vPidStructInit( void )
{
    vWheelPidStructInit( &frontLeftWheelPid, 0 );
    vWheelPidStructInit( &frontRightWheelPid, 0 );
    vWheelPidStructInit( &behindLeftWheelPid, 0 );
    vWheelPidStructInit( &behindRightWheelPid, 0 );
//    motorSetFrontLeftWheelSpeed( 900 );
//    motorSetBehindLeftWheelSpeed( -800 );
//    motorSetBehindRightWheelSpeed( 800 );
}


/*******************************************************************************
* Function Name  : PidInit
* Description    : ��ʼ��PID��ر���
* Input          :
* Output         : None
* Return         : None
*******************************************************************************/
void vWheelPidStructInit( PidStruct *pid, int32_t SetSpeed )
{
    pid->SetPoint = SetSpeed;
    pid->Kp = 1.2;
    pid->Ki = 0.01;
    pid->Kd = 0.001;
    pid->SumError = 0;

}



/*******************************************************************************
* Function Name  : PidInit
* Description    : ��ʼ��PID��ر���
* Input          :
* Output         : None
* Return         : None
*******************************************************************************/
void vSetPidStruct( void *pid, float Kp, float Ki, float Kd )
{
    PidStruct *pidStruct = (PidStruct*)pid;
    
    pidStruct->Kp = Kp;      
    pidStruct->Ki = Ki;  
    pidStruct->Kd = Kd; 

}


/*******************************************************************************
* Function Name  : vSetSpeed
* Description    : �����ٶ�
* Input          : 
* Output         : None
* Return         : None
*******************************************************************************/
void vSetSpeed( PidStruct *pid, int16_t SetSpeed )
{
    pid->SetPoint = SetSpeed;
}





/*******************************************************************************
* Function Name  : turnLeftRightPidAdjust
* Description    : PID�㷨ʵ��
* Input          :
* Output         : None
* Return         : None
*******************************************************************************/
void turnLeftRightPidAdjust( float setPoint, float realPoint )
{	
	float Error; 
    int16_t speed;
    
    if( (setPoint - 123.5) > 0 ) setPoint = 123.5;
    else if( (setPoint + 123.5) < 0 ) setPoint = -123.5; 
    
    Error = setPoint - realPoint;          //ƫ��

    
    speed = 20*fabs(Error); 
    
    if( (Error-1.0) > 0.0 ) //
    {
        //motorSetFrontRightWheelSpeed( -speed ); //�����У�������ת��������ת
        motorSetFrontRightWheelSpeed( speed ); //��ת
        vSetPidStruct( &frontRightWheelPid, 2.5, 0.01, 0 );
    }
    else if( (Error+1.0) < 0.0 )
    {
        motorSetFrontRightWheelSpeed( -speed ); //��ת
        vSetPidStruct( &frontRightWheelPid, 2.5, 0.01, 0 );
    }
    else
    {
//        motorSetFrontRightWheelSpeed( 0 );
        outFrontRightWheelStop(  );
    }

}


#define UP_SPEED  50
#define UP_ACCEL  20.0     //4
#define DOWN_ACCEL  0.5  //0.35
#define DOWN_SPEED  (int16_t)(30/DOWN_ACCEL)


/*******************************************************************************
* Function Name  : UpDownSpeed
* Description    : �Ӽ���
* Input          :
* Output         : None
* Return         : None
*******************************************************************************/
void UpDownSpeed( void )
{
	
    static TickType_t UpDownSpeedTime = 0;
    static TickType_t frontTurnWheelTime = 0;
    static TickType_t behindLeftWheelTime = 0;
    static TickType_t behindRightWheelTime = 0;

    if( robotMotion.scram != BitSet)
    {
//        if(MecanumChassisSetPoint.behindLeftWheelSpeed > 0)
//        {
//            outBehindLeftWheelForward(  );
//        }
//        else if(MecanumChassisSetPoint.behindLeftWheelSpeed < 0)
//        {
//            outBehindLeftWheelRetreat(  );
//        }
//        
//        if(MecanumChassisSetPoint.behindRightWheelSpeed > 0)
//        {
//            outBehindRightWheelForward(  );
//        }
//        else if(MecanumChassisSetPoint.behindRightWheelSpeed < 0)
//        {
//            outBehindRightWheelRetreat(  );
//        }
        
        
//        behindLeftWheelPid.SetPoint = MecanumChassisSetPoint.behindLeftWheelSpeed;
//        behindRightWheelPid.SetPoint = MecanumChassisSetPoint.behindRightWheelSpeed;
        
    }
    
    if( (frontRightWheelPid.SetPoint !=0) && ( MecanumChassisReal.frontRightWheelSpeed == 0 ) && (SingleTimeoutCheck( frontTurnWheelTime, 200 ) == TimeOut) )
    {
        robotMotion.frontRightEncodeError = BitSet;
    }
    else
    {
        robotMotion.frontRightEncodeError = BitReset;
    }
    
    if( (behindLeftWheelPid.SetPoint !=0) && ( MecanumChassisReal.behindLeftWheelSpeed == 0 ) && (SingleTimeoutCheck( behindLeftWheelTime, 200 ) == TimeOut) )
    {
        robotMotion.behindLeftEncodeError = BitSet;
    }
    else
    {
        robotMotion.behindLeftEncodeError = BitReset;
    }
    
    if( (behindRightWheelPid.SetPoint !=0) && ( MecanumChassisReal.behindRightWheelSpeed == 0 ) && (SingleTimeoutCheck( behindRightWheelTime, 200 ) == TimeOut) )
    {
        robotMotion.behindRightEncodeError = BitSet;
    }
    else
    {
        robotMotion.behindRightEncodeError = BitReset;
    }
}






#if 1

///*******************************************************************************
//* Function Name  : sPidAdjust
//* Description    : PID�㷨ʵ��
//* Input          :
//* Output         : None
//* Return         : None
//*******************************************************************************/
int16_t sPidAdjust( PidStruct *pid, int32_t RealPoint )
{	
	
	int16_t PidCtrlOut,Error,dError; 
   	int16_t SetPoint = pid->SetPoint;
    
    Error = abs(SetPoint) - abs(RealPoint);               //ƫ��
    pid->SumError += Error;                               //����        
    dError = Error - pid->LastError;
    pid->LastError = Error;
    
    if( pid->SumError>500 ) 
    {
        pid->SumError = 500;
    }
    else if( pid->SumError<-500 )
    {
        pid->SumError = -500;
    }

    /***********|****������****||********������*******||****΢����****|*/
    PidCtrlOut = (pid->Kp*Error + pid->Ki*pid->SumError + pid->Kd*dError);
    return PidCtrlOut;
  
}
    



  
 
/*******************************************************************************
* Function Name  : vWheelSpeedAdjust
* Description    : 
* Input          :
* Output         : None
* Return         : None
*******************************************************************************/
int16_t speed_temp;
int16_t speed_now;


void vWheelSpeedAdjust( void )
{
   
    int16_t FrontLeftPidTemp, FrontRightPidTemp, BehindLeftPidTemp,BehindRightPidTemp ;
    uint16_t FrontLeftDuty, FrontRightDuty, BehindLeftDuty,BehindRightDuty;
    static int32_t left_temp,right_temp;
    static uint32_t count;
    
    speed_now = -(MecanumChassisReal.behindLeftWheelSpeed+MecanumChassisReal.behindRightWheelSpeed)/2;
    
    if(count<1000)
    {
        count+=20;
    }
    
/**********************************************************frontRightWheel**************************************************************************/
    
    if( frontRightWheelPid.SetPoint != 0 )
    {
        FrontRightPidTemp = sPidAdjust( &frontRightWheelPid, MecanumChassisReal.frontRightWheelSpeed );
        FrontRightDuty = (uint16_t)(TIM_GetCapture2( TIM8 ) + FrontRightPidTemp);
        if( (FrontRightDuty < TIM_PEROID) && (FrontRightDuty >= 0 ) ) SetFrontRightMotorDriverDuty( FrontRightDuty );
    }
    else if( MecanumChassisSetPoint.frontRightWheelSpeed == 0 )
    {
        outFrontRightWheelStop(  );
    }        
  
    
    if(inputRobotStopCheck(  ) == BitSet || (Mc6c.LockFlag == 2 && Mc6c.DisconFlag == 0 && Mc6c.RightKey == 0) || count<1000 || robotMotion.behindLeftWheelError || robotMotion.behindRightWheelError)
    {
       Clear_PID_Temp(&MBL_PID);
       Clear_PID_Temp(&MBR_PID);
       outBehindLeftWheelStop(  );
       outBehindRightWheelStop(  );
       robotMotion.speed = 0;
       robotMotion.robotVelocity = 0;
    }
    else
    {
        MBL_PID.target = MecanumChassisSetPoint.behindLeftWheelSpeed;
        MBL_PID.actual = MecanumChassisReal.behindLeftWheelSpeed;
        
        MBR_PID.target = MecanumChassisSetPoint.behindRightWheelSpeed;
        MBR_PID.actual = MecanumChassisReal.behindRightWheelSpeed;

        PID_IncrementMode(&MBL_PID , two_way);
        if(MBL_PID.ctrOut >= 0 && MBL_PID.ctrOut < 500){left_temp = 500;}
        else if(MBL_PID.ctrOut < 0 && MBL_PID.ctrOut > -500){left_temp = -500;}
        else {left_temp = MBL_PID.ctrOut;}
        
        
        if(left_temp >= 0){outBehindLeftWheelForward(  );}
        else{outBehindLeftWheelRetreat(  );}
        SetBehindLeftMotorDriverDuty(abs(left_temp));
        
        PID_IncrementMode(&MBR_PID , two_way);
        if(MBR_PID.ctrOut >= 0 && MBR_PID.ctrOut < 500){right_temp = 500;}
        else if(MBR_PID.ctrOut < 0 && MBR_PID.ctrOut > -500){right_temp = -500;}
        else {right_temp = MBR_PID.ctrOut;}
        
        if(right_temp >= 0){outBehindRightWheelForward(  );}
        else{outBehindRightWheelRetreat(  );}
        SetBehindRightMotorDriverDuty(abs(right_temp));
        
//        if(robotMotion.robotVelocity == 0 && robotMotion.speed == 0)
//        {
//            if(abs(MecanumChassisReal.behindLeftWheelSpeed) < 2000 || abs(MecanumChassisReal.behindRightWheelSpeed) < 2000)
//            {
//                //����
//                PID_IncrementMode(&MBL_PID , two_way);
//                
//                if(MBL_PID.ctrOut >= 0 && MBL_PID.ctrOut < 500){left_temp = 500;}
//                else if(MBL_PID.ctrOut < 0 && MBL_PID.ctrOut > -500){left_temp = -500;}
//                else {left_temp = MBL_PID.ctrOut;}
// 
//                if(left_temp >= 0){outBehindLeftWheelForward(  );}
//                else{outBehindLeftWheelRetreat(  );}
//                SetBehindLeftMotorDriverDuty(abs(left_temp));

//                
//                //����
//                PID_IncrementMode(&MBR_PID , two_way);
//                
//                if(MBR_PID.ctrOut >= 0 && MBR_PID.ctrOut < 500){right_temp = 500;}
//                else if(MBR_PID.ctrOut < 0 && MBR_PID.ctrOut > -500){right_temp = -500;}
//                else {right_temp = MBR_PID.ctrOut;}

//                if(right_temp >= 0){outBehindRightWheelForward(  );}
//                else{outBehindRightWheelRetreat(  );}
//                SetBehindRightMotorDriverDuty(abs(right_temp));

//            }
//            else
//            {
//               Clear_PID_Temp(&MBL_PID);
//               Clear_PID_Temp(&MBR_PID);
//               outBehindLeftWheelStop(  );
//               outBehindRightWheelStop(  );
//            }
//        }
//        else
//        {
//            PID_IncrementMode(&MBL_PID , two_way);
//            if(MBL_PID.ctrOut >= 0 && MBL_PID.ctrOut < 500){left_temp = 500;}
//            else if(MBL_PID.ctrOut < 0 && MBL_PID.ctrOut > -500){left_temp = -500;}
//            else {left_temp = MBL_PID.ctrOut;}
//            
////            left_temp = MBL_PID.ctrOut;
//            
//            if(left_temp >= 0){outBehindLeftWheelForward(  );}
//            else{outBehindLeftWheelRetreat(  );}
//            SetBehindLeftMotorDriverDuty(abs(left_temp));
//            
//            PID_IncrementMode(&MBR_PID , two_way);
//            if(MBR_PID.ctrOut >= 0 && MBR_PID.ctrOut < 500){right_temp = 500;}
//            else if(MBR_PID.ctrOut < 0 && MBR_PID.ctrOut > -500){right_temp = -500;}
//            else {right_temp = MBR_PID.ctrOut;}
//            
////            right_temp = MBR_PID.ctrOut;
//            if(right_temp >= 0){outBehindRightWheelForward(  );}
//            else{outBehindRightWheelRetreat(  );}
//            SetBehindRightMotorDriverDuty(abs(right_temp));
//        }
    }
}


#endif

