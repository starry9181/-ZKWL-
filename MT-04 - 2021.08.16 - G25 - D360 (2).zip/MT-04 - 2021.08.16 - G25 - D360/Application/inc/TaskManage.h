#ifndef __TASKMANAGE_H
#define __TASKMANAGE_H


/*******C File Head********/
#include <stdint.h>
#include <stdbool.h>
#include <stdio.h>	
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

typedef enum { False = 0, True = !False } MyBool;
typedef enum { BitReset = 0, BitSet = !BitReset } BitState;
typedef enum { FALSE = 0, TRUE = !FALSE }RetrunState;


/*****FreeRTOS******/
#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "semphr.h"

/******************STM32 MCU******************************/
#include "stm32f10x.h"
#include "GpioOut.h"
#include "GpioInput.h"
#include "usart.h"
#include "IWDG.h"
#include "pwm.h"
#include "tim.h"
#include "spi.h"
#include "can.h"
#include "adc.h"

#include "timerEncode.h"
#include "pid.h"
#include "pulsePWM.h"
#include "motorContrl.h"
#include "driverTask.h"


/******************Protocol******************************/
#include "CanNet.h"
#include "ps2Contrl.h"
#include "DataScope_DP.h"
#include "robotProtocol.h"
#include "singleEncode.h"
#include "modbus.h"
#include "protocolTask.h"
#include "mc6c.h"

/******************Application******************************/
#include "SystemTime.h"
#include "robotContrl.h"


#define SystemSetBit( EVEN, BIT )        (EVEN) |= (1<<BIT)
#define SystemResetBit( EVEN, BIT )      (EVEN) &= ~(1<<BIT)
#define SystemReadBit( EVEN, BIT )       ( (EVEN >> BIT) & 0x01 )

extern TaskHandle_t xHandleTaskInfraredDecoding;


uint8_t FreeRTOS_MemoryCompare( uint8_t *source, uint8_t *target, uint8_t length );
void FreeRTOS_MemoryCopy( uint8_t *source, uint8_t *target, uint8_t length );
void HardwareDriverInit(void);
void TaskCreateFunction(void);

#endif
