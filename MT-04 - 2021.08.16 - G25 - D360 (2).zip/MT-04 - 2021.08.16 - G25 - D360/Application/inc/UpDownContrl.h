#ifndef __UPDOWNCONTRL_H
#define __UPDOWNCONTRL_H
#include "TaskManage.h"


typedef enum{
	NoKeyDown = 0,
	ButtonOnDown ,
	ButtonOffDown ,
	ButtonFrontDown ,
	ButtonBackDown ,
	ButtonLeftDonw ,
	ButtonRightDown ,
	ButtonKey1OnDown ,
	ButtonKey1OffDown ,
	ButtonKey2OnDown ,
	ButtonKey2OffDown ,
	ButtonKey3OnDown ,
	ButtonKey3OffDown ,
	ButtonKey4OnDown ,
	ButtonKey4OffDown ,
    DevicePair
}KeyState;




typedef enum{
	StopUpDown = 0,
	Up1Inches,
    Down1Inches,
    Up2Inches,
    Down2Inches,
    Up3Inches,
    Down3Inches,
    Up4Inches,
    Down4Inches
    
}UpDownHeight;





extern KeyState KeyDownState;
void LightUpDown( void );
void vGetRemoteState( void *pInfo );
void UpDownContrlWorkTask( void *Parammenters );

#endif
