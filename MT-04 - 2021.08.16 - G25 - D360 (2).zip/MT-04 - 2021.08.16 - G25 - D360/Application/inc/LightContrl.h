#ifndef __LIGHTCONTRL_H
#define __LIGHTCONTRL_H

#include "TaskManage.h"


typedef enum{
	robotStop = 0,
	robotForward,
	robotTurnLeft,
	robotTurnRight,
	robotRtreate
}RobotRunState;


void SetRobotRunState( RobotRunState RobotState );
RobotRunState GetRobotRunState( void );
void SystemLightContrl( RobotRunState State );


#endif