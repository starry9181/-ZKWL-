#ifndef __WALK_H
#define __WALK_H
#include "TaskManage.h"

extern uint8_t ButtJointFlag;

RetrunState SetCarWalkDirection( void );
void SystemCarWalkTask( void *Parammenters );



#endif
