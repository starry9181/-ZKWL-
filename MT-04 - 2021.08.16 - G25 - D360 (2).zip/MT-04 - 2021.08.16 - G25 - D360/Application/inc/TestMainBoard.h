#ifndef __TESTMAINBOARD_H
#define __TESTMAINBOARD_H

#include "TaskManage.h"


#define MainDataHead        0x0a05        //����ͷ

#define TestCommand         0x01          //��������
#define TestResult          0x02          //���Խ������
#define EnterTest           0x03          //�������ģʽ
#define TestDone            0x04          //�������


typedef enum{
    LowState = 1,
    HighState
}TestState;


typedef struct {
    uint8_t TestNumber;                   //���ԣ�������
    TestState State;                      //���ԣ����״̬
}MainBoardParameter;


/****************************************���Խ�����*********************************************/
#define NumberPower12V                     1         
#define NumberPower5V                      2
#define NumberPower3V3                     3
#define NumberLeftMotorDriver1             4
#define NumberLeftMotorDriver2             5
#define NumberRightMotorDriver1            6
#define NumberRightMotorDriver2            7
#define NumberRollsDriver                  8
#define NumberLeftBrushDriver              9
#define NumberRightBrushDriver             10
#define NumberInfraredDriver               11
#define NumberDropDriver                   12
#define NumberFanPower                     13




extern MainBoardParameter * const pMainTest;

__inline void AllTestDone( void );
__inline void CommunicationWithMainBoard( void );
void TestMainBoardTask( void *Parammenters );
void RecordTestFalseResult( uint8_t TestNumber );
void SetTestMainboardRestart( void );
void SetTestOutputHigh( void );
void SetTestOutputLow( void );
void SenCommandToMainBoard( uint8_t Command, uint8_t Number, TestState State );
uint8_t AnalysisMainBoardCommand( uint8_t Buffer[], MainBoardParameter *pTestMain, uint8_t Length );

#endif
