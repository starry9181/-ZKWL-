#ifndef __SYSTEMTIME_H
#define __SYSTEMTIME_H
#include "TaskManage.h"


typedef enum { NotTimeOut = 0, TimeOut = !NotTimeOut } SystemTimeOutState;



TickType_t GetOSRunTimeNow( void );
SystemTimeOutState SingleTimeoutCheck( TickType_t Time, uint32_t mSTimeOut );
SystemTimeOutState MultipleTimeoutCheck( TickType_t *pTime, uint32_t mSTimeOut );





#endif
