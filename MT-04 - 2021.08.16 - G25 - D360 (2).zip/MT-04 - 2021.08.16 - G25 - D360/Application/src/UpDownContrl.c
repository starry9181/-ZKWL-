/**********************************************************************************
 * Filename   ��nrf24l01.c
 * Author     : Liu Tusheng       
 * Version    : 1.0
 * Date       : 2017.12.21
 * Discription : 
 * Hardware Connet:
**********************************************************************************/ 
#include "UpDownContrl.h"

#define UP_DOWN_TIME  1456

 
#define AUTO_ADJUST_HIGH   1600 //28*25.4


/*******************************************************************************
* Function Name  : UpDownContrlWorkTask
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void UpDownContrlWorkTask( void *Parammenters )
{
    uint8_t Buffer[50], length;

    while( 1 )
    {
       
        LightUpDown(  );
        vTaskDelay( 10 );
    }
    
}



/*******************************************************************************
* Function Name  : vGetRemoteState
* Description    : 
* Input          : None         
* Output         : None
* Return         : None
*******************************************************************************/
void vGetRemoteState( void *pInfo )
{
    ComInfo *pComInfo = ( ComInfo* )pInfo;
    
	switch( pComInfo->Command )
	{
		case SET_SYSTEM_DOWM:
//            UpDownTime = GetOSRunTimeNow(  );
            
			break;
		
		case SET_SYSTEM_UP:
//			UpDownTime = GetOSRunTimeNow(  );
           
			break;

		default:
           
			break;
		
	}
	
	
}







/*******************************************************************************
* Function Name  : LightUpDown
* Description    : 
* Input          : None         
* Output         : None
* Return         : None
*******************************************************************************/
void LightUpDown( void )
{
    uint8_t CanData = 0;
    static bool StopFlag = false;
    static bool UpFlag = false;
    static bool DownFlag = false;
    static TickType_t UpDownTime = 0; 
    
   
//    if( MultipleTimeoutCheck( &UpDownTime, 1000 ) == TimeOut )
//    {
//        UpFlag = false;
//        DownFlag = false;
//    }
    
    
    
    
    if( (systemUltrasonic.AverageDistance >= (AUTO_ADJUST_HIGH-20)) && (systemUltrasonic.AverageDistance <= (AUTO_ADJUST_HIGH+20)) )
    {
       
        CanData = STOP_MOVE_COMMAND;
        PackageCanBackageSendToNode( UtrasonicBoardID, UpDownBoardID, STOP_MOVE_COMMAND, &CanData, 1 );
        PackageCanBackageSendToNode( UtrasonicBoardID, UpDownBoardID, STOP_MOVE_COMMAND, &CanData, 1 );
        PackageCanBackageSendToNode( UtrasonicBoardID, UpDownBoardID, STOP_MOVE_COMMAND, &CanData, 1 );
//        StopFlag = true;
        UpFlag = false;
        DownFlag = false;
//        return;
//            outLightStop(  ); 
    }            
    if( (DownFlag == false) && (systemUltrasonic.AverageDistance >= (AUTO_ADJUST_HIGH+10)) )
    {
        if( ReadDropDepthDownAllow(  ) == true )
        {
            CanData = DOWN_COMMAND;
            PackageCanBackageSendToNode( UtrasonicBoardID, UpDownBoardID, DOWN_COMMAND, &CanData, 1 );
            PackageCanBackageSendToNode( UtrasonicBoardID, UpDownBoardID, DOWN_COMMAND, &CanData, 1 );
            PackageCanBackageSendToNode( UtrasonicBoardID, UpDownBoardID, DOWN_COMMAND, &CanData, 1 );
//            StopFlag = false;
            UpFlag = false;
            DownFlag = true;
        }
       
    }            
    else if( (UpFlag == false) && (systemUltrasonic.AverageDistance <= (AUTO_ADJUST_HIGH-10)) ) 
    {
        
        if( ReadDropDepthUpAllow(  ) == true )
        {
            CanData = UP_COMMAND;
            PackageCanBackageSendToNode( UtrasonicBoardID, UpDownBoardID, UP_COMMAND, &CanData, 1 );
            PackageCanBackageSendToNode( UtrasonicBoardID, UpDownBoardID, UP_COMMAND, &CanData, 1 );
            PackageCanBackageSendToNode( UtrasonicBoardID, UpDownBoardID, UP_COMMAND, &CanData, 1 );
//            StopFlag = false;
            UpFlag = true;
            DownFlag = false;
        }
        
    }
    
//    if( (DownFlag == true) && ( systemUltrasonic.AverageDistance < (AUTO_ADJUST_HIGH-50) ) )
//    {
//        CanData = STOP_MOVE_COMMAND;
//        PackageCanBackageSendToNode( UtrasonicBoardID, UpDownBoardID, STOP_MOVE_COMMAND, &CanData, 1 );
//        PackageCanBackageSendToNode( UtrasonicBoardID, UpDownBoardID, STOP_MOVE_COMMAND, &CanData, 1 );
//        PackageCanBackageSendToNode( UtrasonicBoardID, UpDownBoardID, STOP_MOVE_COMMAND, &CanData, 1 );
//        StopFlag = true;
//        UpFlag = false;
//        DownFlag = false;

//    }
//    
//    if( (UpFlag == true) && ( systemUltrasonic.AverageDistance > (AUTO_ADJUST_HIGH+50) ) )
//    {
//       
//        CanData = STOP_MOVE_COMMAND;
//        PackageCanBackageSendToNode( UtrasonicBoardID, UpDownBoardID, STOP_MOVE_COMMAND, &CanData, 1 );
//        PackageCanBackageSendToNode( UtrasonicBoardID, UpDownBoardID, STOP_MOVE_COMMAND, &CanData, 1 );
//        PackageCanBackageSendToNode( UtrasonicBoardID, UpDownBoardID, STOP_MOVE_COMMAND, &CanData, 1 );
//        StopFlag = true;
//        UpFlag = false;
//        DownFlag = false;
//    }
    
    if( (DownFlag == true) && ( ReadDropDepthDownAllow(  ) != true ) )
    {
        CanData = STOP_MOVE_COMMAND;
        PackageCanBackageSendToNode( UtrasonicBoardID, UpDownBoardID, STOP_MOVE_COMMAND, &CanData, 1 );
        PackageCanBackageSendToNode( UtrasonicBoardID, UpDownBoardID, STOP_MOVE_COMMAND, &CanData, 1 );
        PackageCanBackageSendToNode( UtrasonicBoardID, UpDownBoardID, STOP_MOVE_COMMAND, &CanData, 1 );
//        StopFlag = true;
        UpFlag = false;
        DownFlag = true;
        //return;
    }
    
    if( (UpFlag == true) && ( ReadDropDepthUpAllow(  ) != true ) )
    {
       
        CanData = STOP_MOVE_COMMAND;
        PackageCanBackageSendToNode( UtrasonicBoardID, UpDownBoardID, STOP_MOVE_COMMAND, &CanData, 1 );
        PackageCanBackageSendToNode( UtrasonicBoardID, UpDownBoardID, STOP_MOVE_COMMAND, &CanData, 1 );
        PackageCanBackageSendToNode( UtrasonicBoardID, UpDownBoardID, STOP_MOVE_COMMAND, &CanData, 1 );
//        StopFlag = true;
        UpFlag = true;
        DownFlag = false;
        //return;
    }
    
//    else if( StopFlag == false )
//    {
//        CanData = STOP_MOVE_COMMAND;
//        PackageCanBackageSendToNode( UtrasonicBoardID, UpDownBoardID, STOP_MOVE_COMMAND, &CanData, 1 );
//        PackageCanBackageSendToNode( UtrasonicBoardID, UpDownBoardID, STOP_MOVE_COMMAND, &CanData, 1 );
//        PackageCanBackageSendToNode( UtrasonicBoardID, UpDownBoardID, STOP_MOVE_COMMAND, &CanData, 1 );
//        StopFlag = true;
//    }


}


