/******************************************************************************
* �ļ���  ��IoOut.c
* �ļ�����:
* ������  ��Liu Tusheng
* ��    �գ�2017��11��27��
* Ӳ�����ӣ�
* 
******************************************************************************/
#include "LightContrl.h"

RobotRunState RobotState = robotStop;




/*******************************************************************************
* Function Name  : SetRobotRunState
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SetRobotRunState( RobotRunState State )
{
	RobotState = State;
}


/*******************************************************************************
* Function Name  : GetRobotRunState
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
RobotRunState GetRobotRunState( void )
{
	return RobotState;
}



/*******************************************************************************
* Function Name  : SystemLightContrl
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SystemLightContrl( RobotRunState State )
{
	static TickType_t StopTime = 0, ForwardTime = 0, TurnLeftTime = 0,
	TurnRightTime = 0, RtreateTime = 0;	
	
	switch( State )
	{
		case robotStop:
			if( MultipleTimeoutCheck( &StopTime, 500 ) == TimeOut )
			{
				outTurnLeftLightOFF(  );
				outTurnRightLightOFF(  );
				outTopLightRedOFF(  );
				outTopLightGreenOFF(  );
				outTopLightYellowBlink(  );
			}
			break;
		
		case robotForward:
			if( MultipleTimeoutCheck( &ForwardTime, 500 ) == TimeOut )
			{
				outTurnLeftLightOFF(  );
				outTurnRightLightOFF(  );
				outTopLightRedOFF(  );
				outTopLightGreenBlink(  );
				outTopLightYellowOFF(  );
			}
			break;
		
		case robotTurnLeft:
			if( MultipleTimeoutCheck( &ForwardTime, 500 ) == TimeOut )
			{
				outTurnLeftLightBlink(  );
				outTurnRightLightOFF(  );
				outTopLightRedOFF(  );
				outTopLightGreenBlink(  );
				outTopLightYellowOFF(  );
			}
			break;
		
		case robotTurnRight:
			if( MultipleTimeoutCheck( &ForwardTime, 500 ) == TimeOut )
			{
				outTurnLeftLightOFF(  );
				outTurnRightLightBlink(  );
				outTopLightRedOFF(  );
				outTopLightGreenBlink(  );
				outTopLightYellowOFF(  );
			}
			break;
		
		case robotRtreate:
			if( MultipleTimeoutCheck( &ForwardTime, 500 ) == TimeOut )
			{
				outTurnLeftLightBlink(  );
				outTurnRightLightBlink(  );
				outTopLightRedBlink(  );
				outTopLightGreenOFF(  );
				outTopLightYellowOFF(  );
			}
			break;
		
		default:
			break;
	}
	
}




