/**********************************************************************************
 * Filename   ��robotContrl.c
 * Author     : Liu Tusheng       
 * Version    : 1.0
 * Date       : 2019.5.21
 * Discription : 
 * Hardware Connet:
**********************************************************************************/ 
#include "robotContrl.h"
#include <math.h>


#define  L1   840.0   //���
#define  L2   690.0   //�־�

uint32_t can_overtime;


robotMotionPostrue robotMotion = {0, 0, 0};
Akeman AkemanDiffrentSpeed;

void ps2DataFuse( void *data );


/*******************************************************************************
* Function Name  : SystemProtocolTask
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SystemrobotContrlTask( void *Parammenters )
{
    
    vPidStructInit(  );

    
    while( 1 )
    {
        remoteContrl( &robotMotion );
        robotAttitudeAlgorithm( &robotMotion );
        UpDownSpeed(  );
        
        if( !(Mc6c.DisconFlag == 0 && Mc6c.LeftKey == 2) )//|| Mc6c.DisconFlag == 1
        {
            if(can_overtime > 1000)
            {
                robotMotion.robotVelocity = 0;
                robotMotion.robotAckermanAngle = 0;
            }
            else
            {
                can_overtime += 10;
            }
        }

        gpioInputCheck(  );
        vTaskDelay(10);
    }
    
}


void Error_Beep( void *Parammenters)
{
    static uint16_t cnt;
    while(1)
    {
        if((robotMotion.behindLeftWheelError || robotMotion.behindRightWheelError || robotMotion.frontRightWheelError) && cnt >= 2000)
        {
            outBuzzerBlink(  );
        }
        else if(cnt >= 2000)
        {
            outBuzzerOFF(  );
        }
        if(cnt < 3000) cnt += 500;
        
        vTaskDelay(500);
    }
}


//float angle, k, b,R;
float setEncodeAngle;
/*******************************************************************************
* Function Name  : robotAttitudeAlgorithm
* Description    :  
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void robotAttitudeAlgorithm( void *data )
{
    robotMotionPostrue *pRobotMotion = (robotMotionPostrue *) data;
    static float k, angle;
    
    pRobotMotion->speed = Acc_Handler(1000/100 , 2000/100 , 1000/100 , 2000/100 , pRobotMotion->robotVelocity , pRobotMotion->speed); // pRobotMotion->speed
    
    
    
    //���������ֲ��ٴ���
    angle = Enc_Change_Angle(EncdoeAngle.centreAngle);
    k = L1/(L1 + L2 * tan(fabs(angle)*3.14f/180));
    if( (pRobotMotion->frontCrash != BitSet) && (pRobotMotion->behindCrash != BitSet) )
    {
        if(angle>0)
        {
            pRobotMotion->robotVelocityRight = 2.0f * pRobotMotion->speed / (1.0f + k);  //��������ٶ����÷���
            pRobotMotion->robotVelocityLeft = pRobotMotion->robotVelocityRight * k;
        }
        else if(angle<0)
        {
            pRobotMotion->robotVelocityLeft = 2.0f * pRobotMotion->speed / (1.0f + k);  //��������ٶ����÷���
            pRobotMotion->robotVelocityRight = pRobotMotion->robotVelocityLeft * k;
        }
        else
        {
            pRobotMotion->robotVelocityRight = pRobotMotion->robotVelocityLeft = pRobotMotion->speed;
        }
        motorSetBehindLeftWheelSpeed( pRobotMotion->robotVelocityLeft );  
        motorSetBehindRightWheelSpeed( pRobotMotion->robotVelocityRight );
    }
    else
    {
        pRobotMotion->robotVelocityRight = pRobotMotion->robotVelocityLeft = 0;
//        motorSetBehindLeftWheelSpeed(0);  
//        motorSetBehindRightWheelSpeed(0);
    }

    turnLeftRightPidAdjust( pRobotMotion->robotAckermanAngle, EncdoeAngle.centreAngle );
}






/*******************************************************************************
* Function Name  : remoteContrl
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void remoteContrl( void *data )
{
    static uint8_t Buzzer = 0;
    static TickType_t BuzzerTime = 0;
    static bool DisconFlag = false;
    static uint8_t LeftKey = 0;
    
    robotMotionPostrue *pRobotMotion = (robotMotionPostrue *) data;
    if( (Mc6c.LockFlag == 2) && (Mc6c.LeftKey == 2) )
    {
        if( Mc6c.RightKey == 1 )
        {
            robotMotion.scram = BitReset;
            pRobotMotion->robotVelocity = 3.0*Mc6c.LeftY;   
            pRobotMotion->robotAckermanAngle = Mc6c.RightX/5.4f;
        }
        else
        {
            robotMotion.scram = BitSet;
            pRobotMotion->robotVelocity = 0;
            motorSetFrontRightWheelSpeed( 0 );
            outFrontRightWheelStop(  );
            outBehindLeftWheelStop(  );
            outBehindRightWheelStop(  );
        }
        
        if( (Buzzer < 4) && (MultipleTimeoutCheck( &BuzzerTime, 250 ) == TimeOut ) )
        {
            Buzzer++;
            outBuzzerBlink(  );
        }
        LeftKey = 2;
    }
    else if( (Mc6c.LockFlag == 2) && (Mc6c.LeftKey != 2) && (LeftKey == 2) )
    {
        LeftKey = 1;
        pRobotMotion->robotVelocity = 0;
        pRobotMotion->robotAckermanAngle = 0.0;
        
    }
    else if( Mc6c.LockFlag == 0 )
    {
        Buzzer = 0;
    }
    
    if( (Mc6c.DisconFlag == 1) && (DisconFlag == false) && Mc6c.LeftKey != 1) //ң�������ߴ���
    {
        DisconFlag = true;
        pRobotMotion->robotVelocity = 0;   
//        motorSetFrontRightWheelSpeed( 0 );
//        outFrontRightWheelStop(  );
//        outBehindLeftWheelStop(  );
//        outBehindRightWheelStop(  );
        
    }
    else if( (Mc6c.DisconFlag == 0) && (DisconFlag == true) )
    {
        DisconFlag = false;
    }
}





int16_t Acc_Handler(uint16_t facc , uint16_t fdec , uint16_t bacc , uint16_t bdec , int16_t target , int16_t now_set)
{
    int16_t new_set , err_temp;
    err_temp = target - now_set;
    
    if(target >= 0)
    {
        if(now_set >= 0)
        {
            if(err_temp > facc){new_set = now_set + facc;}
            else if(err_temp < -fdec){new_set = now_set - fdec;}
            else{new_set = target;}
        }
        else
        {
            if(err_temp > bdec){new_set = now_set + bdec;}
            else{new_set = target;}
        }
    }
    else
    {
        if(now_set >= 0)
        {
            if(err_temp < -fdec){new_set = now_set - fdec;}
            else{new_set = target;}
        }
        else
        {
            if(err_temp < -bacc){new_set = now_set - bacc;}
            else if(err_temp > bdec){new_set = now_set + bdec;}
            else{new_set = target;}
        }
    }
    
    
    return new_set;
}


uint8_t Flag_Filter(Flag_Filter_Type * filter , uint8_t flag , uint32_t filter_cnt)
{
    uint8_t flag_temp;
    flag_temp = (flag == 0) ? 0 : 1 ;
    
    if(filter_cnt < 2)
    {
        return flag;
    }
    
    if(filter_cnt != filter->max_cnt)
    {
        filter->now_cnt = filter_cnt/2;
    }
    
    filter->max_cnt = filter_cnt;
    
    if(flag_temp != filter->last_flag)
    {
        filter->now_cnt = filter->max_cnt/2;
    }
    else
    {
        if(flag_temp)
        {
            filter->now_cnt < filter->max_cnt ? filter->now_cnt++ : 0;
        }
        else
        {
            filter->now_cnt > 0 ? filter->now_cnt-- : 0;
        }
    }
    filter->last_flag = flag_temp;
    
    if(filter->now_cnt > filter->max_cnt-1)
    {
        filter->return_flag = 1;
    }
    else if(filter->now_cnt < 1)
    {
        filter->return_flag = 0;
    }
    
    return filter->return_flag;  
}





