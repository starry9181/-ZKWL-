/**********************************************************************************
 * Filename   ��SystemTime.c
 * Author     : Liu Tusheng       
 * Version    : 1.0
 * Date       : 2016.5.25
 *Discription : 
**********************************************************************************/ 
#include "SystemTime.h"






/*******************************************************************************
* Function Name  : GetOSRunTimeNow
* Description    : ��ȡϵͳ����ʱ�䣬����һЩ��ʱ����
* Input          : None                
* Output         : None
* Return         : ϵͳ����ʱ��
*******************************************************************************/
TickType_t GetOSRunTimeNow( void )
{   
    TickType_t SystemTime;    
    
    static uint8_t ucTickTime = (1000/configTICK_RATE_HZ); //ϵͳʱ��Ƭʱ�䣬1s = 1000ms
    
    SystemTime = xTaskGetTickCount(  );
    SystemTime *= ucTickTime;

    
    return SystemTime;
}


/*******************************************************************************
* Function Name  : SingleTimeoutCheck
* Description    : ���γ�ʱ���
* Input          : Time:��ʼʱ�䣬mSTimeOut����ʱʱ��            
* Output         : None
* Return         : ��ʱ״̬
*******************************************************************************/
SystemTimeOutState SingleTimeoutCheck( TickType_t Time, uint32_t mSTimeOut )
{
    TickType_t SystemTime;
    
    SystemTime = xTaskGetTickCount(  );
    if( (SystemTime - Time) >= mSTimeOut )
    {
        return TimeOut;
    }
    return NotTimeOut;   
    
}



/*******************************************************************************
* Function Name  : MultipleTimeoutCheck
* Description    : ���γ�ʱ���
* Input          : *pTime:��ʼʱ�䣬mSTimeOut����ʱʱ��            
* Output         : None
* Return         : ��ʱ״̬
*******************************************************************************/
SystemTimeOutState MultipleTimeoutCheck( TickType_t *pTime, uint32_t mSTimeOut )
{
    TickType_t SystemTime;
    
    if( *pTime == 0 ) 
    {
        *pTime = xTaskGetTickCount(  );
    }
    else
    {
        SystemTime = xTaskGetTickCount(  );
        if( (SystemTime - *pTime) >= mSTimeOut )
        {
            *pTime = 0;
            return TimeOut;
        }
    }        
    
    return NotTimeOut;   
}







