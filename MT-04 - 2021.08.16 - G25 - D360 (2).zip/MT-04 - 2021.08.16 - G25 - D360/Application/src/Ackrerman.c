/**********************************************************************************
 * Filename   ��Akman.c
 * Author     : Liu Tusheng       
 * Version    : 1.0
 * Date       : 2019.8.27
 * Discription : 
 * Hardware Connet:
**********************************************************************************/ 
#include "Ackerman.h"







/*******************************************************************************
* Function Name  : CollectSensorModuleParameter
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void differentialMechanismBenhindWheel( void )
{
    if( EncdoeAngle.leftAngle > 1.0 )
    {
        
    }
    else if( EncdoeAngle.leftAngle < -1.0 )
    {
        
    }
    else
    {
    
    }
}
    

