/**********************************************************************************
 * Filename   ��main.c
 * Author     : Liu Tusheng       
 * Version    : 1.0
 * Date       : 2015.11.14
 *Discription :
**********************************************************************************/ 
#include "taskmanage.h"

void RCC_DefaultConfiguration( void );
void RCC_Configuration(void) ;

int main(void)
{		
//    RCC_Configuration(  );
    //RCC_DefaultConfiguration(  );
    /****Ӳ����ʼ��*****/
    Set_BL_PID(3,1.8,0,0,36000);
    Set_BR_PID(3,1.8,0,0,36000);

	HardwareDriverInit(  );

    
    /*****��������******/
	TaskCreateFunction(  );
    /****����������****/
	vTaskStartScheduler(  );
    
	while( 1 )
    {
    
    }
					  	   
}


/********************************�ļ�����***********************************************/








