/**********************************************************************************
 * �ļ���  ��nrf24l01Mutual.c
 * ��    ��: Liu Tusheng       
 * ��    ��: 1.0
 * ��    ��: 2017.12.2
 * �ļ�����: 
 *
**********************************************************************************/ 
#include "nrf24l01Mutual.h"

ComInfo ProductInfo;


/*******************************************************************************
* Function Name  : ProductInformationInit
* Description    : Read flash data
* Input          : None
* Output         : None
* Return         : flash data
*******************************************************************************/
void ProductInformationInit( void *pInfo, uint8_t command, ProductID pProductID, CommandType pCommandType )
{
    ComInfo *pInformation = ( ComInfo* )pInfo;
    
    pInformation->FactoryNumber = FACTORY_NUMBER;
    pInformation->ProductID = pProductID;
    pInformation->Versions = PRODUCT_VERSIONS;
    pInformation->CommandType = pCommandType;
    pInformation->Command = command;
}

/*******************************************************************************
* Function Name  : PackProductInformationData
* Description    : Read flash data
* Input          : None
* Output         : None
* Return         : flash data
*******************************************************************************/
void PackProductInformationData( void *pInfo, uint8_t buffer[], uint8_t length )
{
    ComInfo *pInformation = ( ComInfo* )pInfo;
    uint8_t i;
    
    for( i=0;i<length;i++ )
    {
        pInformation->Buffer[i] = buffer[i];
    }
    pInformation->DataLength = length;
}


/*******************************************************************************
* Function Name  : CheckOut
* Description    : Read flash data
* Input          : None
* Output         : None
* Return         : flash data
*******************************************************************************/
uint16_t CheckOut( uint8_t *pBuffer, uint8_t Length )
{
	uint8_t i;
	uint16_t Resualt = 0;
	
	for( i=0;i<Length;i++ )
	{
        if( (i!= 9) && (i!=10) )
		Resualt += pBuffer[i];
	}	
	return Resualt;
}



/*******************************************************************************
* Function Name  : nRF24L01SendMassage
* Description    : 
* Input          : None
* Output         : None
* Return         : flash data
*******************************************************************************/
void nRF24L01SendMassage( void *pInfo )
{
    ComInfo *pComInfo = ( ComInfo* )pInfo;
	uint8_t buffer[30],i;
	uint16_t Resualt = 0;
	
	buffer[0] = (NRF_HEAD>>8)&0xFF;
	buffer[1] = NRF_HEAD & 0xFF;
	buffer[2] = pComInfo->FactoryNumber;
    buffer[3] = pComInfo->ProductID;
    buffer[4] = (pComInfo->Versions>>8)&0xFF;
	buffer[5] = pComInfo->Versions&0xFF;
    buffer[6] = pComInfo->CommandType;
    buffer[7] = pComInfo->Command;
    buffer[8+pComInfo->DataLength] = pComInfo->DataLength;
	Resualt = CheckOut( buffer, 7 );
    buffer[9] = (Resualt>>8)&0xFF;
	buffer[10] = Resualt&0xFF;
    for( i=0;i<pComInfo->DataLength;i++ )
    {
        buffer[10+i] = pComInfo->Buffer[i];
    }
	WriteDataToNRF24L01( buffer, 11+pComInfo->DataLength );
	
}



/*******************************************************************************
* Function Name  : AnalysisnRF24L01ReceiveMassage
* Description    : 
* Input          : None
* Output         : None
* Return         : command
*******************************************************************************/
MyBool AnalysisnRF24L01ReceiveMassage( void *pInfo )
{
    ComInfo *pComInfo = ( ComInfo* )pInfo;
	uint8_t buffer[30], command = 0, length;
	uint16_t head, id, versions, resualt = 0, check;
	
	length = ReadDataFromNRF24L01( buffer );
	
	head = (buffer[0]<<8) | buffer[1];
	pComInfo->FactoryNumber = buffer[2];
    pComInfo->ProductID = buffer[3];
    pComInfo->Versions = (buffer[4]<<8) | buffer[5];
    pComInfo->CommandType = buffer[6];
    pComInfo->Command = buffer[7];
    pComInfo->DataLength = buffer[8];
    
    check = (buffer[9]<<8) | buffer[10];
	resualt = CheckOut( buffer, length );
	
    if( (head!=NRF_HEAD) || (pComInfo->FactoryNumber != FACTORY_NUMBER ) || (pComInfo->ProductID!=PRODUCT_ID) || (pComInfo->Versions!=PRODUCT_VERSIONS) || (check!=resualt) )
    {
        return False;
    }
	return True;
}


/*******************************************************************************
* Function Name  : nRF24L01Mutual
* Description    : 
* Input          : None
* Output         : None
* Return         : command
*******************************************************************************/
void nRF24L01Mutual( void )
{
	SPI_GetNRF24L01Event(  );
	if( ReadNRF24L01Flag( nRF24L01_Event, RX_DR ) == BitSet )
	{
		ResetNRF24L01Flag( nRF24L01_Event, RX_DR );
        if( AnalysisnRF24L01ReceiveMassage( &ProductInfo ) == True )
        {
            vGetRemoteState( &ProductInfo );
        }
//        nRF24L01ReceiveCommand(  );
	}
}

