/**********************************************************************************
 * Filename   ��robotProtocol.c
 * Author     : Liu Tusheng       
 * Version    : 1.0
 * Date       : 2019.5.21
 * Discription : 
 * Hardware Connet:
**********************************************************************************/ 
#include "robotProtocol.h"


/*******************************************************************************
* Function Name  : CheckOut
* Description    : �ۼ���У������㺯��
* Input          : pBuffer: ��Ҫ�����У�����ݻ���
                   length����Ҫ�����У�����ݳ���
* Output         : None
* Return         : Check:У����
*******************************************************************************/
static uint16_t CheckOut( uint8_t *pBuffer, uint8_t length )
{
	uint16_t Check = 0, i;
	
	for( i=0; i<length; i++ )
	{
        if( (i == 5) || ( i== 6 ) )
        {
        
        }
        else 
        {
            Check += pBuffer[i];
        }
	}
	return Check;
}


/*******************************************************************************
* Function Name  : PackageCommandMessageToUSART
* Description    : �����������Ϣ����
* Input          : command������
                   pBuffer��Ҫ���͵�����
                   dataNumber�����ݸ���
                   length�����ݳ���
* Output         : None
* Return         : ����true
*******************************************************************************/
bool PackageCommandMessageToUSART( uint16_t command, void *pBuffer, uint8_t length )
{
	uint8_t buffer[USART2_TRANSMIT_BUFFER_SIZE];     
	uint16_t Check;
    
	
    buffer[0] = PROTOCOL_PACK_HEAD & 0xFF;
    buffer[1] = (PROTOCOL_PACK_HEAD>>8) & 0xFF;
    buffer[2] = length+7;        //֡����
    buffer[3] = command & 0xFF;          //����
    buffer[4] = (command>>8) & 0xFF;     //����
   
	
    memcpy( &buffer[7], pBuffer, length );
	Check = CheckOut( buffer, length+7 );
	
    buffer[5] = Check & 0xFF;
	  buffer[6] = (Check>>8) & 0xFF;
	
	
	WriteDataToUSART2TrainsmitBuffer( buffer, length+7 );
	
	return true;
}



/*******************************************************************************
* Function Name  : protocolMessageAnalysisAndExtractMessageData
* Description    : ������Ϣ����
* Input          : pData��ͨ��Э��ṹ����ȡ����
                   pMessage�����ڽ��յ�����Ϣ����
                   MesLen�����ڽ��յ�����Ϣ���ݳ���
* Output         : None
* Return         : �ɹ�����true,ʧ�ܷ���false
*******************************************************************************/
bool protocolMessageAnalysisAndExtractMessageData( void *pData, uint8_t *pMessage, uint8_t MesLen )
{
	uint16_t Check;
	uint8_t i;
    float enc_temp , angle_temp;
    protocolPackageFront Data;
    protocolPackageFront *pPackgeData = &Data;
    robotMotionPostrue *pRobotMotion = (robotMotionPostrue*)pData;
    
	pPackgeData->head = (pMessage[1]<<8) | pMessage[0];
	pPackgeData->packageLength = pMessage[2];
    pPackgeData->command = (pMessage[4]<<8) | pMessage[3];
    
	Check = (pMessage[6]<<8) | pMessage[5];
	if( (pPackgeData->head != PROTOCOL_PACK_HEAD) || ( pPackgeData->packageLength != MesLen )  || ( Check != CheckOut( pMessage, MesLen ) ) )
	{
        if( pPackgeData->head  != PROTOCOL_PACK_HEAD )
        {
            ps2ProtocolDebug( "PACK_HEAD error\r\n" );
        }
        if( pPackgeData->packageLength != MesLen )
        {
            ps2ProtocolDebug( "Message length error\r\n" );
        }
        if( Check != CheckOut( pMessage, MesLen-2 ) )
        {
            ps2ProtocolDebug( "Message checkout error\r\n" );
        }
        for( i=0;i<MesLen;i++ )
        {
            printf("%x ", pMessage[i] ); 
        }
        printf("\r\n");
		return false;
	}
    
    if( (pPackgeData->command == SET_SPEDD_ANGLE) && (Mc6c.LeftKey == 1) )
    {
        memcpy( &pPackgeData->speed, &pMessage[7], 4 );
        pRobotMotion->robotVelocity = pPackgeData->speed;
//        pRobotMotion->robotAckermanAngle = pPackgeData->angle/100.0;
//        for( i=0;i<37;i++ )
//        {
//            if( pPackgeData->angle == canAngle[i].data )
//            {
//                pRobotMotion->robotAckermanAngle = canAngle[i].encodeAngle;
//            }
//        }
            angle_temp = pPackgeData->angle/100.0;
            if(angle_temp > 34) angle_temp = 34;
            else if(angle_temp < -34) angle_temp = -34;
            pRobotMotion->robotAckermanAngle = Angle_Change_Enc(angle_temp);
    }
    return true;
}













