/**********************************************************************************
 * Filename   ��modbus.c
 * Author     : Liu Tusheng       
 * Version    : 1.0
 * Date       : 2019.7.3
 * Discription : 
 * Hardware Connet:
**********************************************************************************/ 
#include "modbus.h"

uint32_t position = 0;


/****************************************************************************************************
 * @Brief    Single byte data inversion        
 * @Param    
 *            @DesBuf: destination buffer
 *            @SrcBuf: source buffer
 * @RetVal    None
 * @Note      (MSB)0101_0101 ---> 1010_1010(LSB)
 ***************************************************************************************************/
void InvertUint8(unsigned char *DesBuf, unsigned char *SrcBuf)
{
    int i;
    unsigned char temp = 0;

    for(i = 0; i < 8; i++)
    {
        if(SrcBuf[0] & (1 << i))
        {
            temp |= 1<<(7-i);
        }
    }
    DesBuf[0] = temp;
}
 


/****************************************************************************************************
 * @Brief    double byte data inversion        
 * @Param    
 *            @DesBuf: destination buffer
 *            @SrcBuf: source buffer
 * @RetVal    None
 * @Note      (MSB)0101_0101_1010_1010 ---> 0101_0101_1010_1010(LSB)
 ***************************************************************************************************/
void InvertUint16(unsigned short *DesBuf, unsigned short *SrcBuf)  
{  
    int i;  
    unsigned short temp = 0;    

    for(i = 0; i < 16; i++)  
    {  
        if(SrcBuf[0] & (1 << i))
        {          
            temp |= 1<<(15 - i);  
        }
    }  
    DesBuf[0] = temp;  
}
 

/****************************************************************************************************
 * @Brief    double byte data inversion        
 * @Param    
 *            @DesBuf: destination buffer
 *            @SrcBuf: source buffer
 * @RetVal    None
 * @Note      (MSB)0101_0101_1010_1010 ---> 0101_0101_1010_1010(LSB)
 ***************************************************************************************************/
unsigned short CRC16_CCITT(unsigned char *puchMsg, unsigned int usDataLen)  
{  
    unsigned short wCRCin = 0x0000;  
    unsigned short wCPoly = 0x1021;  
    unsigned char wChar = 0;  

    while (usDataLen--)     
    {  
        wChar = *(puchMsg++);  
        InvertUint8(&wChar, &wChar);  
        wCRCin ^= (wChar << 8); 

        for(int i = 0; i < 8; i++)  
        {  
            if(wCRCin & 0x8000)
            {
                wCRCin = (wCRCin << 1) ^ wCPoly; 
            }            
            else 
            {              
                wCRCin = wCRCin << 1;  
            }
        }  
    }  
    InvertUint16(&wCRCin, &wCRCin);  
    return (wCRCin) ;  
} 
  

/****************************************************************************************************
 * @Brief    double byte data inversion        
 * @Param    
 *            @DesBuf: destination buffer
 *            @SrcBuf: source buffer
 * @RetVal    None
 * @Note      (MSB)0101_0101_1010_1010 ---> 0101_0101_1010_1010(LSB)
 ***************************************************************************************************/
unsigned short CRC16_CCITT_FALSE(unsigned char *puchMsg, unsigned int usDataLen)  
{  
    unsigned short wCRCin = 0xFFFF;  
    unsigned short wCPoly = 0x1021;  
    unsigned char wChar = 0;  

    while (usDataLen--)     
    {  
        wChar = *(puchMsg++);  
        wCRCin ^= (wChar << 8); 

        for(int i = 0; i < 8; i++)  
        {  
            if(wCRCin & 0x8000)  
            {
                wCRCin = (wCRCin << 1) ^ wCPoly;  
            }
            else  
            {
                wCRCin = wCRCin << 1; 
            }            
        }  
    }  
    return (wCRCin) ;  
}  
 

/****************************************************************************************************
 * @Brief    double byte data inversion        
 * @Param    
 *            @DesBuf: destination buffer
 *            @SrcBuf: source buffer
 * @RetVal    None
 * @Note      (MSB)0101_0101_1010_1010 ---> 0101_0101_1010_1010(LSB)
 ***************************************************************************************************/
unsigned short CRC16_XMODEM(unsigned char *puchMsg, unsigned int usDataLen)  
{  
    unsigned short wCRCin = 0x0000;  
    unsigned short wCPoly = 0x1021;  
    unsigned char wChar = 0;  

    while (usDataLen--)     
    {  
        wChar = *(puchMsg++);  
        wCRCin ^= (wChar << 8);

        for(int i = 0; i < 8; i++)  
        {  
            if(wCRCin & 0x8000)  
            {
                wCRCin = (wCRCin << 1) ^ wCPoly;  
            }
            else
            {              
                wCRCin = wCRCin << 1;
            }
        }  
    }  
    return (wCRCin) ;  
}  
   

/****************************************************************************************************
 * @Brief    double byte data inversion        
 * @Param    
 *            @DesBuf: destination buffer
 *            @SrcBuf: source buffer
 * @RetVal    None
 * @Note      (MSB)0101_0101_1010_1010 ---> 0101_0101_1010_1010(LSB)
 ***************************************************************************************************/
unsigned short CRC16_X25(unsigned char *puchMsg, unsigned int usDataLen)  
{  
    unsigned short wCRCin = 0xFFFF;  
    unsigned short wCPoly = 0x1021;  
    unsigned char wChar = 0;  

    while (usDataLen--)     
    {  
        wChar = *(puchMsg++);  
        InvertUint8(&wChar, &wChar);  
        wCRCin ^= (wChar << 8); 

        for(int i = 0;i < 8;i++)  
        {  
            if(wCRCin & 0x8000)
            {              
                wCRCin = (wCRCin << 1) ^ wCPoly; 
            }            
            else  
            {
                wCRCin = wCRCin << 1; 
            }  
            
        }  
    }  
    InvertUint16(&wCRCin, &wCRCin);  
    return (wCRCin^0xFFFF) ;  
}  
   

/****************************************************************************************************
 * @Brief    double byte data inversion        
 * @Param    
 *            @DesBuf: destination buffer
 *            @SrcBuf: source buffer
 * @RetVal    None
 * @Note      (MSB)0101_0101_1010_1010 ---> 0101_0101_1010_1010(LSB)
 ***************************************************************************************************/
//unsigned short CRC16_MODBUS(unsigned char *puchMsg, unsigned int usDataLen)  
//{  
//    unsigned short wCRCin = 0xFFFF;  
//    unsigned short wCPoly = 0xA001;  
//    unsigned char wChar = 0;  
//    unsigned char Change = 0;
//    
//    while(usDataLen--)     
//    {  
//        wChar = *(puchMsg++);  
////        InvertUint8(&wChar, &wChar);  
//        wCRCin ^= wChar; 

//        for(int i = 0; i < 8; i++)  
//        {  
//            if(wCRCin & 0x0001) 
//            {
//                wCRCin = (wCRCin >> 1) ^ wCPoly;  
//            }
//            else  
//            {
//                wCRCin = wCRCin >> 1; 
//            }      

//        }  
//    }  
//    Change = wCRCin & 0xFF;
////    wCRCin = (wCRCin>>8) & 0xFF;
////    wCRCin = (Change<<8) | wCRCin;
////    wCRCin ^= 0x0000;
////    InvertUint16(&wCRCin, &wCRCin);  
//    
//    return (wCRCin) ;  
//} 
  
  
unsigned short CRC16_MODBUS(unsigned char *puchMsg, unsigned int usDataLen)  
{  
    unsigned short wCRCin = 0xFFFF;  
    unsigned short wCPoly = 0x8005;  
    unsigned char wChar = 0;  

    while (usDataLen--)     
    {  
        wChar = *(puchMsg++);  
        InvertUint8(&wChar, &wChar);  
        wCRCin ^= (wChar << 8); 

        for(int i = 0; i < 8; i++)  
        {  
            if(wCRCin & 0x8000) 
            {
                wCRCin = (wCRCin << 1) ^ wCPoly;  
            }
            else  
            {
                wCRCin = wCRCin << 1; 
            }            
        }  
    }  
    InvertUint16(&wCRCin, &wCRCin);  
    return (wCRCin) ;  
} 
  
  

  

/****************************************************************************************************
 * @Brief    double byte data inversion        
 * @Param    
 *            @DesBuf: destination buffer
 *            @SrcBuf: source buffer
 * @RetVal    None
 * @Note      (MSB)0101_0101_1010_1010 ---> 0101_0101_1010_1010(LSB)
 ***************************************************************************************************/
unsigned short CRC16_IBM(unsigned char *puchMsg, unsigned int usDataLen)  
{  
    unsigned short wCRCin = 0x0000;  
    unsigned short wCPoly = 0x8005;  
    unsigned char wChar = 0;  

    while (usDataLen--)     
    {  
        wChar = *(puchMsg++);  
        InvertUint8(&wChar, &wChar);  
        wCRCin ^= (wChar << 8);  

        for(int i = 0; i < 8; i++)  
        {  
            if(wCRCin & 0x8000)  
            {
                wCRCin = (wCRCin << 1) ^ wCPoly; 
            }            
            else  
            {
                wCRCin = wCRCin << 1;  
            }
        }  
    }  
    InvertUint16(&wCRCin,&wCRCin);  
    return (wCRCin) ;  
}  


/****************************************************************************************************
 * @Brief    double byte data inversion        
 * @Param    
 *            @DesBuf: destination buffer
 *            @SrcBuf: source buffer
 * @RetVal    None
 * @Note      (MSB)0101_0101_1010_1010 ---> 0101_0101_1010_1010(LSB)
 ***************************************************************************************************/
unsigned short CRC16_MAXIM(unsigned char *puchMsg, unsigned int usDataLen)  
{  
    unsigned short wCRCin = 0x0000;  
    unsigned short wCPoly = 0x8005;  
    unsigned char wChar = 0;  

    while (usDataLen--)     
    {  
        wChar = *(puchMsg++);  
        InvertUint8(&wChar, &wChar);  
        wCRCin ^= (wChar << 8);  

        for(int i = 0; i < 8; i++)  
        {  
            if(wCRCin & 0x8000) 
            {              
                wCRCin = (wCRCin << 1) ^ wCPoly;
            }
            else 
            {              
                wCRCin = wCRCin << 1;  
            }
        }  
    }  
    InvertUint16(&wCRCin, &wCRCin);  
    return (wCRCin^0xFFFF) ;  
}  
 

/****************************************************************************************************
 * @Brief    double byte data inversion        
 * @Param    
 *            @DesBuf: destination buffer
 *            @SrcBuf: source buffer
 * @RetVal    None
 * @Note      (MSB)0101_0101_1010_1010 ---> 0101_0101_1010_1010(LSB)
 ***************************************************************************************************/
unsigned short CRC16_USB(unsigned char *puchMsg, unsigned int usDataLen)  
{  
    unsigned short wCRCin = 0xFFFF;  
    unsigned short wCPoly = 0x8005;  
    unsigned char wChar = 0;  

    while (usDataLen--)     
    {  
        wChar = *(puchMsg++);  
        InvertUint8(&wChar, &wChar);  
        wCRCin ^= (wChar << 8); 

        for(int i = 0; i < 8; i++)  
        {  
            if(wCRCin & 0x8000) 
            {              
                wCRCin = (wCRCin << 1) ^ wCPoly;
            }            
            else  
            {
                wCRCin = wCRCin << 1; 
            }            
        }  
    }  
    InvertUint16(&wCRCin, &wCRCin);  
    return (wCRCin^0xFFFF) ;  
} 


/****************************************************************************************************
 * @Brief    double byte data inversion        
 * @Param    
 *            @DesBuf: destination buffer
 *            @SrcBuf: source buffer
 * @RetVal    None
 * @Note      (MSB)0101_0101_1010_1010 ---> 0101_0101_1010_1010(LSB)
 ***************************************************************************************************/
void packageModbusData( unsigned char slaveAddress, unsigned char sommand, unsigned short dataAddress, unsigned short dataLength )  
{  
    unsigned char Buffer[UART4_TRANSMIT_BUFFER_SIZE]; 
    uint16_t check;
    
    Buffer[0] = slaveAddress;
    Buffer[1] = sommand;
    Buffer[2] = (dataAddress>>8) & 0xFF;
    Buffer[3] = dataAddress & 0xFF;
    Buffer[4] = (dataLength>>8) & 0xFF;
    Buffer[5] = dataLength & 0xFF;
    
    check = CRC16_MODBUS( Buffer, 6 );
    //check = crc16( Buffer, 6, 0x00 );
    
    Buffer[6] = check & 0xFF;
    Buffer[7] = (check>>8) & 0xFF;
    
    WriteDataToUSART3TrainsmitBuffer( Buffer, 8 );
    
} 


/****************************************************************************************************
 * @Brief    double byte data inversion        
 * @Param    
 *            @DesBuf: destination buffer
 *            @SrcBuf: source buffer
 * @RetVal    None
 * @Note      (MSB)0101_0101_1010_1010 ---> 0101_0101_1010_1010(LSB)
 ***************************************************************************************************/
void analysisModbusData( unsigned char buffer[], unsigned int length )  
{  
    unsigned char Buffer[USART3_RECEIVE_BUFFER_SIZE]; 
    uint16_t check;
    uint16_t position = 0;
    float angle = 0.0;
    
    if( (buffer[0] != 1) || (buffer[1] != 0x04) || (buffer[2] != 0x04) ) return;
    check = CRC16_MODBUS( Buffer, length );
//    if( ( (buffer[length-1]<<8) | buffer[length-2]) != check ) return 0.0;
    
    position = (buffer[3]<<8) | buffer[4];
    angle = 0.087890625*position;
    
    if( angle < 180.0 )
    {
        EncdoeAngle.centreAngle = -angle;
    }
    else
    {
        EncdoeAngle.centreAngle = 360.0-angle;
    }
    
    
//    motorSetFrontRightWheelSpeed( Mc6c.RightX/6 ); //��ת
//    vSetPidStruct( &frontRightWheelPid, 2.5, 0.01, 0.0001 );
//    return angle;
} 



