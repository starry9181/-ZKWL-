/**********************************************************************************
 * Filename   ��Tof05140.c
 * Author     : Liu Tusheng       
 * Version    : 1.0
 * Date       : 2017.12.28
 * Discription : Usart base driver API
**********************************************************************************/ 
#include "Tof05140.h"
//#include <stdio.h>


uint16_t DropDepth;


/*******************************************************************************
* Function Name  : ReadDropDepth
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
uint16_t ReadDropDepth( void )
{
#define USART_RECEIVE_BUFFER_SIZE 20
#define DROP_DEPTH     100    
	uint8_t ReceiveBuffer[USART_RECEIVE_BUFFER_SIZE], length ;
//	int buffer[4] = {0};
	
    if( GetUSART2ReceiveNumber(  ) )
	{
		length = ucReadBufferDataFromUSART2( ReceiveBuffer );
        AnalysisDropFallData( ReceiveBuffer, length, &DropDepth );
	}
    
}



/*******************************************************************************
* Function Name  : ReadDropDepth
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
bool ReadDropDepthUpAllow( void )
{
#define UP_ALLOW   650
    
    if( DropDepth>=UP_ALLOW ) return true;
    
    return false;
}


/*******************************************************************************
* Function Name  : ReadDropDepth
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
bool ReadDropDepthDownAllow( void )
{
#define DOWN_ALLOW  1050
    
    if( DropDepth<=DOWN_ALLOW ) return true;
    
    return false;
}


/*******************************************************************************
* Function Name  : ReadDropDepth
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void AnalysisDropFallData( uint8_t *pBuffer, uint8_t Length, uint16_t *pData )
{
    uint8_t i = 0;
    
    if( pBuffer[1] == 0x6d )
    {
        i=1;
    }
    else if( pBuffer[2] == 0x6d )
    {
        i=2;
    }
    else if( pBuffer[3] == 0x6d )
    {
        i=3;
    }
    else if( pBuffer[4] == 0x6d )
    {
        i=4;
    }
    switch( i )
    {
        case 0:
            *pData = 0;
            break;
        
        case 1:
            *pData = (pBuffer[0]-0x30);
            break;
        
        case 2:
            *pData = (pBuffer[0]-0x30)*10+(pBuffer[1]-0x30);
            break;
        
        case 3:
            *pData = (pBuffer[0]-0x30)*100+(pBuffer[1]-0x30)*10+(pBuffer[2]-0x30);
            break;
        
        case 4:
            *pData = (pBuffer[0]-0x30)*1000+(pBuffer[1]-0x30)*100+(pBuffer[2]-0x30)*10+(pBuffer[3]-0x30);
            break;
        
        default:
            break;
        
    }
}




