/**********************************************************************************
 * Filename   ��TestMainBoard.c
 * Author     : Liu Tusheng       
 * Version    : 1.0
 * Date       : 2016.11.14
 * Discription : 
 *                 ���԰�                                                   ����  
 *                                 
 *                 ���°���            ��������Դ��ѹ
 *
 *                                          ���͵�״̬����ָ�����
 *                 ����Դ��ADC�з��� >>------------------------------------->>
 *
 *                                 �Ͳ���ָ���ʾ׼���ò���
 *         ����ADC��ȡ������� <<-----------------------------------<<     ����ظ�
 *
 *                                 ���Ե�״̬��ɣ���״̬����ָ��
 *            �����߲���״̬ <<-------------------------------------<<     ���巢��
 *
 *                                   �ظ���״̬����ָ��
 *            �ظ��߲���״̬ >>------------------------------------->>     ���Ը�״̬   
 *
 *
**********************************************************************************/
#include "TestMainBoard.h"


MainBoardParameter MainTest;
MainBoardParameter * const pMainTest = &MainTest; //��¼�������״̬

MainBoardParameter ResultTest[16];
uint8_t Point = 0;
uint8_t MainBoardTestDoneFlag = 0;

uint8_t LedTestFlag = 0;





/*******************************************************************************
* Function Name  : AdcDataHandle
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void TestMainBoardTask( void *Parammenters )
{
      TickType_t TestLEDTime = 0; 
      uint8_t Count = 0;  
//    SetTestOutputHigh(  ); //�������������
    SetTestOutputLow(  );
    
    while( 1 )
    {                 
        CommunicationWithMainBoard(  );
        AllTestDone(  );
        if( LedTestFlag && MultipleTimeoutCheck( &TestLEDTime, 100 ) == TimeOut )
        {
            Count++;
            if( Count >= 20 )
            {
                Count = 0;
                LedTestFlag = 0;
            }
            outMainboardLedBlink(  );
        }
    }
    
}






/*******************************************************************************
* Function Name  : AllTestDone
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
__inline void AllTestDone( void )
{

    if( MainBoardTestDoneFlag ) //�������
    {
        MainBoardTestDoneFlag = 0;
        //pTestData->AllTestNumber++; //���԰�����
        pTestData->TestNumber++;
        if( Point ) //����������ʾ������
        {
            guiSetGuiNow( PageError );
            vTaskDelay( 100 );
            while(Point)
            {
               Point--;   
               SendErrorNumberToLCD( Point, (uint32_t)ResultTest[Point].TestNumber ); //��ʾ�������  
                     
            }
            
        }
        else //û�������
        {            
            pTestData->SeccessNumber++; 
            TestDoneDrawCirsLCD(  );
        }                       
        WriteTestDataToSTM32Flash( pTestData->TestDataFlash );

    }        
}





/*******************************************************************************
* Function Name  : GetTestState
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
__inline void GetTestState( void )
{
#define POWER_12V_VALUE       2000
#define POWER_5V_VALUE        2000    
#define POWER_3V3_VALUE       1500     
    
    if( HighStateValue[Power12VCheck] < POWER_12V_VALUE)
    {
        RecordTestFalseResult( NumberPower12V );
    }
    
    if( HighStateValue[Power5VCheck] < POWER_5V_VALUE)
    {
        RecordTestFalseResult( NumberPower5V );
    }
    
    if( HighStateValue[Power3V3Check] < POWER_3V3_VALUE)
    {
        RecordTestFalseResult( NumberPower3V3 );
    }
    
}





/*******************************************************************************
* Function Name  : CommunicationWithMainBoard
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
__inline void CommunicationWithMainBoard( void )
{
    uint8_t Command,Message[20],Length;
    MainBoardParameter Test;      //���Բ���
    
    
    if( GetUSART3ReceiveNumber(  ) )
    {
        Length = ucReadBufferDataFromUSART3( Message );
        Command = AnalysisMainBoardCommand( Message, &Test, Length );
        switch( Command )
        {
            case TestCommand:
                *pMainTest = Test;
                if( pMainTest->State == HighState )
                {
                    SetTestOutputHigh(  ); //�������������                        
                    SenCommandToMainBoard( TestCommand, 1, HighState );
                    SendProgressBarToLCD( 50 ); //������
                }
                else
                {
                    SendProgressBarToLCD( 25 ); //������
                }
               
                break;
            
            case TestResult:
                if( Test.State == LowState )
                {
                    RecordTestFalseResult( Test.TestNumber );
                }
                SendProgressBarToLCD( 75 ); //������
                break;
            
            case EnterTest:
                LedTestFlag = 1;
                SenCommandToMainBoard( EnterTest, 1, HighState );
            break;
            
            case TestDone :
                GetTestState(  );
                SendProgressBarToLCD( 100 ); //������
                MainBoardTestDoneFlag = 1;
                SetTestOutputLow(  );
                break;
            
            default : break;
            
        }
    } 
}







/*******************************************************************************
* Function Name  : SetTestMainboardRestart
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SetTestMainboardRestart( void )
{
    
    Point = 0;
    pMainTest->State = LowState;
    SetTestOutputLow(  );
    guiSetGuiNow( PageTest ); 
    //vTaskDelay(20);
    SenCommandToMainBoard( TestCommand, 1, LowState );
}


/*******************************************************************************
* Function Name  : SetTestOutputLow
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SetTestOutputLow( void )
{
    outDropClose(  );
    outInfraredClose(  );
    outTestMainboardGeneralLow(  );
    outMainBoardAnalogLow(  );
    outMainBoardAdcLow(  );
    pwm2Disable(  );
    outChargeContrlOFF(  );
}



/*******************************************************************************
* Function Name  : SetTestOutputHigh
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SetTestOutputHigh( void )
{
    outDropLaunch(  );
    outInfraredLaunch(  );
    outTestMainboardGeneralHigh(  );
    outMainBoardAnalogHigh(  );
    outMainBoardAdcHigh(  );
    pwm2Enable(  );
    outChargeContrlON(  );
}






/*******************************************************************************
* Function Name  : RecordTestFalseResult
* Description    : ��¼����ʧ�ܵı��
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void RecordTestFalseResult( uint8_t TestNumber )
{
    if( Point >= 16 ) return;
    
    ResultTest[Point++].TestNumber = TestNumber;
}




/*******************************************************************************
* Function Name  : CheckOut
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
uint16_t CheckOut( uint8_t Buffer[], uint8_t Length )
{
    uint16_t Check = 0x4149;
    uint8_t i;
    
    for( i=0;i<Length;i++ )
    {
        Check += Buffer[i];
    }
    
    return Check;    
}






/*******************************************************************************
* Function Name  : SenCommandToMainBoard
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SenCommandToMainBoard( uint8_t Command, uint8_t Number, TestState State )
{
    
    uint8_t Buffer[10];
    uint16_t Check;
    
    Buffer[0] = (MainDataHead>>8) & 0xFF;
    Buffer[1] = MainDataHead & 0xFF;
    Buffer[2] = Command;
    Buffer[3] = Number;
    Buffer[4] = (uint8_t)State;
    
    Check = CheckOut( Buffer, 5 );
    Buffer[5] = (Check>>8) & 0xFF;
    Buffer[6] = Check & 0xFF;
    
    WriteDataToUSART3TrainsmitBuffer( Buffer, 7 );
    
}





/*******************************************************************************
* Function Name  : AnalysisMainBoardCommand
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
uint8_t AnalysisMainBoardCommand( uint8_t Buffer[], MainBoardParameter *pTestMain, uint8_t Length )
{
    uint16_t DataHead,Check;
    uint8_t Command;
    
    DataHead = (Buffer[0]<<8) & 0xFFFF;
    DataHead |= Buffer[1];
    if( DataHead != MainDataHead )
    {
        return 0;
    }
    Check = (Buffer[Length-2]<<8) & 0xFFFF;
    Check |= Buffer[Length-1];
    
    if( CheckOut( Buffer, Length-2 ) != Check )
    {
        return 0;
    }
    Command = Buffer[2];
    pTestMain->TestNumber = Buffer[3];
    pTestMain->State = (TestState)Buffer[4];
    
    return Command;    
}





