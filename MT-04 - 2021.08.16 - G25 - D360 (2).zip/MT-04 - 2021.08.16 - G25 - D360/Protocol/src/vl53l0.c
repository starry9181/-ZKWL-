/**********************************************************************************
 * Filename   ��vl53l0.c
 * Author     : Liu Tusheng       
 * Version    : 1.0
 * Date       : 2018.7.13
 * Discription : 
**********************************************************************************/ 
#include "vl53l0.h"






static void AnalysisDropFallVl53l0Data( uint8_t *pBuffer, uint8_t Length, uint16_t *pData );




uint16_t Vl53l0Distance = 1000;
bool AllowUpDownFlag = false;


/*******************************************************************************
* Function Name  : ReadDropDepthVl53l0
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
bool ReadDropDepthVl53l0( void )
{
#define USART_RECEIVE_BUFFER_SIZE 20
    
#define HIGH_HEIGHT_LASER     600                  //�ڸߴ�����Ĳ�࣬500mm 
#define LOW_HEIGHT_LASER     1100                  //�ڸߴ�����Ĳ�࣬1500mm    
	uint8_t ReceiveBuffer[USART_RECEIVE_BUFFER_SIZE], length ;
//    uint16_t Vl53l0Distance = 0;
//	int buffer[4] = {0};
	if( GetUSART2ReceiveNumber(  ) )
	{
		length = ucReadBufferDataFromUSART2( ReceiveBuffer );
        AnalysisDropFallVl53l0Data( ReceiveBuffer, length, &Vl53l0Distance );
        if( (Vl53l0Distance > HIGH_HEIGHT_LASER) && (Vl53l0Distance < LOW_HEIGHT_LASER) )
        {
            AllowUpDownFlag = true;
        }
        else
        {
            AllowUpDownFlag = false;
        }
	}
    
//    if( GetUSART3ReceiveNumber(  ) )
//	{
//		length = ucReadBufferDataFromUSART3( ReceiveBuffer );
//        AnalysisDropFallVl53l0Data( ReceiveBuffer, length, &Vl53l0Distance );
//        
//        if( Vl53l0Distance < DROP_DEPTH )
//        {
//            AllSensor.FrontModule.RightFrontFall = BitSet;
//        }
//        else
//        {
//            AllSensor.FrontModule.RightFrontFall = BitReset;
//        }
//	}
    return AllowUpDownFlag;
}

/*******************************************************************************
* Function Name  : CheckOut
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
static uint8_t CheckOut( uint8_t *pBuffer, uint8_t Length )
{
    uint8_t check = 0,i;
    
    for( i=0;i<(Length-1); i++ )
    {
        check += pBuffer[i];
    }
    
    return check;
}



/*******************************************************************************
* Function Name  : AnalysisDropFallVl53l0Data
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
static void AnalysisDropFallVl53l0Data( uint8_t *pBuffer, uint8_t Length, uint16_t *pData )
{
    uint8_t i = 0;
    
    if( (pBuffer[0] != 0x5A) || (pBuffer[1] != 0x5A) || (CheckOut( pBuffer, Length ) != pBuffer[7]) ) return;
    
    *pData = (pBuffer[4] << 8) | pBuffer[5];
}