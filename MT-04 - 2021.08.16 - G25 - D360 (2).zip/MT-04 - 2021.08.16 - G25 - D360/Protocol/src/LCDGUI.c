/**********************************************************************************
 * Filename   ��LCDGUI.c
 * Author     : Liu Tusheng       
 * Version    : 1.0
 * Date       : 2016.11.1
 * Discription : LCG GUI API
**********************************************************************************/
#include "LCDGUI.h"


volatile TestStuct TestData = {100,100}; //��¼������Ϣ
volatile TestStuct * const pTestData = &TestData;
volatile GUI GuiNow = PageMain;              //��¼LCD��ǰUI    
volatile GUI SetGuiNow = PageMain;           //����LCD��ǰUI
uint8_t SetGuiFlag = 0;

//uint8_t CirsRED[ ] = {"cirs 400,200,100,RED"};
uint8_t CirsGreen[ ] = {"cirs 400,160,80,GREEN"};
uint8_t SetPageMain[ ] = {"page main"};
uint8_t SetPageSet[ ] = {"page set"};
uint8_t SetPageTest[ ] = {"page test"};
uint8_t SetPageError[ ] = {"page error"};

uint8_t SetTestJ0Value[20] = {"j0.val="};        //������
uint8_t SetTestT0Value[20] = {"t0.txt=\"10%\""}; //���Ȱٷֱ� 
uint8_t SetTestN0Value[15] = {"n0.val="};        //�Ѿ�����������
uint8_t SetTestN1Value[15] = {"n1.val="};        //�ɹ�������
uint8_t SetTestN2Value[15] = {"n2.val="};        //��Ʒ�ʣ��룩
uint8_t SetTestN3Value[15] = {"n3.val="};        //ϵͳ���гɹ����԰�����

uint8_t SetErrorN0Value[15] = {"n0.val="};
uint8_t SetErrorN1Value[15] = {"n1.val="};
uint8_t SetErrorN2Value[15] = {"n2.val="};
uint8_t SetErrorN3Value[15] = {"n3.val="};
uint8_t SetErrorN4Value[15] = {"n4.val="};
uint8_t SetErrorN5Value[15] = {"n5.val="};
uint8_t SetErrorN6Value[15] = {"n6.val="};
uint8_t SetErrorN7Value[15] = {"n7.val="};
uint8_t SetErrorN8Value[15] = {"n8.val="};
uint8_t SetErrorN9Value[15] = {"n9.val="};
uint8_t SetErrorN10Value[15] = {"n10.val="};
uint8_t SetErrorN11Value[15] = {"n11.val="};
uint8_t SetErrorN12Value[15] = {"n12.val="};
uint8_t SetErrorN13Value[15] = {"n13.val="};
uint8_t SetErrorN14Value[15] = {"n14.val="};
uint8_t SetErrorN15Value[15] = {"n15.val="};




/*******************************************************************************
* Function Name  : VLCD_GUI_Task
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void VLCD_GUI_Task( void *Parammenters )
{

    uint8_t ReceiveLCDMessage[30],Length;
    
    guiSetGuiNow( PageMain );    
  
    while( 1 )
    {
        if( GetUSART2ReceiveNumber(  ) )
        {
            Length = ucReadBufferDataFromUSART2( ReceiveLCDMessage );
            HandleLCDCommand( ReceiveLCDMessage, Length );
        }
        if( guiReadSetGuiFlag(  ) )
        {
            guiClearGuiFlag(  );
            
            switch( SetGuiNow )
            {
                case PageMain:
                    SendSringsCommandToLCD( SetPageMain, strlen((const char*)SetPageMain) );
                    break;
                
                case PageSet:
                    SendSringsCommandToLCD( SetPageSet, strlen((const char*)SetPageSet) );
                    break;
                
                case PageTest:
                    SendSringsCommandToLCD( SetPageTest, strlen((const char*)SetPageTest) );
                    break;
                
                case PageError:
                    SendSringsCommandToLCD( SetPageError, strlen((const char*)SetPageError) );
                    break;
                                               
                default: break;
            }
            
        }
    }        
    
}




/*********************************MCU���͵�LCD**********************************************/



/*******************************************************************************
* Function Name  : NumberToStrings
* Description    : ����תACSII��
* Input          : Number������
* Output         : *pStrings��ACSII��ŵ�ַ����λ����ʮ��ǧλ����ǰ
* Return         : StringLength��ACSII����
*******************************************************************************/
uint8_t NumberToStrings( uint8_t *pStrings, uint32_t Number )
{
    uint8_t StringLength = 0;
    
    if( Number == 0 )
    {
        pStrings[StringLength++] = '0';
    }
    while( Number )
    {
        pStrings[StringLength++] = Number % 10 + 0x30;
        Number /= 10;
    }    
    return StringLength;
}



/*******************************************************************************
* Function Name  : SendNumberCommandToLCD
* Description    : ����תACSII��
* Input          : Number������
* Output         : *pStrings��Ҫ���͵����Number��Ҫ��ʾ������
* Return         : None
*******************************************************************************/
void SendNumberCommandToLCD( uint8_t *pStrings, uint32_t Number )
{
    uint16_t length = 0, i = 0;
    uint8_t target[20],TarLength;
    
    
    while( pStrings[length++] != '=' );  //�ҵ�'='�ַ�
    
    TarLength = NumberToStrings( target, Number );
    
    for( i=1; i<=TarLength; i++ )      //��source�ַ�������λ�ò����ַ���target
    {
        pStrings[length++] = target[TarLength-i];
    }
    
    for(i=0;i<3;i++)                 //д�����������
    {
        pStrings[length++] = 0xFF;
    }
    
    WriteDataToUSART2TrainsmitBuffer( pStrings, length );
}






/*******************************************************************************
* Function Name  : SendErrorNumberToLCD
* Description    : ����תACSII��
* Input          : Number������
* Output         : Location��Ҫ��ʾ��λ�ã�Number��Ҫ��ʾ������
* Return         : None
*******************************************************************************/
void SendErrorNumberToLCD( uint8_t Location, uint32_t Number )
{
    switch( Location )
    {
        case 0:
            SendNumberCommandToLCD( SetErrorN0Value, Number );
            break;
        
        case 1:
            SendNumberCommandToLCD( SetErrorN1Value, Number );
            break;
        
        case 2:
            SendNumberCommandToLCD( SetErrorN2Value, Number );
            break;
        
        case 3:
            SendNumberCommandToLCD( SetErrorN3Value, Number );
            break;
        
        case 4:
            SendNumberCommandToLCD( SetErrorN4Value, Number );
            break;
        
        case 5:
            SendNumberCommandToLCD( SetErrorN5Value, Number );
            break;
        
        case 6:
            SendNumberCommandToLCD( SetErrorN6Value, Number );
            break;
        
        case 7:
            SendNumberCommandToLCD( SetErrorN7Value, Number );
            break;
        
        case 8:
            SendNumberCommandToLCD( SetErrorN8Value, Number );
            break;
        
        case 9:
            SendNumberCommandToLCD( SetErrorN9Value, Number );
            break;
        
        case 10:
            SendNumberCommandToLCD( SetErrorN10Value, Number );
            break;
        
        case 11:
            SendNumberCommandToLCD( SetErrorN11Value, Number );
            break;
        
        case 12:
            SendNumberCommandToLCD( SetErrorN12Value, Number );
            break;
        
        case 13:
            SendNumberCommandToLCD( SetErrorN13Value, Number );
            break;
        
        case 14:
            SendNumberCommandToLCD( SetErrorN14Value, Number );
            break;
        
        case 15:
            SendNumberCommandToLCD( SetErrorN15Value, Number );
            break;
        
        default:     break;
    }
    
}






/*******************************************************************************
* Function Name  : TestDoneDrawCirsLCD
* Description    : ��Բ
* Input          : 
* Output         : 
* Return         : None
*******************************************************************************/
void TestDoneDrawCirsLCD( void )
{
    SendSringsCommandToLCD( SetPageTest, strlen((const char*)SetPageTest) );
    vTaskDelay(10);
    SendSringsCommandToLCD( CirsGreen, strlen((const char*)CirsGreen) );
}


/*******************************************************************************
* Function Name  : SendpercentageCommandToLCD
* Description    : ���Ͱٷֱ���ʾ
* Input          : Number������
* Output         : *pStrings��Ҫ���͵����Number��Ҫ��ʾ�İٷֱ�
* Return         : 
*******************************************************************************/
void SendpercentageCommandToLCD( uint8_t *pStrings, uint8_t Number )
{
    uint8_t i,length=0,NumSize=0;
    uint8_t NumStr[3];
    
    if( Number == 0 )
    {
        pStrings[NumSize++] = '0';
    }
    while( Number )
    {
        NumStr[NumSize++] = Number % 10 + 0x30;
        Number /= 10;
    }
    
    while( pStrings[length++] != '"' );             //�ҵ���һ��'"'

    for( i=1;i<=NumSize;i++ )                       //���������ַ���
    {
        pStrings[length++] = NumStr[NumSize-i];
    }    
    pStrings[length++] = '%';
    pStrings[length++] = '"';
    for( i=0;i<3;i++ )                              //������
    {
        pStrings[length++] = 0xFF;
    }  
    WriteDataToUSART2TrainsmitBuffer( &pStrings[0], length );
    
}





/*******************************************************************************
* Function Name  : SendProgressBarToLCD
* Description    : ���ͽ������ٷֱ���ʾ
* Input          : Number��Ҫ��ʾ�İٷֱ�
* Output         : 
* Return         : 
*******************************************************************************/
void SendProgressBarToLCD( uint8_t Number )
{
    SendNumberCommandToLCD( SetTestJ0Value, Number );  
    SendpercentageCommandToLCD( SetTestT0Value, Number ); 
}






/*******************************************************************************
* Function Name  : SendTestDataToLCD
* Description    : ���Ͳ�������
* Input          : 
* Output         : 
* Return         : 
*******************************************************************************/
void SendTestDataToLCD( void )
{
    
    SendNumberCommandToLCD( SetTestN0Value, TestData.TestNumber );
    SendNumberCommandToLCD( SetTestN1Value, TestData.SeccessNumber );
    SendNumberCommandToLCD( SetTestN3Value, (TestData.SeccessNumber+TestData.AllTestNumber) );
    if( TestData.TestNumber == 0 )
    {
        TestData.DefectivePercentage = 0;
    }
    else
    {
        TestData.DefectivePercentage =  ( (TestData.TestNumber-TestData.SeccessNumber)/(float)TestData.TestNumber )*1000;   
    }
    SendNumberCommandToLCD( SetTestN2Value, TestData.DefectivePercentage );
}


/*******************************************************************************
* Function Name  : SendSringsCommandToLCD
* Description    : �����ַ������LCD
* Input          : pStrings���ַ�������,length: �ַ�������
* Output         : None
* Return         : None
*******************************************************************************/
void SendSringsCommandToLCD( uint8_t *pStrings, uint8_t length )
{
    uint8_t srings[50],i;
    
    FreeRTOS_MemoryCopy( srings, pStrings, length );
    
    for(i=0;i<3;i++)                 //д�����������
    {
        srings[length++] = 0xFF;
    }
    
    WriteDataToUSART2TrainsmitBuffer( srings, length );
    
}



/*********************************MCU���յ�LCD����**********************************************/



/*******************************************************************************
* Function Name  : AnalysisLCDCommand
* Description    : ����LCD����
* Input          : *pData�����ڽ��յ�����,length: ����
* Output         : None
* Return         : ����
*******************************************************************************/
uint8_t AnalysisLCDCommand( uint8_t *pData, uint8_t length )
{
    uint8_t i,check = 0;
    
    if( (pData[0] != ((LCD_DADA_HEAD>>8)&0xFF)) || (pData[1] != (LCD_DADA_HEAD&0xFF)) )
    {
        return 0;        
    }
    for( i=0;i<length-1;i++ )
    {
        check += pData[i];
    }
    if( check != pData[length-1] )
    {
        return 0;
    }
    
    return pData[2];
}





/*******************************************************************************
* Function Name  : HandleLCDCommand
* Description    : ����LCD����
* Input          : *pData�����ڽ��յ�����,length: ����
* Output         : None
* Return         : 
*******************************************************************************/
void HandleLCDCommand( uint8_t *pData, uint8_t length )
{
    uint8_t command;
    
    command = AnalysisLCDCommand( pData, length );
    
    switch( command )
    {
        case SelectMainBoard:
            break;
        
        case SelectLoamCakeBoard:
            break;
        
        case SelectInfraredBoard:
            break;

        case ClearTestData:
            pTestData->AllTestNumber += pTestData->SeccessNumber;
            WriteProgramWordDataToSTM32Flash( ALL_TEST_BOARD_NUMBER, pTestData->AllTestNumber );
            pTestData->TestNumber = 0;
            pTestData->SeccessNumber = 0;
            pTestData->DefectivePercentage = 0;   
            WriteTestDataToSTM32Flash( pTestData->TestDataFlash );
            break;
        
        case SendTestData:
            SendTestDataToLCD(  );
            break;
        
        case LcdGuiNow:
            switch( pData[3] )
            {
                case PageMain :
                    GuiNow = PageMain;
                    break;
                
                case PageSet :
                    GuiNow = PageSet;
                    break;
                
                case PageTest :
                    GuiNow = PageTest;
                    break;
                
                case PageError :
                    GuiNow = PageError;
                    break;
                
                case PageBox :
                    GuiNow = PageBox;
                    break;
                
                default : break;
            }
            break;
        
        
        default : break;
    }
    
}



