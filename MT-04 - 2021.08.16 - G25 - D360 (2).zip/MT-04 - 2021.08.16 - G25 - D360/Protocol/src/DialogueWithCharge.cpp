/******************************************************************************
* �ļ���  ��DialogueWithCar.c
* �ļ�������
* ������  ��Liu Tusheng
* ��    �գ�2016��2��29��
* 
* Ӳ�����ӣ�
*
******************************************************************************/
#include "DialogueWithCharge.h"










/********************************************************************************************
*������  ��SystemDialogueWithChargeTask
*������������ʼ��
*��    ������
*����ֵ  ����
********************************************************************************************/
void SystemDialogueWithChargeTask( void *Parammenters )
{
    uint8_t Usart2ReceiveBuffer[USART2_RECEIVE_BUFFER_SIZE],Usart2Length;    
    uint8_t Usart3ReceiveBuffer[USART3_RECEIVE_BUFFER_SIZE],Usart3Length;  
    uint16_t CommandData;
    
    while( 1 )
    {
        if( GetUSART2ReceiveNumber(  ) )
        {
            Usart2Length = ucReadBufferDataFromUSART2( Usart2ReceiveBuffer );
            if(  AnalysisCarMesssage( Usart2ReceiveBuffer, Usart2Length, &CommandData ) != FALSE )
            {
                AnalysisCarMesssageOperation( CommandData );
            }
            WriteDataToUSART3TrainsmitBuffer( Usart2ReceiveBuffer, Usart2Length );
        }
        
        if( GetUSART3ReceiveNumber(  ) )
        {
                        
            Usart3Length = ucReadBufferDataFromUSART3( Usart3ReceiveBuffer );
            if(  AnalysisCarMesssage( Usart3ReceiveBuffer, Usart3Length, &CommandData ) != FALSE )
            {
                AnalysisCarMesssageOperation( CommandData );
            }
            WriteDataToUSART2TrainsmitBuffer( Usart3ReceiveBuffer, Usart3Length );
        }
        
    }
    
}



/*******************************************************************************
* Function Name  : 
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
RetrunState CarSendCommandToChargeStation( uint8_t command, uint8_t *pdata, uint8_t datalength )
{
    uint8_t buffer[20];
    uint16_t check;
    
    buffer[0] = (HEAD_PACK>>8) & 0xFF;
    buffer[1] = HEAD_PACK & 0xFF;
    buffer[2] = command;
    buffer[3] = datalength;
    buffer[6] = *pdata;
      
    check = CheckOut( buffer, 7 );    
    buffer[4] = (check>>8) & 0xFF;
    buffer[5] = check & 0xFF;
    
    
    
    WriteDataToUSART3TrainsmitBuffer( buffer, 7 );    
    
    return TRUE;
    
}



