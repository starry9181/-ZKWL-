/**********************************************************************************
 * Filename   ��tm1812.c
 * Author     : Liu Tusheng       
 * Version    : 1.0
 * Date       : 2016.09.20
 * Discription : 
 *                         
**********************************************************************************/ 
#include "tm1812.h"


uint8_t ucTm1812PWMValue[12];   //����LED �Ҷȵȼ�





/*******************************************************************************
* Function Name  : vTM1812Init
* Description    : ��ʼ��ϵͳ����LED�Ҷ�
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void vTM1812Init( void )
{
    uint8_t i;
    
    for( i=0;i<12;i++ )
    {

        vSetLEDGrayscaleGrade( (LEDNumber)i, i );
           
    }
    
        
}



/*******************************************************************************
* Function Name  : vSetLEDGrayscaleGrade
* Description    : ����LED�ƻҶȵȼ�
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void vSetLEDGrayscaleGrade( LEDNumber LED, uint8_t ucGrade )
{
    uint8_t i;
//    DMA_Cmd( DMA1_Stream1, DISABLE );     
    for( i=0; i<8; i++ )
    {
        
        if( ucGrade & 0x80 )
        {
            ucTM1812EncodeBuffer[LED*8+i] = T1H_IN_850ns;
        }
        else
        {
            ucTM1812EncodeBuffer[LED*8+i] = T0H_IN_400ns;
        }
        ucGrade <<= 1;
        
    }
//    DMA_Cmd( DMA1_Stream1, ENABLE );     
}








