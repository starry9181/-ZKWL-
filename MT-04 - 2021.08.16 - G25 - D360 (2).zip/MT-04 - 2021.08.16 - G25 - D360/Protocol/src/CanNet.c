/**********************************************************************************
 * Filename   ��CanNet.c
 * Author     : Liu Tusheng       
 * Version    : 1.0
 * Date       : 2017.12.28
 * Discription : can networking
 * hardware connect:
**********************************************************************************/ 
#include "CanNet.h"



void PackageCanBackageSendToNode( uint32_t OwnID, uint32_t TargetID, uint16_t Command, void *pData, uint8_t length );
static uint8_t CopyCanBackageReceiveFromNode( uint8_t buffer[ ], void *pCanBack );
static uint16_t ExtractDataFromCanMessage( void * pModuleData, void *pCanBack, uint8_t length );
static void CollectSensorModuleParameter( void *pCanBack );

static void canMessageReply( void *pCanBack );

AngleQuantization canAngle[37] = {
    1, -33.25, -107.76,
    2, -31.5, -103.29,
    3, -29.75, -97.95,
    4, -28.00, -92.55,
    5, -26.25, -87.09,
    6, -24.50, -81.56,
    7, -22.75, -75.96,
    8, -21.00, -70.30,
    9, -19.25, -64.57,
    10, -17.50, -58.82,
    11, -15.75, -53.00,
    12, -14.00, -47.14,
    13, -12.25, -41.27,
    14, -10.50, -35.37,
    15, -8.75, -29.44,
    16, -7.00, -23.51,
    17, -5.25, -17.61,
    18, -3.50, -11.70,
    19, 0.00, 0.00,
    20, 3.50, 11.24,
    21, 5.25, 16.53,
    22, 7.00, 21.62,
    23, 8.75, 26.51,
    24, 10.50, 31.18,
    25, 12.25, 35.63,
    26, 14.00, 39.89,
    27, 15.75, 43.92,
    28, 17.50, 47.75,
    29, 19.25, 51.37,
    30, 21.00, 54.76,
    31, 22.75, 57.98,
    32, 24.50, 60.95,
    33, 26.25, 63.75,
    34, 28.00, 66.35,
    35, 29.75, 68.75,
    36, 31.50, 70.98,
    37, 33.25, 73.01  
};

#if 1

/*******************************************************************************
* Function Name  : canMessageContrlCanModule
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void canMessageContrlCanModule( void )
{
    static TickType_t CanTime = 0;
    static CanID ID_PC = BroadcastID;
    //CanData Data;
    uint8_t  CanData = 20;
    

        
}



/*******************************************************************************
* Function Name  : canMessageDataCollect
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
uint8_t  speed_mode = 0x00;
uint16_t  speed_limit = 2260;

extern uint32_t can_overtime;

void canMessageDataCollect( void *data )
{
    robotMotionPostrue *pRobotMotion = (robotMotionPostrue *) data;
    uint8_t CanMessage[8],i;
    CanData Data;
    float enc_temp , angle_temp;
    int16_t speed_temp;
    
    if( ReadCanMessageNumber(  ) )
    {
        ReadCanPackageMessage( CanMessage );
        switch( CopyCanBackageReceiveFromNode( CanMessage, &Data ) )
        {
            case BroadcastID:            //�㲥ID
                
                break;
            
            case AckermanContrlPCID:        //���ػ�ID
            {
                CollectSensorModuleParameter( &Data );
                
                if( Mc6c.LeftKey == 1 || Mc6c.DisconFlag == 1)
                {
                    if(CanMessage[1] == 0x01)
                    {
                        can_overtime = 0;
                       
                        angle_temp = (int16_t)((Data.Data[3]<<8)|Data.Data[2])/100.0;
                        if(angle_temp > 35) angle_temp = 35;
                        else if(angle_temp < -35) angle_temp = -35;
											
                        pRobotMotion->robotAckermanAngle = Angle_Change_Enc(angle_temp);
                        
                        speed_temp = ((Data.Data[1]<<8)|Data.Data[0]);
                        if(speed_temp >= speed_limit)
                        {
                            speed_temp = speed_limit;
                        }
                        else if(speed_temp <= -speed_limit)
                        {
                            speed_temp = -speed_limit;
                        }
                        pRobotMotion->robotVelocity = speed_temp;
                    }
                }
                if(CanMessage[1] == 0x20)
                {
                    if(CanMessage[2] == 0x01)
                    {
                        Clear_Crash_Flag();
                    }
                }
                break;
            }
            case AckermanChassisID:        //���̰�ID
                
                break;
            
            default:
                break;
        }
    }
}






/*******************************************************************************
* Function Name  : CollectSensorModuleParameter
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
static void CollectSensorModuleParameter( void *pCanBack )
{
	CanData *pData = ( CanData* )pCanBack;
  Sensor  GetCanSensor;
    float data;

	switch( pData->Command )
	{
        case SET_SPEED_ANGLE :
            
            memcpy( (char*)&data, &pData->Data, sizeof(float)  );
            EncdoeAngle.leftAngle = data;
            break;
		default:
			break;	
	}
}
/*******************************************************************************
* Function Name  : PackageCanBackageSendToNode
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void PackageCanBackageSendToNode( uint32_t OwnID, uint32_t TargetID, uint16_t Command, void *pData, uint8_t length )
{
	uint8_t buffer[8] = {0};
	   
	buffer[0] = OwnID & 0xFF;
	buffer[1] = Command & 0xFF;
    
    memcpy( &buffer[2], pData, length  );
	CanSendDataPackage( TargetID, buffer );
	
}



/*******************************************************************************
* Function Name  : CopyCanBackageReceiveFromNode
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
static uint8_t CopyCanBackageReceiveFromNode( uint8_t buffer[ ], void *pCanBack )
{
	CanData *pData = ( CanData* )pCanBack;
	
	pData->TransmitID = buffer[0];
	pData->Command = buffer[1];
    memcpy( pData->Data, &buffer[2], 6 );
	return pData->TransmitID;
}



/*******************************************************************************
* Function Name  : ExtractDataFromCanMessage
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
static uint16_t ExtractDataFromCanMessage( void * pModuleData, void *pCanBack, uint8_t length )
{
    CanData *pData = ( CanData* )pCanBack;
    
    memcpy( pModuleData, pData->Data, length );
    
    return pData->Command;
}


#endif


uint8_t Can_Send_Data(uint16_t canid , const uint8_t * data , uint8_t num)
{
    CanTxMsg TxMessage;
    uint8_t cnt;
    if(canid > 0x800 || num>8) return 0;

    TxMessage.StdId=canid;
    TxMessage.IDE=CAN_ID_STD;
    TxMessage.RTR=CAN_RTR_DATA;
    TxMessage.DLC=8;
    for(cnt = 0; cnt < num ; cnt++)
    {
        TxMessage.Data[cnt] = data[cnt];
    }
    for( ; cnt < 8 ; cnt++)
    {
        TxMessage.Data[cnt] = 0;
    }
    
    
    CAN_Transmit(CAN1, &TxMessage);

    return cnt;
}





