/**********************************************************************************
 * Filename   ��ps2COntrl.c
 * Author     : Liu Tusheng       
 * Version    : 1.0
 * Date       : 2019.5.21
 * Discription : 
 * Hardware Connet:
**********************************************************************************/ 
#include "ps2COntrl.h"



static bool MessageAnalysisData( void *buffer, void *Package );


ps2Package ps2Handle;

/*******************************************************************************
* Function Name  : CheckOut
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
static uint16_t CheckOut( uint8_t *pBuffer, uint8_t length )
{
	uint16_t Check = 0, i;
	
	for( i=0; i<length; i++ )
	{
		Check += pBuffer[i];
	}
	
	return Check;
}




/*******************************************************************************
* Function Name  : ps2MessageAnalysisAndExtractMessageData
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
bool ps2MessageAnalysisAndExtractMessageData( void *pData, uint8_t *pMessage, uint8_t MesLen )
{
	uint16_t Check;
	uint8_t i;
    
    ps2Package *pPackgeData = (ps2Package *)pData;
    
	pPackgeData->head = (pMessage[1]<<8) | pMessage[0];
	pPackgeData->packageLength = pMessage[2];
    pPackgeData->command = (pMessage[4]<<8) | pMessage[3];
    pPackgeData->messageReturnFlag = pMessage[5];
    pPackgeData->dataCount = pMessage[6];
    
	Check = (pMessage[MesLen-1]<<8) | pMessage[MesLen-2];
	if( (pPackgeData->head != PS2_PACK_HEAD) || ( pPackgeData->packageLength != MesLen ) || ( Check != CheckOut( pMessage, MesLen-2 ) ) )
	{
        if( pPackgeData->head  != PS2_PACK_HEAD )
        {
            ps2ProtocolDebug( "PACK_HEAD error\r\n" );
        }
        if( pPackgeData->packageLength != MesLen )
        {
            ps2ProtocolDebug( "Message length error\r\n" );
        }
        if( Check != CheckOut( pMessage, MesLen-2 ) )
        {
            ps2ProtocolDebug( "Message checkout error\r\n" );
        }
//        if( pPackgeData->command != PS2_COMMAND )
//        {
//            ps2ProtocolDebug( "command error\r\n" );
//        }
        for( i=0;i<MesLen;i++ )
        {
            printf("%x ", pMessage[i] );
            
        }
        printf("\r\n");
		return false;
	}
	memcpy( &pPackgeData->data, &pMessage[7], pPackgeData->packageLength-9 );
	pPackgeData->data.dataUpdateFlag = BitSet;
    
    
    return true;
}




/*******************************************************************************
* Function Name  : ps2HandleContrl
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void ps2HandleContrl( void )
{
    uint8_t Buffer[UART4_RECEIVE_BUFFER_SIZE], length;
    
    if( GetUART4ReceiveNumber(  ) )
    {
        length = ucReadBufferDataFromUART4( Buffer );
        if( ps2MessageAnalysisAndExtractMessageData( &ps2Handle, Buffer, length ) != false )
        {
            
        }
    }

}




