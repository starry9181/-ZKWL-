/**********************************************************************************
 * Filename   ��singleEncode.c
 * Author     : Liu Tusheng       
 * Version    : 1.0
 * Date       : 2019.7.2
 * Discription : 
 * Hardware Connet:
**********************************************************************************/ 
#include "singleEncode.h"

#include <math.h>


float singleAngle = 0.0;




/*******************************************************************************
* Function Name  : singleCheckOut
* Description    : У������㺯��
* Input          : pBuffer: ��Ҫ�����У�����ݻ���
                   length����Ҫ�����У�����ݳ���
* Output         : None
* Return         : Check:У����
*******************************************************************************/
static uint16_t singleCheckOut( uint8_t *pBuffer, uint8_t length )
{
	uint16_t Check = 0, i;
	uint8_t CheckHigh = 0, CheckLow = 0;
    
	for( i=2; i<length-3; i++ )
	{
		CheckHigh += pBuffer[i];
        CheckLow ^= pBuffer[i];
	}
	
    Check = (CheckHigh<<8) | CheckLow;
    
	return Check;
}




/*******************************************************************************
* Function Name  : analysisSingleEncodeAngle
* Description    : �����������ǶȺ���
* Input          : pBuffer: ��Ҫ�����У�����ݻ���
                   length����Ҫ�����У�����ݳ���
* Output         : None
* Return         : Check:У����
*******************************************************************************/
bool analysisSingleEncodeAngle( uint8_t *pBuffer, uint8_t length )
{
	uint16_t Check = 0, i;
	uint16_t Angle; //Angle���ֵ16384
    if( (((pBuffer[0]<<8)|(pBuffer[1])) != SINGLE_ENCODE_HEAD) || (pBuffer[2] != (length-5)) ) return false;
    
    Check = singleCheckOut( pBuffer, length );
    if( Check != ((pBuffer[length-3]<<8)|(pBuffer[length-2])) ) return false;
    
    Angle = (pBuffer[3]<<8)| pBuffer[4];
    
    singleAngle = Angle*0.02197265625;
    
    //if( ((pBuffer[0]<<8)|(pBuffer[1])) != SINGLE_ENCODE_HEAD ) return false;
    
    return true;
}



float Enc_Change_Angle(float enc)
{
    float angle;
    angle = enc * (0.0004144f * fabs(enc) + 0.2315f);

    return angle;
}


float Angle_Change_Enc(float angle)
{
    float enc;
    enc = angle * (-0.0197436f * fabs(angle) + 4.24f);

    return enc;
}



