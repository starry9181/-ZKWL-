/******************************************************************************
* �ļ���  ��RedEncode.c
* �ļ�������
* ������  ��Liu Tusheng
* ��    �գ�2016��2��29��
* 
* Ӳ�����ӣ�
*
******************************************************************************/
#include "RedDecode.h"


__IO DecodeStruct LeftSensorDecode = {0};                  //�����ͷ
__IO DecodeStruct LeftCentreSensorDecode = {0};            //���н���ͷ
__IO DecodeStruct RightCentreSensorDecode = {0};           //���н���ͷ
__IO DecodeStruct RightSensorDecode = {0};                 //�ҽ���ͷ



QueueHandle_t xQueueInfraredDecoding = NULL;





//__inline RetrunState SetCarWalkDirection( void );
void RedCodeSensorNumber( DecodeSensor Sensor, uint16_t *pBuffer, uint8_t length );
/********************************************************************************************
*������  ��SystemInfraredDecodingTask
*������������ʼ��
*��    ������
*����ֵ  ����
********************************************************************************************/
void SystemInfraredDecodingTask( void *Parammenters )
{  
    uint8_t ucQueueMsgValue;

    
    if( (xQueueInfraredDecoding = xQueueCreate( 20, sizeof(uint8_t) ) ) == NULL )
    {
        
    }

    while( 1 )
    {
        
        if( xQueueReceive(xQueueInfraredDecoding, (void *)&ucQueueMsgValue, 50 ) == pdPASS )
        {
            switch( ucQueueMsgValue )
            {
                case LeftSensor:
                    
                    break;
                
                case LeftCentreSensor:
                    RedCodeSensorNumber( LeftCentreSensor, LeftCentreDecode.Buffer[LeftCentreDecode.ReadGrooveIndex], CAPTURE_BUFFER_SIZE );
                    capLeftCentreDecodeReadBufferDone(  );
                    break;
                
                case RightCentreSensor: 
                    RedCodeSensorNumber( RightCentreSensor, RightCentreDecode.Buffer[RightCentreDecode.ReadGrooveIndex], CAPTURE_BUFFER_SIZE );
                    capRightCentreDecodeReadBufferDone(  );
                    break;
                
                case RightSensor: 
                    RedCodeSensorNumber( RightSensor, RightDecode.Buffer[RightDecode.ReadGrooveIndex], CAPTURE_BUFFER_SIZE );
                    capRightDecodeReadBufferDone(  );
                    break;
                
                default : break;
            }
   
        }        
        
        DecodeTimeOutHandle(  );  
  

    }
    
    
}

  


/********************************************************************************************
*������  ��DecodeTimeOutHandle
*������������ʱ����������֮ǰ������������
*��    ����
*����ֵ  ����
********************************************************************************************/
void DecodeTimeOutHandle( void )
{
#define DECODE_TIME_OUT  100
    uint8_t i;
    
    /***************************************�󴫸���*****************************************************/
    for( i=0;i<4;i++ )
    {
        if( SingleTimeoutCheck( LeftSensorDecode.DecodeTimeOut[i], DECODE_TIME_OUT ) == TimeOut )
        {
            LeftSensorDecode.DecodeChar[i] = 0;
        }
    }
    
    /***************************************���д�����*****************************************************/
    for( i=0;i<4;i++ )
    {
        if( SingleTimeoutCheck( LeftCentreSensorDecode.DecodeTimeOut[i], DECODE_TIME_OUT ) == TimeOut )
        {
            LeftCentreSensorDecode.DecodeChar[i] = 0;
        }
    }
    
    
    /***************************************���д�����*****************************************************/
    for( i=0;i<4;i++ )
    {
        if( SingleTimeoutCheck( RightCentreSensorDecode.DecodeTimeOut[i], DECODE_TIME_OUT ) == TimeOut )
        {
            RightCentreSensorDecode.DecodeChar[i] = 0;
        }
    }
    
    
    /***************************************�Ҵ�����*****************************************************/
    for( i=0;i<4;i++ )
    {
        if( SingleTimeoutCheck( RightSensorDecode.DecodeTimeOut[i], DECODE_TIME_OUT ) == TimeOut )
        {
            RightSensorDecode.DecodeChar[i] = 0;
        }
    }
    
}











/********************************************************************************************
*������  ��RedCodeSensorNumber
*������������ʼ��IO��
*��    ������
*����ֵ  ����
********************************************************************************************/
void RedCodeSensorNumber( DecodeSensor Sensor, uint16_t *pBuffer, uint8_t length )
{
    uint8_t data = 0, i;

   
    
    /*************************************�жϵڰ��ֽ��Ƿ�Ϊ����δ***********************************************/
//    if( ( pBuffer[8]>END_BIT_TIME_UPPER_LIMIT ) || ( pBuffer[8]<END_BIT_TIME_UPPER_LIMIT ) ) 
//    {              
//        return DecodeNumberNone;
//    }    

    /*********************************************��������********************************************/
    for( i=0;i<8;i++ )
    {
        data<<=1;  
        if( (pBuffer[i]> LOGIC_1_TIME_LOWER_LIMIT) && (pBuffer[i]< LOGIC_1_TIME_UPPER_LIMIT) )
        {
            data |= 0x01;
        }
        else if( (pBuffer[i]> LOGIC_0_TIME_LOWER_LIMIT) && (pBuffer[i]< LOGIC_0_TIME_UPPER_LIMIT) )
        {
            data &= ~0x01;
        }
        else
        {
        
        }
              
    }
    /*********************************************����ƥ��********************************************/
    switch( Sensor )
    {
        case LeftSensor:
            switch( data )
            {
                case 'I':                      
                    LeftSensorDecode.DecodeChar[DecodeNumber1-1] = 'I';                    //�����õ����ַ�                    
                    LeftSensorDecode.DecodeTimeOut[DecodeNumber1-1] = GetOSRunTimeNow(  ); //��ȡϵͳʱ�䣬�����ʱ�������������
                    break;
                
                case 'C':
                    LeftSensorDecode.DecodeChar[DecodeNumber2-1] = 'C'; 
                    LeftSensorDecode.DecodeTimeOut[DecodeNumber2-1] = GetOSRunTimeNow(  ); //��ȡϵͳʱ��
                    break;
                
                case 'L':
                    LeftSensorDecode.DecodeChar[DecodeNumber3-1] = 'L';              
                    LeftSensorDecode.DecodeTimeOut[DecodeNumber3-1] = GetOSRunTimeNow(  ); //��ȡϵͳʱ��
                    break;
                
                case 'E':
                    LeftSensorDecode.DecodeChar[DecodeNumber4-1] = 'E'; 
                    LeftSensorDecode.DecodeTimeOut[DecodeNumber4-1] = GetOSRunTimeNow(  ); //��ȡϵͳʱ��
                    break;
                
                default:break;
            }
            break;
        
        case LeftCentreSensor:
            switch( data )
            {
                 case 'I':  
                    LeftCentreSensorDecode.DecodeChar[DecodeNumber1-1] = 'I'; 
                    LeftCentreSensorDecode.DecodeTimeOut[DecodeNumber1-1] = GetOSRunTimeNow(  ); //��ȡϵͳʱ��
                    break;
                
                case 'C':
                    LeftCentreSensorDecode.DecodeChar[DecodeNumber2-1] = 'C';  
                    LeftCentreSensorDecode.DecodeTimeOut[DecodeNumber2-1] = GetOSRunTimeNow(  ); //��ȡϵͳʱ��
                    break;
                
                case 'L':
                    LeftCentreSensorDecode.DecodeChar[DecodeNumber3-1] = 'L'; 
                    LeftCentreSensorDecode.DecodeTimeOut[DecodeNumber3-1] = GetOSRunTimeNow(  ); //��ȡϵͳʱ��
                    break;
                
                case 'E':
                    LeftCentreSensorDecode.DecodeChar[DecodeNumber4-1] = 'E'; 
                    LeftCentreSensorDecode.DecodeTimeOut[DecodeNumber4-1] = GetOSRunTimeNow(  ); //��ȡϵͳʱ��
                    break;
                
                default:break;
            }
            break;
        
        case RightCentreSensor:
            switch( data )
            {
                case 'I':  
                    RightCentreSensorDecode.DecodeChar[DecodeNumber1-1] = 'I'; 
                    RightCentreSensorDecode.DecodeTimeOut[DecodeNumber1-1] = GetOSRunTimeNow(  ); //��ȡϵͳʱ��
                    break;
                
                case 'C':
                    RightCentreSensorDecode.DecodeChar[DecodeNumber2-1] = 'C';  
                    RightCentreSensorDecode.DecodeTimeOut[DecodeNumber2-1] = GetOSRunTimeNow(  ); //��ȡϵͳʱ��
                    break;
                
                case 'L':
                    RightCentreSensorDecode.DecodeChar[DecodeNumber3-1] = 'L'; 
                    RightCentreSensorDecode.DecodeTimeOut[DecodeNumber3-1] = GetOSRunTimeNow(  ); //��ȡϵͳʱ��
                    break;
                
                case 'E':
                    RightCentreSensorDecode.DecodeChar[DecodeNumber4-1] = 'E'; 
                    RightCentreSensorDecode.DecodeTimeOut[DecodeNumber4-1] = GetOSRunTimeNow(  ); //��ȡϵͳʱ��
                    break;
                
                default:break;
            }
            break;
        
        case RightSensor:
            switch( data )
            {
                case 'I':  
                    RightSensorDecode.DecodeChar[DecodeNumber1-1] = 'I'; 
                    RightSensorDecode.DecodeTimeOut[DecodeNumber1-1] = GetOSRunTimeNow(  ); //��ȡϵͳʱ��
                    break;
                
                case 'C':
                    RightSensorDecode.DecodeChar[DecodeNumber2-1] = 'C'; 
                    RightSensorDecode.DecodeTimeOut[DecodeNumber2-1] = GetOSRunTimeNow(  ); //��ȡϵͳʱ��
                    break;
                
                case 'L':
                    RightSensorDecode.DecodeChar[DecodeNumber3-1] = 'L';  
                    RightSensorDecode.DecodeTimeOut[DecodeNumber3-1] = GetOSRunTimeNow(  ); //��ȡϵͳʱ��
                    break;
                
                case 'E':
                    RightSensorDecode.DecodeChar[DecodeNumber4-1] = 'E'; 
                    RightSensorDecode.DecodeTimeOut[DecodeNumber4-1] = GetOSRunTimeNow(  ); //��ȡϵͳʱ��
                    break;
                
                default:break;
            }
            break;
        
        default: break;
    }
                             
    
}





