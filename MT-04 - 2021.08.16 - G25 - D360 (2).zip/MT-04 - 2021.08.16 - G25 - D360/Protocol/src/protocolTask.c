/**********************************************************************************
 * Filename   ��protocolTask.c
 * Author     : Liu Tusheng       
 * Version    : 1.0
 * Date       : 2017.9.8
 * Discription : 
 * Hardware Connet:
**********************************************************************************/ 
#include "protocolTask.h"

extern bool protocolMessageAnalysisAndExtractMessageData( void *pData, uint8_t *pMessage, uint8_t MesLen );

canContrl SendData;

/*******************************************************************************
* Function Name  : SystemProtocolTask
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void SystemProtocolTask( void *Parammenters )
{
    uint8_t Buffer[UART4_RECEIVE_BUFFER_SIZE], length;
    TickType_t canTime = 0;
    uint8_t can_data[8];
    
    protocolPackageFront PackgeData;
//    packageModbusData( 0x01, 0x04, 0x0400, 0x0002 );
    
    while( 1 )
    {
//        ps2HandleContrl(  );
//        robotProtocolContrl (   );
     if( ReadCanMessageNumber(  ) )
		{
			canMessageDataCollect( &robotMotion );
		}
#if 1        
        if( GetUSART2ReceiveNumber(  ) )
        {
            length = ucReadBufferDataFromUSART2( Buffer );
            protocolMessageAnalysisAndExtractMessageData( &robotMotion, Buffer, length );
        }
        
        if( GetUSART3ReceiveNumber(  ) )
        {
            length = ucReadBufferDataFromUSART3( Buffer );
//            analysisSingleEncodeAngle( Buffer, length );
            analysisModbusData( Buffer, length );
            
        }
      
        if( MultipleTimeoutCheck( &canTime, 20 ) == TimeOut )
        {
            packageModbusData( 0x01, 0x04, 0x0400, 0x0002 );
            
            SendData.robotVelocity = (MecanumChassisReal.behindLeftWheelSpeed+MecanumChassisReal.behindRightWheelSpeed)/2; //��������ٶȷ�������
            
            SendData.robotAckermanAngle = Enc_Change_Angle(EncdoeAngle.centreAngle)*100;
            SendData.battery = robotMotion.battery;
            SendData.turnToWheelError = robotMotion.frontRightWheelError;
            SendData.behindLeftWheelError = robotMotion.behindLeftWheelError;
            SendData.behindRightWheelError = robotMotion.behindRightWheelError;
            SendData.scram = robotMotion.scram;
            SendData.frontCrash = robotMotion.frontCrash;
            SendData.behindCrash = robotMotion.behindCrash;
            
            PackageCanBackageSendToNode( AckermanChassisID, 0x10 , REPORT_SPEED_ANGLE, &SendData, sizeof(canContrl) );
            PackageCommandMessageToUSART( REPORT_ROBOT_STATE, &SendData, sizeof(canContrl) );

            can_data[0] = 0x02;
            can_data[1] = 0x02;
            can_data[2] = (uint8_t)(MecanumChassisReal.behindLeftWheelSpeed);
            can_data[3] = (uint8_t)((MecanumChassisReal.behindLeftWheelSpeed) >> 8);
            can_data[4] = (uint8_t)(MecanumChassisReal.behindRightWheelSpeed);
            can_data[5] = (uint8_t)((MecanumChassisReal.behindRightWheelSpeed) >> 8);
            can_data[6] = 0;
            can_data[7] = 0;
            Can_Send_Data(0x11 , can_data , 8);
            
        }
        
#endif        
        vTaskDelay(1);
    }

}



