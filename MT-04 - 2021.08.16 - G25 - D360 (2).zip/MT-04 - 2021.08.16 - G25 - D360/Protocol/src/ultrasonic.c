/**********************************************************************************
 * Filename   ��SensorMix.c
 * Author     : Liu Tusheng       
 * Version    : 1.0
 * Date       : 2017.9.8
 * Discription : 
 * Hardware Connet:
**********************************************************************************/ 
#include "ultrasonic.h"






/*******************************************************************************
* Function Name  : UltrasonicTring
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void UltrasonicTring( void )
{
    static TickType_t UltrasonicTime = 0;
    
    if( (outReadTring1State(  ) == BitSet) && (MultipleTimeoutCheck( &UltrasonicTime, 5 ) == TimeOut) )
    {
        outUltasonicTring1Low(  );
        outUltasonicTring2Low(  );
        outUltasonicTring3Low(  );
        outUltasonicTring4Low(  );
    }
    else if( (outReadTring1State(  ) == BitReset) && (MultipleTimeoutCheck( &UltrasonicTime, 200 ) == TimeOut) )
    {
        outUltasonicTring1Higt(  );
        outUltasonicTring2Higt(  );
        outUltasonicTring3Higt(  );
        outUltasonicTring4Higt(  );
    }
    
}




/*******************************************************************************
* Function Name  : UltrasonicCheacUpDwonAllow
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
bool UltrasonicCheacUpAllow( void )
{
#define HIGH_HEIGHT     600                  //�ڸߴ��������Ĳ�࣬500mm
    
//    if( Ultrasonic1.Distance > HIGH_HEIGHT )    
//    {
//        return true;
//    }
//    
//    return false;
    return true;
}



/*******************************************************************************
* Function Name  : UltrasonicCheacUpDwonAllow
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
bool UltrasonicCheacDownAllow( void )
{
#define LOW_HEIGHT     1100                  //�ڸߴ��������Ĳ�࣬1500mm
//    if(  Ultrasonic1.Distance < LOW_HEIGHT )    
//    {
//        return true;
//    }
    
//    return false;
    return true;
}
