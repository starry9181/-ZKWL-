/**
  ******************************************************************************
  * @file    mc6c.c
  * @author  zxp
  * @version V1.0.0
  * @date    2019-10-10
  * @brief   MC6Cң�����ݵĽ���
  ******************************************************************************
  * @attention 
  * 
  ******************************************************************************
  */
#include "mc6c.h"
#include "stm32f10x_dma.h"
#include <math.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>
#include <stdio.h>




MC6C Mc6c;

#if MCUSARTPORT == 3
//-----------------------------���� 3--------------------------------------------------------
static uint8_t USART3_Rx_Buff[100];
static uint8_t USART3_Tx_Buff[100];

//����2DMA���� DMA1 ͨ��7
uint8_t MCUSART3_DMA_TX(const uint8_t *TxBuff , uint8_t Byte_Cnt)
{ 
	DMA_Cmd(DMA1_Channel2, DISABLE);
	if(Byte_Cnt>(sizeof(USART3_Tx_Buff)/sizeof(*USART3_Tx_Buff))){return 0;}
	memcpy(USART3_Tx_Buff,TxBuff,Byte_Cnt);
	DMA_SetCurrDataCounter(DMA1_Channel2,Byte_Cnt);
	DMA_Cmd(DMA1_Channel2, ENABLE);
	return 1;
}


static void USART3_DMA_Config(void)
{
	DMA_InitTypeDef dma_init;

	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);

	DMA_DeInit(DMA1_Channel2);
	DMA_DeInit(DMA1_Channel3);

	dma_init.DMA_PeripheralBaseAddr = (uint32_t)&(USART3->DR);
	dma_init.DMA_MemoryBaseAddr = (uint32_t)USART3_Rx_Buff;
	dma_init.DMA_DIR = DMA_DIR_PeripheralSRC ;	
	dma_init.DMA_BufferSize = 100;
	dma_init.DMA_PeripheralInc = DMA_PeripheralInc_Disable; 
	dma_init.DMA_MemoryInc = DMA_MemoryInc_Enable;	
	dma_init.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
	dma_init.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;	 
	dma_init.DMA_Mode = DMA_Mode_Normal ;
	dma_init.DMA_Priority = DMA_Priority_VeryHigh;
	dma_init.DMA_M2M = DMA_M2M_Disable;
	DMA_Init(DMA1_Channel3, &dma_init); 	   
	DMA_Cmd (DMA1_Channel3,ENABLE);

	dma_init.DMA_PeripheralBaseAddr = (uint32_t)&(USART3->DR);
	dma_init.DMA_MemoryBaseAddr = (uint32_t)USART3_Tx_Buff;
	dma_init.DMA_DIR = DMA_DIR_PeripheralDST ;	
	dma_init.DMA_BufferSize = 8;
	dma_init.DMA_PeripheralInc = DMA_PeripheralInc_Disable; 
	dma_init.DMA_MemoryInc = DMA_MemoryInc_Enable;	
	dma_init.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
	dma_init.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;	 
	dma_init.DMA_Mode = DMA_Mode_Normal ;
	dma_init.DMA_Priority = DMA_Priority_Medium;
	dma_init.DMA_M2M = DMA_M2M_Disable;
	DMA_Init(DMA1_Channel2, &dma_init); 	   
	//  DMA_Cmd (DMA1_Channel7,ENABLE);//�����ʱ���ٿ���

	USART_DMACmd(USART3, USART_DMAReq_Rx, ENABLE);
	USART_DMACmd(USART3, USART_DMAReq_Tx, ENABLE);
}



static void USART3_NVIC_Config(void)
{
	NVIC_InitTypeDef  usart_nvic_init; 
  
	usart_nvic_init.NVIC_IRQChannel = DMA1_Channel3_IRQn ;	
	usart_nvic_init.NVIC_IRQChannelPreemptionPriority = 0;
	usart_nvic_init.NVIC_IRQChannelSubPriority = 1;
	usart_nvic_init.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&usart_nvic_init);
	
	usart_nvic_init.NVIC_IRQChannel = USART3_IRQn;	
	usart_nvic_init.NVIC_IRQChannelPreemptionPriority = 0;
	usart_nvic_init.NVIC_IRQChannelSubPriority = 2;
	usart_nvic_init.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&usart_nvic_init);
}


void MCUSART3_Config(uint32_t BaudRate)
{
	GPIO_InitTypeDef  gpio_init;
	USART_InitTypeDef usart_init;

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOB| RCC_APB2Periph_AFIO, ENABLE);

	gpio_init.GPIO_Pin = GPIO_Pin_10;
	gpio_init.GPIO_Mode = GPIO_Mode_AF_PP;
	gpio_init.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &gpio_init);
		
	gpio_init.GPIO_Pin = GPIO_Pin_11;
	gpio_init.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOB, &gpio_init);

	usart_init.USART_BaudRate = BaudRate;
	usart_init.USART_WordLength = USART_WordLength_9b;
	usart_init.USART_StopBits = USART_StopBits_2;
	usart_init.USART_Parity = USART_Parity_Even ;
	usart_init.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	usart_init.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(USART3, &usart_init); 

	USART3_NVIC_Config();
	USART3_DMA_Config();

	USART_ITConfig(USART3, USART_IT_IDLE, ENABLE);
	USART_Cmd(USART3, ENABLE);
	USART_ClearFlag(USART3, USART_FLAG_TC);


}

/********����3�����жϺ���*******/	
void USART3_IRQHandler(void)
{
	if(USART_GetITStatus(USART3, USART_IT_IDLE) != RESET)
	{
		unsigned char temp;
		temp = USART3->SR;
		temp = USART3->DR;
		//ȥ����
		temp=temp;

		DMA_Cmd (DMA1_Channel3,DISABLE);
		//���ң������
		Sbus_Data_Count(USART3_Rx_Buff);
        
        memset(USART3_Rx_Buff , 0 , sizeof(USART3_Rx_Buff));
		
		DMA_SetCurrDataCounter(DMA1_Channel3,100);
		DMA_Cmd (DMA1_Channel3,ENABLE);
		
	}
}

/**********DMA1ͨ��6�����ж�****/
void DMA1_Channel3_IRQHandler(void)
{
	if(DMA_GetFlagStatus(DMA1_FLAG_TC3)!=RESET) 
	{
		DMA_ClearITPendingBit(DMA1_IT_TC3);
	}
}

/*
 *******************************************************************************
 *		DMA	printf
 *******************************************************************************
 */

void MCu3_printf(const char *format,...)
{
	uint32_t length;
    char _dbg_TXBuff[100]={0};
	va_list args;
	va_start(args, format);
	length = vsnprintf((char*)_dbg_TXBuff, sizeof(_dbg_TXBuff), (char*)format, args);
	va_end(args);
	MCUSART3_DMA_TX((const unsigned char*)_dbg_TXBuff,length);
	
}

#elif MCUSARTPORT == 4
//-----------------------------���� 4--------------------------------------------------------

static uint8_t UART4_Rx_Buff[100];
static uint8_t UART4_Tx_Buff[100];

//����4DMA���� DMA2 ͨ��5
uint8_t MCUART4_DMA_TX(const uint8_t *TxBuff , uint8_t Byte_Cnt)
{ 
	DMA_Cmd(DMA2_Channel5, DISABLE);
	if(Byte_Cnt>(sizeof(UART4_Tx_Buff)/sizeof(*UART4_Tx_Buff))){return 0;}
	memcpy(UART4_Tx_Buff,TxBuff,Byte_Cnt);
	DMA_SetCurrDataCounter(DMA2_Channel5,Byte_Cnt);
	DMA_Cmd(DMA2_Channel5, ENABLE);
	return 1;
}


static void UART4_DMA_Config(void)
{
	DMA_InitTypeDef dma_init;

	RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA2, ENABLE);

	DMA_DeInit(DMA2_Channel5);
	DMA_DeInit(DMA2_Channel3);

	dma_init.DMA_PeripheralBaseAddr = (uint32_t)&(UART4->DR);
	dma_init.DMA_MemoryBaseAddr = (uint32_t)UART4_Rx_Buff;
	dma_init.DMA_DIR = DMA_DIR_PeripheralSRC ;	
	dma_init.DMA_BufferSize = 100;
	dma_init.DMA_PeripheralInc = DMA_PeripheralInc_Disable; 
	dma_init.DMA_MemoryInc = DMA_MemoryInc_Enable;	
	dma_init.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
	dma_init.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;	 
	dma_init.DMA_Mode = DMA_Mode_Normal ;
	dma_init.DMA_Priority = DMA_Priority_VeryHigh;
	dma_init.DMA_M2M = DMA_M2M_Disable;
	DMA_Init(DMA2_Channel3, &dma_init); 	   
	DMA_Cmd (DMA2_Channel3,ENABLE);

	dma_init.DMA_PeripheralBaseAddr = (uint32_t)&(UART4->DR);
	dma_init.DMA_MemoryBaseAddr = (uint32_t)UART4_Tx_Buff;
	dma_init.DMA_DIR = DMA_DIR_PeripheralDST ;	
	dma_init.DMA_BufferSize = 8;
	dma_init.DMA_PeripheralInc = DMA_PeripheralInc_Disable; 
	dma_init.DMA_MemoryInc = DMA_MemoryInc_Enable;	
	dma_init.DMA_PeripheralDataSize = DMA_PeripheralDataSize_Byte;
	dma_init.DMA_MemoryDataSize = DMA_MemoryDataSize_Byte;	 
	dma_init.DMA_Mode = DMA_Mode_Normal ;
	dma_init.DMA_Priority = DMA_Priority_Medium;
	dma_init.DMA_M2M = DMA_M2M_Disable;
	DMA_Init(DMA2_Channel5, &dma_init); 	   
	//  DMA_Cmd (DMA1_Channel7,ENABLE);//�����ʱ���ٿ���

	USART_DMACmd(UART4, USART_DMAReq_Rx, ENABLE);
	USART_DMACmd(UART4, USART_DMAReq_Tx, ENABLE);
}



static void UART4_NVIC_Config(void)
{
	NVIC_InitTypeDef  usart_nvic_init; 
  
	usart_nvic_init.NVIC_IRQChannel = DMA2_Channel3_IRQn ;	
	usart_nvic_init.NVIC_IRQChannelPreemptionPriority = 0;
	usart_nvic_init.NVIC_IRQChannelSubPriority = 1;
	usart_nvic_init.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&usart_nvic_init);
	
	usart_nvic_init.NVIC_IRQChannel = UART4_IRQn;	
	usart_nvic_init.NVIC_IRQChannelPreemptionPriority = 0;
	usart_nvic_init.NVIC_IRQChannelSubPriority = 2;
	usart_nvic_init.NVIC_IRQChannelCmd = ENABLE;
	NVIC_Init(&usart_nvic_init);
}


void MCUART4_Config(uint32_t BaudRate)
{
	GPIO_InitTypeDef  gpio_init;
	USART_InitTypeDef usart_init;

	RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4, ENABLE);
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC| RCC_APB2Periph_AFIO, ENABLE);

	gpio_init.GPIO_Pin = GPIO_Pin_10;
	gpio_init.GPIO_Mode = GPIO_Mode_AF_PP;
	gpio_init.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &gpio_init);
		
	gpio_init.GPIO_Pin = GPIO_Pin_11;
	gpio_init.GPIO_Mode = GPIO_Mode_IN_FLOATING;
	GPIO_Init(GPIOC, &gpio_init);

	usart_init.USART_BaudRate = BaudRate;
	usart_init.USART_WordLength = USART_WordLength_9b;
	usart_init.USART_StopBits = USART_StopBits_2;
	usart_init.USART_Parity = USART_Parity_Even ;
	usart_init.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
	usart_init.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
	USART_Init(UART4, &usart_init); 

	UART4_NVIC_Config();
	UART4_DMA_Config();

	USART_ITConfig(UART4, USART_IT_IDLE, ENABLE);
	USART_Cmd(UART4, ENABLE);
	USART_ClearFlag(UART4, USART_FLAG_TC);

}

/********����4�����жϺ���*******/	

void UART4_IRQHandler(void)
{
	if(USART_GetITStatus(UART4, USART_IT_IDLE) != RESET)
	{
		uint8_t temp;
		temp = UART4->SR;
		temp = UART4->DR;
		//ȥ����
		temp=temp;
		DMA_Cmd (DMA2_Channel3,DISABLE);
		
		//���ң������
		Sbus_Data_Count(UART4_Rx_Buff);
		
        memset(UART4_Rx_Buff , 0 , sizeof(UART4_Rx_Buff));
        
		DMA_SetCurrDataCounter(DMA2_Channel3,100);
		DMA_Cmd (DMA2_Channel3,ENABLE);
	}
}

/**********DMA2ͨ��3�����ж�****/
void DMA2_Channel3_IRQHandler(void)
{
	if(DMA_GetFlagStatus(DMA2_FLAG_TC3)!=RESET) 
	{
		DMA_ClearITPendingBit(DMA1_IT_TC3);
	}
}


/*
 *******************************************************************************
 *		DMA	printf
 *******************************************************************************
 */

void MCu4_printf(const char *format,...)
{
	uint32_t length;
    char _dbg_TXBuff[100]={0};
	va_list args;
	va_start(args, format);
	length = vsnprintf((char*)_dbg_TXBuff, sizeof(_dbg_TXBuff), (char*)format, args);
	va_end(args);
	MCUART4_DMA_TX((const unsigned char*)_dbg_TXBuff,length);
	
}
#endif


/*******************************************************************************
* Function Name  : MC6CInit  
* Description    : MC6C��ʼ��
* Input          : None
* Output         : None
* Return         : None 
****************************************************************************** */
static uint16_t _channels[16];
void MC6CInit(void)
{
	#if   MCUSARTPORT == 3
	MCUSART3_Config(100000);
	#elif MCUSARTPORT == 4
	MCUART4_Config(100000);
	#endif
    Mc6c.DisconFlag = 1;
	memset(Mc6c.DeCH,0,sizeof(Mc6c.DeCH));
	memset(Mc6c.NoCH,0,sizeof(Mc6c.NoCH));
	memset(_channels,0,sizeof(_channels));
}

/*******************************************************************************
* Function Name  : Deal_SbusData  
* Description    : ����ң��������
* Input          : None
* Output         : None
* Return         : None 
****************************************************************************** */
void Deal_SbusData(void)
{
	Mc6c.LeftX  = Mc6c.NoCH[3];
	Mc6c.LeftY  = Mc6c.NoCH[1];
	Mc6c.RightX = Mc6c.NoCH[0];
	Mc6c.RightY = _channels[2];
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
			ң�������ݴ������������ÿ������ȷһ�����ݽ�һ��
++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
	
	
	
/*++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/	
}

/*******************************************************************************
* Function Name  : Sbus_Data_Count  
* Description    : ���ң��������
* Input          : ң������
* Output         : None
* Return         : None 
****************************************************************************** */
void Sbus_Data_Count(uint8_t *buffer)
{
	
	static uint8_t i=0;
    static uint8_t range_error = 0;
	
	if(buffer[0] == 0x0F && buffer[21] == 0xEA && buffer[22] == 0x53)
	{
		_channels[0]  = ((buffer[1]>>0 |buffer[2]<<8)     			  & 0x07FF);
		_channels[1]  = ((buffer[2]>>3 |buffer[3]<<5)                 & 0x07FF);
		_channels[2]  = ((buffer[3]>>6 |buffer[4]<<2 |buffer[5]<<10)  & 0x07FF);
		_channels[3]  = ((buffer[5]>>1 |buffer[6]<<7)                 & 0x07FF);
		_channels[4]  = ((buffer[6]>>4 |buffer[7]<<4)                 & 0x07FF);
		_channels[5]  = ((buffer[7]>>7 |buffer[8]<<1 |buffer[9]<<9)   & 0x07FF);
		_channels[6]  = ((buffer[9]>>2 |buffer[10]<<6)                & 0x07FF);
		_channels[7]  = ((buffer[10]>>5|buffer[11]<<3)                & 0x07FF);
		_channels[8]  = ((buffer[12]   |buffer[13]<<8)                & 0x07FF);
		_channels[9]  = ((buffer[13]>>3|buffer[14]<<5)                & 0x07FF);
		_channels[10] = ((buffer[14]>>6|buffer[15]<<2|buffer[16]<<10) & 0x07FF);
		_channels[11] = ((buffer[16]>>1|buffer[17]<<7)                & 0x07FF);
		_channels[12] = ((buffer[17]>>4|buffer[18]<<4)                & 0x07FF);
		_channels[13] = ((buffer[18]>>7|buffer[19]<<1|buffer[20]<<9)  & 0x07FF);
		_channels[14] = ((buffer[20]>>2|buffer[21]<<6)                & 0x07FF);
		_channels[15] = ((buffer[21]>>5|buffer[22]<<3)                & 0x07FF);
	}
	else
	{
		return;
	}
	
	//�����ж�
	if((_channels[0] == 1001 && _channels[1] == 1001 && _channels[2] == 41 && _channels[3] == 1001) || 
        (_channels[0] == 1000 && _channels[1] == 1000 && _channels[2] == 40 && _channels[3] == 1000))
	{
		memset(Mc6c.DeCH,0,sizeof(Mc6c.DeCH));
		memset(Mc6c.NoCH,0,sizeof(Mc6c.NoCH));
		memset(_channels,0,sizeof(_channels));
        Mc6c.LeftKey = Mc6c.RightKey = 0;
		Mc6c.DisconFlag = 1;
		Mc6c.LockFlag = 0;
		i = 0;
        range_error = 0;
		Deal_SbusData();//�������һ�Σ���ȷ���ٶ�����
		return;
	}
	else
	{
		Mc6c.DisconFlag = 0;
	}
	
	//ȡĬ��ֵ
	if(i < 10)
	{
        if(abs(_channels[0] - 1000) > 300 || abs(_channels[1] - 1000) > 300 || abs(_channels[3] - 1000) > 300 || range_error == 1)
        {
            range_error = 1;
            i = 0;
            return;
        }
        else
        {
            Mc6c.DeCH[0] += (float)(_channels[0]/10.0);
            Mc6c.DeCH[1] += (float)(_channels[1]/10.0);
            Mc6c.DeCH[2] += (float)(_channels[2]/10.0);
            Mc6c.DeCH[3] += (float)(_channels[3]/10.0);
            i++;
        }

		return;
	}
	
	//�����ж�
	if(Mc6c.LockFlag == 0 || Mc6c.LockFlag == 1)
	{
		if(_channels[2] > 1500)
		{
			Mc6c.LockFlag = 1;
		}
		else if(_channels[2] < 500 && Mc6c.LockFlag == 1)
		{
			Mc6c.LockFlag =2;
		}
	}
	
	//��������������
	if(Mc6c.LockFlag == 2 && Mc6c.DisconFlag == 0)
	{
		if	   (_channels[0] > Mc6c.DeCH[0] + ERRORVAUE) {Mc6c.NoCH[0] = _channels[0] - Mc6c.DeCH[0]-ERRORVAUE;}
		else if(_channels[0] < Mc6c.DeCH[0] - ERRORVAUE) {Mc6c.NoCH[0] = _channels[0] - Mc6c.DeCH[0]+ERRORVAUE;}
		else
		{
			Mc6c.NoCH[0] = 0;
		}
		
		if	   (_channels[1] > Mc6c.DeCH[1] + ERRORVAUE) {Mc6c.NoCH[1] = _channels[1] - Mc6c.DeCH[1]-ERRORVAUE;}
		else if(_channels[1] < Mc6c.DeCH[1] - ERRORVAUE) {Mc6c.NoCH[1] = _channels[1] - Mc6c.DeCH[1]+ERRORVAUE;}
		else
		{
			Mc6c.NoCH[1] = 0;
		}
			
		if	   (_channels[2] > Mc6c.DeCH[2] + ERRORVAUE) {Mc6c.NoCH[2] = _channels[2] - Mc6c.DeCH[2]-ERRORVAUE;}
		else if(_channels[2] < Mc6c.DeCH[2] - ERRORVAUE) {Mc6c.NoCH[2] = _channels[2] - Mc6c.DeCH[2]+ERRORVAUE;}
		else
		{
			Mc6c.NoCH[2] = 0;
		}
			
		if	   (_channels[3] > Mc6c.DeCH[3] + ERRORVAUE) {Mc6c.NoCH[3] = _channels[3] - Mc6c.DeCH[3]-ERRORVAUE;}
		else if(_channels[3] < Mc6c.DeCH[3] - ERRORVAUE) {Mc6c.NoCH[3] = _channels[3] - Mc6c.DeCH[3]+ERRORVAUE;}
		else
		{
			Mc6c.NoCH[3] = 0;
		}
		
		if(_channels[4] < 300)
		{
			Mc6c.LeftKey = 0;
		}
		else if(_channels[4] < 1100)
		{
			Mc6c.LeftKey = 1;
		}
		else if(_channels[4] > 1700)
		{
			Mc6c.LeftKey = 2;
		}
		
		if(_channels[5] < 300)
		{
			Mc6c.RightKey = 0;
		}
		else if(_channels[5] > 1700)
		{
			Mc6c.RightKey = 1;
		}
	}
	else
	{
		return;
	}
	
	Deal_SbusData();
	
}

