/******************************************************************************
* �ļ���  ��DialogueWithCar.c
* �ļ�������
* ������  ��Liu Tusheng
* ��    �գ�2016��2��29��
* 
* Ӳ�����ӣ�
*
******************************************************************************/
#include "DialogueWithCar.h"


TickType_t ButtJointTime = 0;

/*******************************************�Խ�״̬********���״̬*************��ˮ״̬*********��ˮ״̬ *********/
CommunicationWithCar CommunicatWitchCar = { ButtJointClose, BatteryChargeClose, AddWaterClose, DrainWaterClose };




/*******************************************************************************
* Function Name  : 
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
uint16_t CheckOut( uint8_t buffer[], uint8_t length )
{
    uint16_t check = 0x4943;
    uint8_t i=0;
    
    for( i=0;i<length;i++ )
    {
        if( (i==4) || (i==5) )
        {
            
        }
        else
        {
            check += buffer[i];
        }
        
    }
    
    return check;
}





/*******************************************************************************
* Function Name  : 
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
RetrunState ChargeStationSendCommandToCar( uint8_t command, uint8_t *pdata, uint8_t datalength )
{
    uint8_t buffer[30];
    uint16_t check;
    
    buffer[0] = (HEAD_PACK>>8) & 0xFF;
    buffer[1] = HEAD_PACK & 0xFF;
    buffer[2] = command;
    buffer[3] = datalength;
    buffer[6] = *pdata;
      
    check = CheckOut( buffer, 7 );    
    buffer[4] = (check>>8) & 0xFF;
    buffer[5] = check & 0xFF;
    
    
    
    WriteDataToUSART3TrainsmitBuffer( buffer, 7 );    
    
    return TRUE;
    
}








/*******************************************************************************
* Function Name  : 
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
RetrunState AnalysisCarMesssage( uint8_t *pBuffer, uint8_t length, uint16_t *pCommandData )
{
    
    if( ((pBuffer[0]<<8)|pBuffer[1]) != HEAD_PACK )return FALSE;   
    if( CheckOut( pBuffer, length ) != ( (pBuffer[4]<<8)|pBuffer[5] ) ) return FALSE;          
    if( ( pBuffer[3]+6 ) != length ) return FALSE;
    
    *pCommandData = (pBuffer[2]<<8)|pBuffer[6];    //����������ݴ����һ��uint16_t ������
    
    return TRUE;

}






/*******************************************************************************
* Function Name  : AnalysisCarMesssageOperation
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
RetrunState AnalysisCarMesssageOperation( uint16_t pCommandData )
{
      
    switch( (pCommandData>>8)&0xFF )
    {
        case ButtJointCommand:
            switch( pCommandData & 0xFF )
            {
                case ButtJointRequest:
                        CommunicatWitchCar.eButtJoint = ButtJointRequest;
                        ButtJointTime = GetOSRunTimeNow(  );
                        DebugPrintf("get ButtJointRequest,%d\r\n", CommunicatWitchCar.eButtJoint );
                        ButtJointFlag = 0;
                    break;               
                
                case ButtJointDone:
                        CommunicatWitchCar.eButtJoint = ButtJointClose;
                        DebugPrintf("get ButtJointDone,%d\r\n", CommunicatWitchCar.eButtJoint );

                case ButtJointClose:
                        CommunicatWitchCar.eButtJoint = ButtJointClose;
                        DebugPrintf("get ButtJointClose,%d\r\n", CommunicatWitchCar.eButtJoint );
                break;
                
                default: return FALSE;
                    
            }
            break;
        
        case BatteryChargingCommand:
            switch( pCommandData & 0xFF )
            {
                case BatteryChargeRequest:
                    CommunicatWitchCar.eBatteryCharge = BatteryChargeRequest;
                    DebugPrintf("get BatteryChargeRequest,%d\r\n", CommunicatWitchCar.eBatteryCharge );
                    break;               
                
                case BatteryNeedCharge:
                    CommunicatWitchCar.eBatteryCharge = BatteryCharging;
                    DebugPrintf("get BatteryCharging,%d\r\n", CommunicatWitchCar.eBatteryCharge );
                    break;
                
                case BatteryChargeDone:
                    CommunicatWitchCar.eBatteryCharge = BatteryChargeClose;
                    DebugPrintf("get BatteryChargeDone,%d\r\n", CommunicatWitchCar.eBatteryCharge );
                    break;
                
                default: return FALSE;
                    
            }
            break;
        
        case AddWaterCommand:
            switch( pCommandData & 0xFF )
            {
                case AddWaterRequest:
                    CommunicatWitchCar.eAddWater = AddWaterRequest;
                    DebugPrintf("get AddWaterRequest,%d\r\n", CommunicatWitchCar.eAddWater );
                    break;               
                
                case AddWaterNeed:
                    CommunicatWitchCar.eAddWater = AddingWater;
                    DebugPrintf("get AddWaterNeed,%d\r\n", CommunicatWitchCar.eAddWater );
                    break;
                
                case AddWaterDone:
                    CommunicatWitchCar.eAddWater = AddWaterClose;
                    DebugPrintf("get AddWaterDone,%d\r\n", CommunicatWitchCar.eAddWater );
                    break;
                
                default: return FALSE;
                    
            }
            break;
        
        case DrainWaterCommand:
            switch( pCommandData & 0xFF )
            {
                case DrainWaterRequest:
                    CommunicatWitchCar.eDrainWater = DrainWaterRequest;
                    DebugPrintf("get DrainWaterRequest,%d\r\n", CommunicatWitchCar.eDrainWater );
                    break;               
                
                case DrainWaterNeed:
                    CommunicatWitchCar.eDrainWater = DrainingWater;
                    DebugPrintf("get DrainWaterNeed,%d\r\n", CommunicatWitchCar.eDrainWater );
                    break;
                
                case DrainWaterDone:
                    CommunicatWitchCar.eDrainWater = DrainWaterClose;
                    DebugPrintf("get DrainWaterDone,%d\r\n", CommunicatWitchCar.eDrainWater );
                    break;
                
                default: return FALSE;
                    
            }
            break;
        
        default : return FALSE;
    }
    
    return TRUE;
}










