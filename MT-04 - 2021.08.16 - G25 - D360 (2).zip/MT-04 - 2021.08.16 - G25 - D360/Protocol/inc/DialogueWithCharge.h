#ifndef __DIALOGUEWITHCHARGE_H
#define __DIALOGUEWITHCHARGE_H

#include "TaskManage.h"


void SystemDialogueWithChargeTask( void *Parammenters );

RetrunState CarSendCommandToChargeStation( uint8_t command, uint8_t *pdata, uint8_t datalength );

#endif
