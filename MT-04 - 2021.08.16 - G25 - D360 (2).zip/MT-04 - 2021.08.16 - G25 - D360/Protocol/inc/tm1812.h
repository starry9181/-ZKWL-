#ifndef __TM1812_H
#define __TM1812_H
#include "TaskManage.h"

#define T0H_IN_400ns        29
#define T1H_IN_850ns        61

typedef enum {
    BreathRedLED = 0 ,
    BreathGreenLED ,
    BreathBlueLED ,
    RollsWindingLED ,
    WorkModeLED ,    
    BoxCheckLED ,
    WiFiStateLED ,
    BoxFullLED ,
    BatteryChargeLED , 
    Reserve0 ,
    FanErroLED ,
    MotorErroLED ,                   
            
}LEDNumber;



void vTM1812Init( void );
void vSetLEDGrayscaleGrade( LEDNumber LED, uint8_t ucGrade );

#endif
