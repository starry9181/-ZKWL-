#ifndef __SINGLEENCODE_H
#define __SINGLEENCODE_H

#include "TaskManage.h"

#define SINGLE_ENCODE_HEAD         0xABCD          //����ͷ

bool analysisSingleEncodeAngle( uint8_t *pBuffer, uint8_t length );

float Enc_Change_Angle(float enc);
float Angle_Change_Enc(float angle);


#endif
