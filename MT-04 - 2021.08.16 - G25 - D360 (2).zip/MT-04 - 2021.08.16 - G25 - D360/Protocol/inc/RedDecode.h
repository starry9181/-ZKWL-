#ifndef __REDDECODE_H
#define __REDDECODE_H
#include "TaskManage.h"


#define THRESHOLD       200
//#define START_BIT_TIME  2000
#define LOGIC_0_TIME    1000
#define LOGIC_1_TIME    1500
#define END_BIT_TIME    2000

#define LOGIC_0_TIME_UPPER_LIMIT      ( LOGIC_0_TIME + THRESHOLD )
#define LOGIC_0_TIME_LOWER_LIMIT      ( LOGIC_0_TIME - THRESHOLD )

#define LOGIC_1_TIME_UPPER_LIMIT      ( LOGIC_1_TIME + THRESHOLD )
#define LOGIC_1_TIME_LOWER_LIMIT      ( LOGIC_1_TIME - THRESHOLD )

#define END_BIT_TIME_UPPER_LIMIT      ( END_BIT_TIME + THRESHOLD )
#define END_BIT_TIME_LOWER_LIMIT      ( END_BIT_TIME - THRESHOLD )


/*******************���յ����������***********************/
typedef enum{
    DecodeNumberNone = 0,
    DecodeNumber1 ,
    DecodeNumber2 ,
    DecodeNumber3 ,
    DecodeNumber4
}DecodeNumber;




/*******************���յ����������Ϣ***********************/
typedef struct {
    int8_t DecodeChar[4]; 
    TickType_t DecodeTimeOut[4];
}DecodeStruct;



extern QueueHandle_t xQueueInfraredDecoding;
extern __IO DecodeStruct LeftSensorDecode;                  //�����ͷ
extern __IO DecodeStruct LeftCentreSensorDecode;            //���н���ͷ
extern __IO DecodeStruct RightCentreSensorDecode;           //���н���ͷ
extern __IO DecodeStruct RightSensorDecode;                 //�ҽ���ͷ









__inline void GetRedDecodeResult( uint8_t *pResultBuffer );
void SystemInfraredDecodingTask( void *Parammenters );
void DecodeTimeOutHandle( void );
     





#endif
