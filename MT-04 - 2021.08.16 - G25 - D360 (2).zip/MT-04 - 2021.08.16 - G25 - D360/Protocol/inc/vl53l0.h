#ifndef __VL53L0_H
#define __VL53L0_H

#include "TaskManage.h"


bool ReadDropDepthVl53l0( void );

#endif
