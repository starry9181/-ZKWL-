#ifndef __LCDGUI_H
#define __LCDGUI_H
#include "TaskManage.h"


#define LCD_DADA_HEAD  0x050A

#define SelectMainBoard            1
#define SelectLoamCakeBoard        2
#define SelectInfraredBoard        3
//#define SelectWheelBoard           4
#define ClearTestData              4
#define SendTestData               5
#define LcdGuiNow                  6
typedef enum{
    PageMain = 0,
    PageSet ,
    PageTest ,
    PageError ,
    PageBox ,
}GUI;

typedef enum {
    MainBoard = 0 ,                 //ѡ������
    LoamCakeBoard ,                 //�ϸǰ�
    InfraredBoard ,                 //�����
    WheelBoard                      //���Ӱ�  
}Board;


typedef struct{    
    uint32_t TestNumber;            //���԰�����
    uint32_t SeccessNumber;         //�ɹ�������
    uint32_t AllTestNumber;         //���в��԰�����    
    uint32_t TestDataFlash;         //�������ݵ�������ַ
    uint16_t DefectivePercentage;   //��Ʒ��
    Board SelectBoard;              //����ѡ��
    uint8_t ProgressBar;            //������  
}TestStuct;
    
    
extern volatile TestStuct * const pTestData;
extern volatile GUI SetGuiNow;           //����LCD��ǰUI
extern uint8_t SetGuiFlag;


#define guiSetGuiNow( GUI )  SetGuiNow = GUI; SetGuiFlag = 1
#define guiReadSetGuiFlag(  )  SetGuiFlag
#define guiClearGuiFlag(  )  SetGuiFlag = 0



void VLCD_GUI_Task( void *Parammenters );
void SendNumberCommandToLCD( uint8_t *pStrings, uint32_t Number );
void SendSringsCommandToLCD( uint8_t *pStrings, uint8_t length );
void SendpercentageCommandToLCD( uint8_t *pStrings, uint8_t Number );
void SendProgressBarToLCD( uint8_t Number );    
void SendTestDataToLCD( void );

void SendErrorNumberToLCD( uint8_t Location, uint32_t Number );
void TestDoneDrawCirsLCD( void );

uint8_t AnalysisLCDCommand( uint8_t *pData, uint8_t length ); 
void HandleLCDCommand( uint8_t *pData, uint8_t length );


#endif
