#ifndef __ULTRASONIC_H
#define __ULTRASONIC_H


#include "TaskManage.h"


	#define  FARTHEST_RANGE1   0xb1      //continuous return data,suggest greater than 2m, dead zone 290mm, fathest 3500mm      
	#define  FARTHEST_RANGE2   0xb2      //once return data, suggest greater than 2m, dead zone 290mm, fathest 3500mm      
	#define  FARTH_RANGE1      0xb3      //continuous return data,suggest less than 2m,dead zone 250mm, fathest 3500mm
	#define  FARTH_RANGE2      0xb4      //once return data,suggest less than 2m,dead zone 250mm, fathest 3500mm
	#define  FARTHER_RANGE1    0xb5      //continuous return data,suggest less than 1.5m,dead zone 205mm, fathest 1500mm
	#define  FARTHER_RANGE2    0xb6      //once return data,suggest less than 1.5m,dead zone 205mm, fathest 1500mm
	#define  NEARLY_RANGE1     0xb7      //continuous return data,suggest less than 1m,dead zone 200mm, fathest 1000mm
	#define  NEARLY_RANGE2     0xb8      //once return data,suggest less than 1m,dead zone 200mm, fathest 1000mm
	#define  NEARLY_RANGE3     0xb9      //continuous return data,suggest less than 0.2m,dead zone 200mm, fathest 1000mm
	#define  NEARLY_RANGE4     0xba      //once return data,suggest less than 0.2m,dead zone 200mm, fathest 1000mm
	#define  FARTHEST_RANGE3   0xbb      //continuous return data,suggest greater than 3m,dead zone 290mm, fathest 5000mm
	#define  FARTHEST_RANGE4   0xbc      //once return data,suggest greater than 3m,dead zone 290mm, fathest 5000mm
    
	#define SENSOR_0           (1<<0)
	#define SENSOR_1           (1<<1)
	#define SENSOR_2           (1<<2)
	#define SENSOR_3           (1<<3)
	#define SENSOR_4           (1<<4)
	#define SENSOR_5           (1<<5)
	#define SENSOR_6           (1<<6)
	#define SENSOR_7           (1<<7)
	#define SENSOR_8           (1<<8)
	#define SENSOR_9           (1<<9)
	#define SENSOR_10          (1<<10)
	#define SENSOR_11          (1<<11)
	#define SENSOR_ALL         ( SENSOR_0|SENSOR_1|SENSOR_2|SENSOR_3|SENSOR_4|SENSOR_5|SENSOR_6|SENSOR_7|SENSOR_8|SENSOR_9|SENSOR_10|SENSOR_11 )
	#define SENSOR_NO          0
	
	
#define DATA_HEAD              0
#define OPERATION_CODE         1
#define DATA_LENGTH            2
#define ULTRANSON_DATA         3

typedef struct{
	uint8_t MachineNumber;
	uint8_t SensorNumber;
	uint16_t GetData[12];
}UltrasonicParameter;
		
typedef struct{
	uint8_t MachineNumber;
    uint16_t AverageDistance;
    uint32_t AllDistance;
	uint16_t Data[8];
}SystemUltrasonic;

extern SystemUltrasonic systemUltrasonic;

void UltrasonicTring( void );
bool UltrasonicCheacUpAllow( void );
bool UltrasonicCheacDownAllow( void );



#endif

