#ifndef __DIALOGUEWITHCAR_H
#define __DIALOGUEWITHCAR_H
#include "TaskManage.h"







#define HEAD_PACK                        0x050B



#define ButtJointCommand                 0x00      //�Խ�����
    typedef enum{
        ButtJointRequest = 1 ,       //�Խ�����
        FastSwingLeft ,
        FastSwingRight ,
        FastRetreate ,
        SlowSwingLeft ,
        SlowSwingRight ,
        SlowRetreate ,
        CarStop ,
        ButtJointDone ,              //�Խ����
        ButtJointClose               //�رնԽ�ģʽ       
    }ButtJoint;
    
#define BatteryChargingCommand           0x01      //�������
    typedef enum{
        BatteryChargeRequest = 1 ,  //�������
        BatteryNeedCharge ,
        BatteryCharging ,
        BatteryChargeDone ,
        BatteryChargeClose
    }BatteryCharge;
#define AddWaterCommand                  0x02      //��ˮ����
    typedef enum{
        AddWaterRequest = 1 ,
        AddWaterNeed ,
        AddingWater ,
        AddWaterDone ,
        AddWaterClose 
    }AddWater;
#define DrainWaterCommand                0x03      //��ˮ���� 
    typedef enum{
        DrainWaterRequest = 1 ,
        DrainWaterNeed ,
        DrainingWater,
        DrainWaterDone ,
        DrainWaterClose
    }DrainWater;
#define DecodeCommand                    0x04      //��������


    
typedef struct{
    ButtJoint eButtJoint;
    BatteryCharge eBatteryCharge;
    AddWater eAddWater;
    DrainWater eDrainWater;
}CommunicationWithCar; 
    
    
    

extern CommunicationWithCar CommunicatWitchCar;
extern TickType_t ButtJointTime;



uint16_t CheckOut( uint8_t buffer[], uint8_t length );
RetrunState ChargeStationSendCommandToCar( uint8_t command, uint8_t *pdata, uint8_t datalength );

RetrunState AnalysisCarMesssage( uint8_t *pBuffer, uint8_t length, uint16_t *pCommandData );    
RetrunState AnalysisCarMesssageOperation( uint16_t pCommandData );
#endif
