#ifndef __MODBUS_H
#define __MODBUS_H
#include "TaskManage.h"

void packageModbusData( unsigned char slaveAddress, unsigned char sommand, unsigned short dataAddress, unsigned short dataLength ); 

void analysisModbusData( unsigned char buffer[], unsigned int length );

#endif
