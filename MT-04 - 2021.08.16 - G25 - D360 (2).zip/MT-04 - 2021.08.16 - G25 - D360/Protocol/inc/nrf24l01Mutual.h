#ifndef __NRF24L01MUTUAL_H
#define __NRF24L01MUTUAL_H

#include "TaskManage.h"



//#define TURN_ON_OFF_15_MINUTE_MODE     0x00
//#define TURN_ON_OFF_FORCE_MODE         0x01

//#define SELECTED_LENGTH_MODE         0x00
//#define CONTINUE_MODE                0x01

#define TURN_OFF_NA_LIGHT            0x00
#define TURN_ON_NA_LIGHT             0x01

#define SET_SYSTEM_DOWM              0x00
#define SET_SYSTEM_UP                0x01 

#define TURN_OFF_RED_LED             0x00
#define TURN_ON_RED_LED              0x01

#define TURN_OFF_GREEN_LED           0x02
#define TURN_ON_GREEN_LED            0x03

#define TURN_OFF_BLUE_LED            0x04
#define TURN_ON_BLUE_LED             0x05

#define TURN_OFF_LED_LIGHT           0x00
#define TURN_ON_LED_LIGHT            0x01


typedef enum{
    AcContrlNaID = 1,
    DcContrlLedID = 2,
    RiseAndFallID = 3,
    AcContrlLedID = 4,
}ProductID;

typedef enum{
    WatchCommand = 0,
    AcContrlNaCommand = 1,
    DcContrlLedCommand = 2,
    RiseAndFallCommand = 3,
    AcContrlLedCommand = 4,
}CommandType;

typedef struct{
    uint8_t FactoryNumber;  //���ұ��
    uint8_t ProductID;      //��ƷID
    uint16_t Versions;      //��Ʒ�汾��
    uint8_t CommandType;    //��������
    uint8_t Command;        //���� 
    uint8_t Buffer[20];
    uint8_t DataLength;
}ComInfo;


#define NRF_HEAD                0x050A    //����ͷ
#define FACTORY_NUMBER          0x01      //���ұ��
#define PRODUCT_ID              RiseAndFallID      //��ƷID
#define PRODUCT_VERSIONS        0x0100    //��Ʒ�汾�����ֽ�Ϊ�汾���������ֽ�Ϊ�汾С������0x0100��ʾΪʮ����1.0�汾




extern ComInfo ProductInfo;


void vnRF24L01SendMassage( uint8_t command );
void ProductInformationInit( void *pInfo, uint8_t command, ProductID pProductID, CommandType pCommandType );
void PackProductInformationData( void *pInfo, uint8_t buffer[], uint8_t length );
void SetProductInformationCommand( void *pInfo, uint8_t Command );
void nRF24L01SendMassage( void *pInfo );
MyBool AnalysisnRF24L01ReceiveMassage( void *pInfo );
void nRF24L01ReceiveCommand(void *pInfo );
void nRF24L01Mutual( void );







#endif
