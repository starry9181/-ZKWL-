#ifndef __TOF05140_H
#define __TOF05140_H

#include "TaskManage.h"


typedef struct {
    uint16_t LeftFront;             
    uint16_t RightFront;
    uint16_t LeftBehind;
    uint16_t RightBehind;
}FallSensor;


#if 1
	#define Tof05140Debug( fmt, arg... ) printf( "[DEBUG][%s,%d]"fmt, __FUNCTION__, __LINE__, ##arg )
#else
	#define Tof05140Debug( fmt, arg... )
#endif


extern uint16_t DropDepth;


uint16_t ReadDropDepth( void );
bool ReadDropDepthUpAllow( void );
bool ReadDropDepthDownAllow( void );
void AnalysisDropFallData( uint8_t *pBuffer, uint8_t Length, uint16_t *pData );

#endif
