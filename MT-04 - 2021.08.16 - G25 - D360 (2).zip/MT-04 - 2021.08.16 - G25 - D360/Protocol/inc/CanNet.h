#ifndef __CANNET_H
#define __CANNET_H
//extern "C"
//{
#include "TaskManage.h"


#if 0
	#define CanNetDebug( fmt, arg... ) printf( "[DEBUG][%s,%d]"fmt, __FUNCTION__, __LINE__, ##arg )
#else
	#define CanNetDebug( fmt, arg... )
#endif

#if 1
	#define CanNetError( fmt, arg... ) printf( "[ERROR][%s,%d]"fmt, __FUNCTION__, __LINE__, ##arg )
#else
	#define CanNetError( fmt, arg... )
#endif 

#define FALL_THRESHOLD    150   //��������ֵ

typedef enum{
	BroadcastID = 0,             //�㲥ID
	AckermanContrlPCID = 1 ,      //can���ػ�ID
    AckermanChassisID = 2,        //���̿��ư�ID
}CanID;


#define SET_SPEED_ANGLE       1
#define REPORT_SPEED_ANGLE       2

#define CENTRE_ENCODE_ANGLE     1
#define RIGHT_ENCODE_ANGLE     2

#define  LOW_SPEED         1667
#define  MID_SPEED         3333
#define  HIGH_SPEED        5000

#define  LOW_SPEED_MODE         0x00
#define  MID_SPEED_MODE         0x01
#define  HIGH_SPEED_MODE        0x02


/****************CAN���ݰ��ṹ****************/
typedef struct{
	uint8_t TransmitID;    //���ͽڵ��ID
	uint8_t Command;       //����
	uint8_t Data[6];       //����
}CanData;

/****************��������Ϣ****************/
typedef struct{
    uint8_t Command;       //����
    uint8_t BoardID;       //����ID
}Sensor;


typedef struct{
    char data;
    float angle;
    float encodeAngle;
}AngleQuantization;

typedef struct{
    char data;
    int16_t speed;
}SpeedQuantization;

typedef struct{
    int16_t robotVelocity;       //�����ƶ��ٶ�
    int16_t robotAckermanAngle;  //��������
    uint8_t battery;             //���� 

    uint8_t turnToWheelError : 1;          //ת���ֵ������
    uint8_t behindLeftWheelError : 1;      //�����ֹ���
    uint8_t behindRightWheelError : 1;     //�����ֹ���
    uint8_t scram : 1;                     //��ͣ 
    uint8_t frontCrash : 1;                //ǰ����
    uint8_t behindCrash : 1;               //�󴥱�
    
    uint8_t reseve : 2;                    //����
    
}canContrl;

extern canContrl SendData;
extern AngleQuantization canAngle[37];
extern uint8_t  speed_mode;

void canMessageInit( void *pAllSensor );
void canMessageDataCollect( void *data );
void canMessageContrlCanModule( void );
void PackageCanBackageSendToNode( uint32_t OwnID, uint32_t TargetID, uint16_t Command, void *pData, uint8_t length );
uint8_t Can_Send_Data(uint16_t canid , const uint8_t * data , uint8_t num);
//} //end extern "C"
#endif
