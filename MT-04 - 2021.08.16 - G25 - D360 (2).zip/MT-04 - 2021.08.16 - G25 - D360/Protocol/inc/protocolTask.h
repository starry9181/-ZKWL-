#ifndef __PROTOCOLTASK_H
#define __PROTOCOLTASK_H

#include "TaskManage.h"





void SystemProtocolTask( void *Parammenters );





#endif
