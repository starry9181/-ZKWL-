#ifndef __ROSTOPIC_H
#define __ROSTOPIC_H

#include "TaskManage.h"
#include "RosNode.h"
#include "ros.h"
#include "std_msgs/String.h"
#include "sensor_msgs/Range.h"
#include "geometry_msgs/Twist.h"




void RosTopicWorkTask( void *Parammenters );
void cmd_velCallback(const geometry_msgs::Twist&cmd_vel);
void ros_node_init(  void  );
void ros_node_spinOnce(  void  );


#endif