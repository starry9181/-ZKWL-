#ifndef __ROSNODE_H
#define __ROSNODE_H
#include "TaskManage.h"


class RosNode
{
	public:
		RosNode( )
		{
		
		}
		void init(void)
        {
            baud_ = 115200;
            //Usart2Init( baud_ );
        }
        
        int getBaud( ){return baud_;}
        
        void setBaud(long baud)
        {
            this->baud_= baud;
        }
        
		int read( void )
        {
			int length;
            length = ucReadBufferCharDataFromUSART2(  );
			return length;
			
        }
		void write(uint8_t* pBuffer, int length )
        {
            WriteDataToUSART2TrainsmitBuffer( pBuffer, length );
        }
		
		unsigned long time( void )
		{
			return (unsigned long)GetOSRunTimeNow(  );
		}
        
    protected:        
        long baud_;
};


#endif

