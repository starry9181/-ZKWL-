/******************************************************************************
* �ļ���  ��IoOut.c
* �ļ�����:
* ������  ��Liu Tusheng
* ��    �գ�2017��11��27��
* Ӳ�����ӣ�
* 
******************************************************************************/
#include "RosTopic.h"



//-------------ROS����----------------
ros::NodeHandle nodeHandle;      //����ROS�ڵ���



//����������ģ��
sensor_msgs::Range sonar0;
sensor_msgs::Range sonar1;
sensor_msgs::Range sonar2;
sensor_msgs::Range sonar3;
sensor_msgs::Range sonar4;
//sensor_msgs::Range sonar5;
//sensor_msgs::Range sonar6;
//sensor_msgs::Range sonar7;
//sensor_msgs::Range sonar8;
//sensor_msgs::Range sonar9;
//sensor_msgs::Range sonar10;
//sensor_msgs::Range sonar11;
std_msgs::String msg1;
//rosserial_arduino::gotopose point;


//ros::Publisher pose( "pose",&point );
//����������ģ��Ļ���
ros::Publisher sonar0_pub( "/sonar0", &sonar0 );
ros::Publisher sonar1_pub( "/sonar1", &sonar1 );
ros::Publisher sonar2_pub( "/sonar2", &sonar2 );
ros::Publisher sonar3_pub( "/sonar3", &sonar3 );
ros::Publisher sonar4_pub( "/sonar4", &sonar4 );
//ros::Publisher sonar5_pub( "/sonar5", &sonar5 );
//ros::Publisher sonar6_pub( "/sonar6", &sonar6 );
//ros::Publisher sonar7_pub( "/sonar7", &sonar7 );
//ros::Publisher sonar8_pub( "/sonar8", &sonar8 );
//ros::Publisher sonar9_pub( "/sonar9", &sonar9 );
//ros::Publisher sonar10_pub( "/sonar10", &sonar10 );
//ros::Publisher sonar11_pub( "/sonar11", &sonar11 );

//ros::Publisher pub( "stm_publish", &msg1 );



ros::Subscriber<geometry_msgs::Twist>sub( "cmd_vel", cmd_velCallback );  //�������ⶩ�Ļص�������ڵ�ַ



/*******************************************************************************
* Function Name  : RosTopicWorkTask
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void RosTopicWorkTask( void *Parammenters )
{
	
	ros_node_init(  );
	
	while( 1 )
	{
		ros_node_spinOnce(  );
	}
	
}


/*******************************************************************************
* Function Name  : get_min_data
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
uint16_t get_min_data( uint16_t *pBuffer, char number )
{
	uint16_t min = 5000;
	char i;
	
	for( i=0;i<number;i++ )
	{
		if( pBuffer[i] < min  )
		{
			min = pBuffer[i];
		}
		
	}
	
	return min;
}


/*******************************************************************************
* Function Name  : get_two_data_min
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
uint16_t get_two_data_min( uint16_t data1, uint16_t data2 )
{
	uint16_t min;
	
	if( data1 <= data2 )
	{
		min = data1;
	}
	else
	{
		min = data2;
	}
	
	return min;
}

/*******************************************************************************
* Function Name  : ultrasound_ros_data_package
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void ultrasound_ros_data_package(  void  )
{ 
#define FILED_VIEW 1.0
#define MIN_RANGE 0.05
#define MAX_RANGE 4.00
#define RANGe_CHANGE 1000.0
	sonar0.radiation_type  = sensor_msgs::Range::ULTRASOUND;
	sonar0.header.frame_id = "/sonar0";
	sonar0.field_of_view = FILED_VIEW;
	sonar0.min_range = MIN_RANGE;
	sonar0.max_range = MAX_RANGE;
//	sonar0.range = get_min_data( &UltrasonicSensor.GetData[0], 3 )/RANGe_CHANGE;
	sonar0.header.stamp = nodeHandle.now(  );
	sonar0_pub.publish( &sonar0 );
	
	sonar1.radiation_type  = sensor_msgs::Range::ULTRASOUND;
	sonar1.header.frame_id = "/sonar1";
	sonar1.field_of_view = FILED_VIEW;
	sonar1.min_range = MIN_RANGE;
	sonar1.max_range = MAX_RANGE;
//	sonar1.range = get_min_data( &UltrasonicSensor.GetData[3], 2 )/RANGe_CHANGE;
	sonar1.header.stamp = nodeHandle.now(  );
	sonar1_pub.publish( &sonar1 );
	
	sonar2.radiation_type  = sensor_msgs::Range::ULTRASOUND;
	sonar2.header.frame_id = "/sonar2";
	sonar2.field_of_view = FILED_VIEW;
	sonar2.min_range = MIN_RANGE;
	sonar2.max_range = MAX_RANGE;
//	sonar2.range = get_min_data( &UltrasonicSensor.GetData[5], 2 )/RANGe_CHANGE;
	sonar2.header.stamp = nodeHandle.now(  );
	sonar2_pub.publish( &sonar2 );
	
	sonar3.radiation_type  = sensor_msgs::Range::ULTRASOUND;
	sonar3.header.frame_id = "/sonar3";
	sonar3.field_of_view = FILED_VIEW;
	sonar3.min_range = MIN_RANGE;
	sonar3.max_range = MAX_RANGE;
//	sonar3.range = get_min_data( &UltrasonicSensor.GetData[8], 2 )/RANGe_CHANGE;
	sonar3.header.stamp = nodeHandle.now(  );
	sonar3_pub.publish( &sonar3 );
	
	sonar4.radiation_type  = sensor_msgs::Range::ULTRASOUND;
	sonar4.header.frame_id = "/sonar4";
	sonar4.field_of_view = FILED_VIEW;
	sonar4.min_range = MIN_RANGE;
	sonar4.max_range = MAX_RANGE;
//	sonar4.range = get_two_data_min( UltrasonicSensor.GetData[7], get_min_data( &UltrasonicSensor.GetData[10], 2 ) )/RANGe_CHANGE;
	sonar4.header.stamp = nodeHandle.now(  );
	sonar4_pub.publish( &sonar4 );
	
//	sonar5.radiation_type  = sensor_msgs::Range::ULTRASOUND;
//	sonar5.header.frame_id = "/sonar5";
//	sonar5.field_of_view = FILED_VIEW;
//	sonar5.min_range = MIN_RANGE;
//	sonar5.max_range = MAX_RANGE;
//	sonar5.range = Ultrasonic.GetData[5]/RANGe_CHANGE;
//	sonar5.header.stamp = nodeHandle.now(  );
//	sonar5_pub.publish( &sonar5 );
//	
//	sonar6.radiation_type  = sensor_msgs::Range::ULTRASOUND;
//	sonar6.header.frame_id = "/sonar6";
//	sonar6.field_of_view = FILED_VIEW;
//	sonar6.min_range = MIN_RANGE;
//	sonar6.max_range = MAX_RANGE;
//	sonar6.range = Ultrasonic.GetData[6]/RANGe_CHANGE;
//	sonar6.header.stamp = nodeHandle.now(  );
//	sonar6_pub.publish( &sonar6 );
//	
//	sonar7.radiation_type  = sensor_msgs::Range::ULTRASOUND;
//	sonar7.header.frame_id = "/sonar7";
//	sonar7.field_of_view = FILED_VIEW;
//	sonar7.min_range = MIN_RANGE;
//	sonar7.max_range = MAX_RANGE;
//	sonar7.range = Ultrasonic.GetData[7]/RANGe_CHANGE;
//	sonar7.header.stamp = nodeHandle.now(  );
//	sonar7_pub.publish( &sonar7 );
//	
//	sonar8.radiation_type  = sensor_msgs::Range::ULTRASOUND;
//	sonar8.header.frame_id = "/sonar8";
//	sonar8.field_of_view = FILED_VIEW;
//	sonar8.min_range = MIN_RANGE;
//	sonar8.max_range = MAX_RANGE;
//	sonar8.range = Ultrasonic.GetData[8]/RANGe_CHANGE;
//	sonar8.header.stamp = nodeHandle.now(  );
//	sonar8_pub.publish( &sonar8 );
//	
//	sonar9.radiation_type  = sensor_msgs::Range::ULTRASOUND;
//	sonar9.header.frame_id = "/sonar9";
//	sonar9.field_of_view = FILED_VIEW;
//	sonar9.min_range = MIN_RANGE;
//	sonar9.max_range = MAX_RANGE;
//	sonar9.range = Ultrasonic.GetData[9]/RANGe_CHANGE;
//	sonar9.header.stamp = nodeHandle.now(  );
//	sonar9_pub.publish( &sonar9 );
//	
//	sonar10.radiation_type  = sensor_msgs::Range::ULTRASOUND;
//	sonar10.header.frame_id = "/sonar10";
//	sonar10.field_of_view = FILED_VIEW;
//	sonar10.min_range = MIN_RANGE;
//	sonar10.max_range = MAX_RANGE;
//	sonar10.range = Ultrasonic.GetData[10]/RANGe_CHANGE;
//	sonar10.header.stamp = nodeHandle.now(  );
//	sonar10_pub.publish( &sonar10 );
//	
//	sonar11.radiation_type  = sensor_msgs::Range::ULTRASOUND;
//	sonar11.header.frame_id = "/sonar11";
//	sonar11.field_of_view = FILED_VIEW;
//	sonar11.min_range = MIN_RANGE;
//	sonar11.max_range = MAX_RANGE;
//	sonar11.range = Ultrasonic.GetData[11]/RANGe_CHANGE;
//	sonar11.header.stamp = nodeHandle.now(  );
//	sonar11_pub.publish( &sonar11 );
	
	
	
}



/*******************************************************************************
* Function Name  : ultrasound
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void ros_node_init(  void  )
{
	nodeHandle.initNode(    );
	nodeHandle.advertise( sonar0_pub );
	nodeHandle.advertise( sonar1_pub );
	nodeHandle.advertise( sonar2_pub );
	nodeHandle.advertise( sonar3_pub );
	nodeHandle.advertise( sonar4_pub );
//	nodeHandle.advertise( sonar5_pub );
//	nodeHandle.advertise( sonar6_pub );
//	nodeHandle.advertise( sonar7_pub );
//	nodeHandle.advertise( sonar8_pub );
//	nodeHandle.advertise( sonar9_pub );
//	nodeHandle.advertise( sonar10_pub );
//	nodeHandle.advertise( sonar11_pub );
	nodeHandle.subscribe( sub );
//	nodeHandle.advertise( pub );
}


/*******************************************************************************
* Function Name  : ultrasound
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void ros_node_spinOnce(  void  )
{
	static TickType_t RosNotePublishTime = 0;
	
	if( MultipleTimeoutCheck(  &RosNotePublishTime, 50  ) == TimeOut  )
	{
		ultrasound_ros_data_package(    );
		nodeHandle.spinOnce(    );
	}
	
}





/*******************************************************************************
* Function Name  : cmd_velCallback
* Description    : 
* Input          : None
* Output         : None
* Return         : None
*******************************************************************************/
void cmd_velCallback( const geometry_msgs::Twist&cmd_vel )
{ 
	double xx = 0.0,zz = 0.0;
	xx=cmd_vel.linear.x;  //�ٶ�
	zz=cmd_vel.angular.z; //��ת��
//	msg1.data = "hello";
//	pub.publish( &msg1 );
	if(  xx > 0.05  )        //ǰ��
	{
		SetRobotRunState(  robotForward  );
	}
	else if(  xx < -0.05  )   //����
	{
		SetRobotRunState(  robotRtreate  );
	}
	else                  
	{
		SetRobotRunState(  robotStop  );
	}
	
	if(  zz > 0.3  )        //��ʱ����ת
	{
		SetRobotRunState(  robotTurnLeft  );
	}
	else if(  zz < -0.3  )  //˳ʱ����ת
	{
		SetRobotRunState(  robotTurnRight  );
	}
	else
	{
		//SetRobotRunState(  robotForward  );
	}
			
}




