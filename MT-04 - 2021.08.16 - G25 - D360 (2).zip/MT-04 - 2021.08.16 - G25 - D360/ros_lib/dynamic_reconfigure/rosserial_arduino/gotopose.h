#ifndef _ROS_rosserial_arduino_gotopose_h
#define _ROS_rosserial_arduino_gotopose_h

#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include "ros/msg.h"

namespace rosserial_arduino
{

  class gotopose : public ros::Msg
  {
    public:
      typedef uint16_t _x_type;
      _x_type x;
      typedef uint16_t _y_type;
      _y_type y;
      typedef uint16_t _w_type;
      _w_type w;
      typedef uint16_t _timeout_type;
      _timeout_type timeout;

    gotopose():
      x(0),
      y(0),
      w(0),
      timeout(0)
    {
    }

    virtual int serialize(unsigned char *outbuffer) const
    {
      int offset = 0;
      *(outbuffer + offset + 0) = (this->x >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->x >> (8 * 1)) & 0xFF;
      offset += sizeof(this->x);
      *(outbuffer + offset + 0) = (this->y >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->y >> (8 * 1)) & 0xFF;
      offset += sizeof(this->y);
      *(outbuffer + offset + 0) = (this->w >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->w >> (8 * 1)) & 0xFF;
      offset += sizeof(this->w);
      *(outbuffer + offset + 0) = (this->timeout >> (8 * 0)) & 0xFF;
      *(outbuffer + offset + 1) = (this->timeout >> (8 * 1)) & 0xFF;
      offset += sizeof(this->timeout);
      return offset;
    }

    virtual int deserialize(unsigned char *inbuffer)
    {
      int offset = 0;
      this->x =  ((uint16_t) (*(inbuffer + offset)));
      this->x |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      offset += sizeof(this->x);
      this->y =  ((uint16_t) (*(inbuffer + offset)));
      this->y |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      offset += sizeof(this->y);
      this->w =  ((uint16_t) (*(inbuffer + offset)));
      this->w |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      offset += sizeof(this->w);
      this->timeout =  ((uint16_t) (*(inbuffer + offset)));
      this->timeout |= ((uint16_t) (*(inbuffer + offset + 1))) << (8 * 1);
      offset += sizeof(this->timeout);
     return offset;
    }

    const char * getType(){ return "rosserial_arduino/gotopose"; };
    const char * getMD5(){ return "e5853b47356d259bb44cb78b037e403b"; };

  };

}
#endif