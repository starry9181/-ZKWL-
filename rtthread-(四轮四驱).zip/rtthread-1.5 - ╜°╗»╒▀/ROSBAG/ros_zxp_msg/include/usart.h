#ifndef __USART_H_
#define __USART_H_

/*************************************************************************/
#define PROTOBUF_SIZE 30		//数组长度
#define HEADER    0xDEED		//数据头
#define Base_Width    0.3588f		//车体(X^2+Y^2)开方，斜对角半径
/*************************************************************************/
typedef unsigned char      u8;
typedef unsigned short int u16;
typedef short int          s16;
/*************************************************************************/
union Upload_Data  
{
   u8 buffer[PROTOBUF_SIZE];
   
   struct _Sensor_Str_
   {
      u16 Header;
      u8  Len;
      u8  Type;
      u16 Cmd;
      u16  DataNum;
      s16 FLV;
      s16 FRV;
      s16 BLV;
      s16 BRV;
      u16 Power;
      u16 State;
      float Longitude;
      float Latitude;
      u16 Check;

   }Sensor_Str;
}SerialData;


/*************************************************************************/
//打开20ms数据上传结构体
union SendGetChass_Data  
{
   u8 buffer[12];
   struct _Sensor_Str_
   {
      u16 Header;
      u8  Len;
      u8  Type;
      u16 Cmd;
      u16 DataNum;
      u16 Date;
      u16 Check;

   }Sensor_Str;
}SerialWriteData;

/*************************************************************************/
//下发轮子速度结构体
union SendWheelSpeed_Data  
{
   u8 buffer[PROTOBUF_SIZE];
   
   struct _Sensor_Str_
   {
      u16 Header;
      u8  Len;
      u8  Type;
      u16 Cmd;
      u16 DataNum;
      s16 FLV;
      s16 FRV;
      s16 BLV;
      s16 BRV;
      u16 Stop;
      u16 Check;

   }Sensor_Str;
}SendWheelData;

/*************************************************************************/

#endif
