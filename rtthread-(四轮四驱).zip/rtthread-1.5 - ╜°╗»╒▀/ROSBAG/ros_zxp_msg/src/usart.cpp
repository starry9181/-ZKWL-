#include <usart.h>
#include <ros/ros.h>                      //类似 C 语言的 stdio.h 
#include <ros_zxp_msg/chass.h>            //要用到 msg 中定义的数据类型 
#include <serial/serial.h>                //ROS已经内置了的串口包 
#include <std_msgs/String.h> 
#include <std_msgs/Empty.h> 
#include <geometry_msgs/Pose.h>
#include <geometry_msgs/Vector3.h>
#include <geometry_msgs/Twist.h>
#include <signal.h>


serial::Serial ser; //声明串口对象 
/*************************************************************************/
void cmd_velCallback(const geometry_msgs::Twist &twist_aux)
{
   static s16 LSpeed=0,RSpeed=0;
   LSpeed = twist_aux.linear.x*1000 - twist_aux.angular.z*Base_Width*1000;
   RSpeed = twist_aux.linear.x*1000 + twist_aux.angular.z*Base_Width*1000;

   //add date
   SendWheelData.Sensor_Str.Header  = HEADER;
   SendWheelData.Sensor_Str.Len     = 20;
   SendWheelData.Sensor_Str.Type    = 0;
   SendWheelData.Sensor_Str.Cmd     = 0x0002;
   SendWheelData.Sensor_Str.DataNum = 5;
   SendWheelData.Sensor_Str.FLV     = LSpeed;
   SendWheelData.Sensor_Str.FRV     = RSpeed;
   SendWheelData.Sensor_Str.BLV     = LSpeed;
   SendWheelData.Sensor_Str.BRV     = RSpeed;
   SendWheelData.Sensor_Str.Stop    = 0;
   SendWheelData.Sensor_Str.Check   = 0;
   for (int i = 0; i < SendWheelData.Sensor_Str.Len - 2; ++i)
   {
      SendWheelData.Sensor_Str.Check += SendWheelData.buffer[i];
   }
   ser.write(SendWheelData.buffer,sizeof(SendWheelData.buffer));
   //ROS_INFO("Get the speed from cmd_vel %d %d\n",LSpeed,RSpeed);
}
/*************************************************************************/
//当关闭包时调用，关闭20ms上传
void mySigIntHandler(int sig)
{
   //add date
   SerialWriteData.Sensor_Str.Header =HEADER;
   SerialWriteData.Sensor_Str.Len    =12;
   SerialWriteData.Sensor_Str.Type   =0;
   SerialWriteData.Sensor_Str.Cmd    =0x0001;
   SerialWriteData.Sensor_Str.DataNum=0x0001;
   SerialWriteData.Sensor_Str.Date   =0x0000; //clos 20ms up data
   SerialWriteData.Sensor_Str.Check  =0;
   for (int i = 0; i < SerialWriteData.Sensor_Str.Len-2; ++i)
   {
      SerialWriteData.Sensor_Str.Check +=SerialWriteData.buffer[i];
   }
   ser.write(SerialWriteData.buffer,sizeof(SerialWriteData.buffer));
   ROS_INFO("close the serial!\n");
   //ser.close();
   ros::shutdown();
}
/*************************************************************************/
int main(int argc,char **argv)
{    
   u16 TempCheck=0,len=0;
   ros::init(argc,argv,"talker",ros::init_options::NoSigintHandler);            //解析参数，命名节点为 talker
   signal(SIGINT, mySigIntHandler);  											//把信号槽连接到mySigIntHandler保证关闭节点时能够关闭20ms数据上传

   ros::NodeHandle nh;                       //创建句柄，相当于一套工具，可以实例化 node，并且对 node 进行操作
   ros_zxp_msg::chass chass_msg;                   //创建 gps 消息
   chass_msg.FLSpeed = 155;                        //设置 x 初值
   chass_msg.FRSpeed = -155;
   chass_msg.BLSpeed = 155;
   chass_msg.BRSpeed = -155;                       //设置 y 初值
   chass_msg.State = "run";                        //设置 state 初值
   ros::Publisher pub = nh.advertise<ros_zxp_msg::chass>("chass_info",1);//创建 publisher 对象
   ros::Subscriber sub = nh.subscribe("cmd_vel",1,cmd_velCallback);  //
   ros::Subscriber sub1 = nh.subscribe("/cmd_vel_mux/input/teleop",1,cmd_velCallback);  //

   try 
    { 
         //设置串口属性，并打开串口 
        ser.setPort("/dev/ttyUSB0"); 
        ser.setBaudrate(115200); 
        serial::Timeout to = serial::Timeout::simpleTimeout(2000); 
        ser.setTimeout(to); 
        ser.open(); 
    } 
    catch (serial::IOException& e) 
    { 
        ROS_ERROR_STREAM("Unable to open port "); 
        return -1; 
    } 

    //检测串口是否已经打开，并给出提示信息 
    if(ser.isOpen()) 
    { 
        ROS_INFO_STREAM("Serial Port initialized"); 
    } 
    else 
    { 
        return -1; 
    } 
   
   //ros::Rate loop_rate(50);   //设置发送数据的频率为10Hz                               
   while(ros::ok())
   {                                                                 
     
      //wait have date to spinince ,the callback
      ser.read(SerialData.buffer,sizeof(SerialData.buffer));

      //get check
      TempCheck = 0;
      for(u8 i=0;i<PROTOBUF_SIZE-2;i++)
      {
         TempCheck += SerialData.buffer[i];
      }

      //头和校验正确
      if(SerialData.Sensor_Str.Header == HEADER && SerialData.Sensor_Str.Check == TempCheck)
      {

         
         chass_msg.FLSpeed = SerialData.Sensor_Str.FLV;                
         chass_msg.FRSpeed = SerialData.Sensor_Str.FRV;
         chass_msg.BLSpeed = SerialData.Sensor_Str.BLV;
         chass_msg.BRSpeed = SerialData.Sensor_Str.BRV;
         chass_msg.State   = SerialData.Sensor_Str.State;
         ROS_INFO("Talker:chass: FLV = %d,FRV = %d,BLV = %d,BRV = %d",chass_msg.FLSpeed,chass_msg.FRSpeed,chass_msg.BLSpeed,chass_msg.BRSpeed); //打印函数，类似 printf()
         pub.publish(chass_msg);                      //发布消息
         memset(SerialData.buffer,0,sizeof(SerialData.buffer));
      }
      else     //
      {
         ROS_INFO("Send The ON 20ms up date CMD %x %x %x\n",SerialData.Sensor_Str.Header,SerialData.Sensor_Str.Check,TempCheck);
         //add date
         SerialWriteData.Sensor_Str.Header =HEADER;
         SerialWriteData.Sensor_Str.Len    =12;
         SerialWriteData.Sensor_Str.Type   =0;
         SerialWriteData.Sensor_Str.Cmd    =0x0001;
         SerialWriteData.Sensor_Str.DataNum=0x0001;
         SerialWriteData.Sensor_Str.Date   =0x0001;
         SerialWriteData.Sensor_Str.Check  =0;
         for (int i = 0; i < SerialWriteData.Sensor_Str.Len-2; ++i)
         {
            SerialWriteData.Sensor_Str.Check +=SerialWriteData.buffer[i];
         }
         ser.write(SerialWriteData.buffer,sizeof(SerialWriteData.buffer));
         
         len = ser.available();
         //清空数据残余
         if(len > 0)
         {
            ser.read(SerialData.buffer,len);
         }
         memset(SerialData.buffer,0,sizeof(SerialData.buffer));
      }

      ros::spinOnce();
      //loop_rate.sleep();   //按前面设置的10Hz频率将程序挂起
   }
   return 0;
}
/*************************************************************************/