#include <ros/ros.h>
#include <ros_zxp_msg/chass.h>
#include <std_msgs/Float32.h>   //ROS自带的浮点类型，类似 float，但是不同
 
void gpsCallback(const ros_zxp_msg::chass::ConstPtr &msg)
{   //回调函数，参数类型为 ConstPtr 类型的指针，它被定义在之前编译生成的 gps.h 中，指向 gps 的消息
   ROS_INFO("Listener: FLV = %d,FRV = %d,BLV = %d,BRV = %d,state = %s",msg->FLSpeed,msg->FRSpeed,msg->BLSpeed,msg->BRSpeed,msg->State.c_str());
}
 
int main(int argc,char** argv){
   ros::init(argc,argv,"listener");  
   ros::NodeHandle n;
   ros::Subscriber sub = n.subscribe("chass_info",1,gpsCallback);  //
   ros::spin();
   return 0;
}