#ifndef __ADC_H
#define __ADC_H	
#include "sys.h"

#define	RESISTANCERATIO  (18+1)/1
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
extern float PowerVale;//��ѹֵ
void Adc_Init(void);
void Get_PowerData(void);
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
#endif 


