/**
  ******************************************************************************
  * @file    dealrosdata.c
  * @author  zxp
  * @version V1.0.0
  * @date    2019-09-05
  * @brief   ������λ�����ݣ�ͨ��Э��ע������ʵ��
  ******************************************************************************
  * @attention 
  * 
  ******************************************************************************
  */
#include "dealrosdata.h"
#include "sys.h" 	
#include "bsp_usart.h"
#include "motor.h"
#include <math.h>
#include <stdlib.h>
#include "ps.h"
#include "control.h"
#include "main.h"
#include "dealbkscharge.h"
#include "adc.h"
#include "errordetect.h"
//////////////////////////////////////////////////////////////////////////////////  

union RespondRobotData20MS TXData20MS;
/**************************************************************************
�������ܣ�50ms���ص�������
��ڲ�������
����  ֵ����
**************************************************************************/
//static u8 SendDataMode=0;//20ms�ϴ�ģʽ
void SendRobotDataToROS20ms(void)
{
	static union ROBOTSTA
	{
		struct bit
		{
				char stop:		1; //��ͣ
				char power: 	1; //��ѹ
				char motor: 	1; //���
				char fronde: 	1; //ǰ��ײ
				char backde: 	1; //���ײ
				char StopCon: 	1; //������ͣ
				char bit6: 		1;  
				char bit7: 		1;  
		} err;
		u8 data;
	}RobotSta;
	
	u8 i = 0;
	u16 TempCheck = 0;
	static s16 LTemEn=0,RTemEn=0,BLTemEn=0,BRTemEn=0;
	
	//��ȡ����
	RobotSta.err.stop  = STOP_READ;
	RobotSta.err.power = RobotState.bits.bit4;
	RobotSta.err.motor = RobotState.bits.bit0 | RobotState.bits.bit1 | RobotState.bits.bit2 | RobotState.bits.bit3;
	RobotSta.err.fronde = ~DELECTLEFT;
	RobotSta.err.backde = ~DELECTRIGHT;
	RobotSta.err.StopCon= RXRobotSpeed.prot.StopCon;
	
	TXData20MS.prot.Header	= DATAHEAD;
	TXData20MS.prot.Len		= 0x1C;
	TXData20MS.prot.Type	= 0x04;
	TXData20MS.prot.Cmd		= 0x81;
	TXData20MS.prot.Num		= 0x0A;
	TXData20MS.prot.FLSpeed = LeftWheel. NowSpeed;
	TXData20MS.prot.FRSpeed = RightWheel.NowSpeed;
	TXData20MS.prot.BLSpeed = BLeftWheel. NowSpeed;
	TXData20MS.prot.BRSpeed = BRightWheel. NowSpeed;
	TXData20MS.prot.FLAddEN = - (TIM1 -> CNT - LTemEn);
	TXData20MS.prot.FRAddEN = TIM4 -> CNT - RTemEn;
	TXData20MS.prot.BLAddEN = - (TIM3 -> CNT - BLTemEn);
	TXData20MS.prot.BRAddEN = TIM5 -> CNT - BRTemEn;
	TXData20MS.prot.Voltage = PowerVale*10;
	TXData20MS.prot.State   = RobotSta.data;			 //����״̬
	TXData20MS.prot.Check	= 0;
		
	for(i=0;i<sizeof(TXData20MS.data)-2;i++)
	{
		TempCheck +=  TXData20MS.data[i];
	}
	TXData20MS.prot.Check = TempCheck;
		
	USART2_DMA_TX(TXData20MS.data,sizeof(TXData20MS.data));
	
	LTemEn  =  TIM1 -> CNT;
	RTemEn  =  TIM4 -> CNT;
	BLTemEn =  TIM3 -> CNT;
	BRTemEn =  TIM5 -> CNT;
	
}

/******************************����Ӳ������********************************************/
union SendHardData TXHardData;

void ResendHardData(void)
{
	u8 i = 0;
	u16 TempCheck = 0;
	
	TXHardData.prot.Header		= DATAHEAD;
	TXHardData.prot.Len   		= 0x18;
	TXHardData.prot.Type  		= 0x04;
	TXHardData.prot.Cmd 		= 0x80;
	TXHardData.prot.Num 		= 0x08;
	TXHardData.prot.Version 	= 0x2104;
	TXHardData.prot.Power 		= 200;
	TXHardData.prot.Ratio 		= Wheel_RATIO;
	TXHardData.prot.Encoder 	= ENCODER_LINE;
	TXHardData.prot.XWheelbase 	= XWHEEL;
	TXHardData.prot.YWheelbase 	= YWHEEL;
	TXHardData.prot.WheelD 		= Wheel_D;
	TXHardData.prot.Battery		= 30;
	TXHardData.prot.Check 		= 0;
	
	for(i=0;i<sizeof(TXHardData.data)-2;i++)
	{
		TempCheck +=  TXHardData.data[i];
	}
	TXHardData.prot.Check = TempCheck;
	
	USART2_DMA_TX(TXHardData.data,sizeof(TXHardData.data));
}

/**************************************************************************
�������ܣh���ROS�·����ٶ�
��ڲ�����data
����  ֵ����
**************************************************************************/
union ReciveData RXRobotData;
union ReciveDataSpeed RXRobotSpeed;

void RXRobotDataFromROS(u8 *data)
{
	u8 i=0;
	u16 TempCheck = 0;
	for(i=0;i<sizeof(RXRobotData.data);i++)
	{
		RXRobotData.data[i] = data[i];
	}

	if(RXRobotData.prot.Header == DATAHEAD && RXRobotData.prot.Type == 0x04)
	{
		switch(RXRobotData.prot.Cmd)
		{
			case 0x00:	//��ѯӲ����Ϣ
			{
				for(i=0;i<sizeof(RXRobotData.data)-2;i++)
				{
					TempCheck += RXRobotData.data[i];
				}
				
				if(TempCheck == RXRobotData.prot.Check)
				{
					//����Ӳ����Ϣ
					ResendHardData();
				}
				break;
			}
			case 0x01:	//�������߹ر�20ms�ϴ�
			{
				for(i=0;i<sizeof(RXRobotData.data)-2;i++)
				{
					TempCheck += RXRobotData.data[i];
				}
				
				if(TempCheck == RXRobotData.prot.Check)
				{
					//����20ms�ϴ�ģʽ					
					if(RXRobotData.prot.data)
					{
						//������ʱ��
						rt_timer_start(timer1);
					}
					else
					{
						//�رն�ʱ��
						rt_timer_stop(timer1) ;
					}
				}
				break;
			}
			case 0x02:	//�����ٶ�����
			{
				for(i=0;i<sizeof(RXRobotSpeed.data);i++)
				{
					RXRobotSpeed.data[i] = data[i];
				}
				
				TempCheck =0;
				for(i=0;i<sizeof(RXRobotSpeed.data)-2;i++)
				{
					TempCheck += RXRobotSpeed.data[i];
				}
				
				if(TempCheck != RXRobotSpeed.prot.Check)
				{
					return;
				}
				
				//��ͣģʽ��
				if(RXRobotSpeed.prot.StopCon == 1)
				{
					//��ͣ
					STOP1 = 0;
					STOP2 = 0;
					STOP3 = 0;
					STOP4 = 0;
					RXRobotSpeed.prot.FLSpeed = 0;
					RXRobotSpeed.prot.FRSpeed = 0;
					RXRobotSpeed.prot.BLSpeed = 0;
					RXRobotSpeed.prot.BRSpeed = 0;
				}
				
				//ң����ģʽ�»��߼�ͣ����¶��ٶ���0
				if((Mc6c.LeftKey == 2 || Mc6c.RightKey == 0) && Mc6c.DisconFlag == 0)
				{
					RXRobotSpeed.prot.FLSpeed = 0;
					RXRobotSpeed.prot.FRSpeed = 0;
					RXRobotSpeed.prot.BLSpeed = 0;
					RXRobotSpeed.prot.BRSpeed = 0;
				}
				//������ʱ��ʱ����
				RecRosDataTimeCnt = 0;
				
				if(Mc6c.LeftKey == 2 || DealTouchFlag == 1)
				{
					return;
				}
		
				SetAddLeftWheelSpeed (RXRobotSpeed.prot.FLSpeed);
				SetAddRightWheelSpeed(RXRobotSpeed.prot.FRSpeed);
				SetAddBLeftWheelSpeed (RXRobotSpeed.prot.BLSpeed);
				SetAddBRightWheelSpeed(RXRobotSpeed.prot.BRSpeed);
				
				break;
			}
			case 3:		//�����ͼ�ͣ����
			{
				break;
			}
			default:break;
		}
		
	}
	
}
/**************************************************************************
�������ܣ�����ROS���ݳ�ʱ
��ڲ�������
����  ֵ����
**************************************************************************/
u8 RecRosDataTimeCnt=0;
void DealRosDataTimeOut(void)
{
	if(Mc6c.LeftKey == 2 && Mc6c.DisconFlag == 0)
	{
		//����������ݼ�ʱ
		RecRosDataTimeCnt = 0;
	}
	else
	{
		RecRosDataTimeCnt++;
	}
	
	//������ʱ����ٶ�
	if(RecRosDataTimeCnt > 10)
	{
		RecRosDataTimeCnt = 10;
		SetAddRightWheelSpeed (0);
		SetAddLeftWheelSpeed  (0);
		SetAddBRightWheelSpeed(0);
		SetAddBLeftWheelSpeed (0);
	}
}

