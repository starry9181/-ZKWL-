/**
  ******************************************************************************
  * @file    errordetect.c
  * @author  zxp
  * @version V1.0.0
  * @date    2019-09-05
  * @brief   整机错误检测程序
  ******************************************************************************
  * @attention 
  * 
  ******************************************************************************
  */
#include "errordetect.h"
#include "control.h"	
#include "bsp_usart.h"
#include "adc.h"
#include "timer.h"
#include "motor.h"
#include "pid.h"
#include "main.h"

union ROBOTSTATE RobotState;
/*******************************************************************************
* Function Name  : Init_ErrorDetect
* Description    : 初始化错误标志
* Input          : None
* Output         : None
* Return         : None 
****************************************************************************** */
void Init_ErrorDetect(void)
{
	RobotState.data=0;
}

/*******************************************************
* Function Name  : DealTouch
* Description    : ´¥±ß´¦Àíº¯Êý
* Input          : None
* Output         : None
* Return         : None
*********************************************************/
_Bool DealTouchFlag = 0;
u8 TouchStep=0;
void DealTouch(void)
{
	static u8 Cnt = 0,DelectStatus=0;
	switch(TouchStep)
	{
		case 0:
		{
			//触边触发且目标值不等于0
			if((DELECTLEFT == 0 || DELECTRIGHT == 0) && (LeftWheel.AimSpeed != 0 || RightWheel.AimSpeed != 0 || BLeftWheel.AimSpeed != 0 || BRightWheel.AimSpeed != 0))
			{
				//标记触发的防撞杆
				if(DELECTLEFT == 0)
				{
					DelectStatus = 1;
				}
				else if(DELECTRIGHT == 0)
				{
					DelectStatus = 1;
				}
				
				TouchStep = 1;
				//急停
				STOP1 = 0;
				STOP2 = 0;
				STOP3 = 0;
				STOP4 = 0;
				//清除速度
				SetLeftWheelSpeed(0);
				SetRightWheelSpeed(0);

				//清除PID残留
				LeftPID.ctrOut = 0;
				RightPID.ctrOut= 0;
				
			}
			break;
		}
		case 1:
		{
			//目标不为0一直停住
			if(LeftWheel.AimSpeed != 0 || RightWheel.AimSpeed != 0 || BLeftWheel.AimSpeed != 0 || BRightWheel.AimSpeed != 0)
			{
				//急停
				STOP1 = 0;
				STOP2 = 0;
				STOP3 = 0;
				STOP4 = 0;
				//清除速度
				SetLeftWheelSpeed(0);
				SetRightWheelSpeed(0);
				SetBLeftWheelSpeed(0);
				SetBRightWheelSpeed(0);
				
				SetAddLeftWheelSpeed(0);
				SetAddRightWheelSpeed(0);
				SetAddBLeftWheelSpeed(0);
				SetAddBRightWheelSpeed(0);
				
				AddLeftWheel.TempSpeed = 0;
				AddRightWheel.TempSpeed = 0;
				AddBLeftWheel.TempSpeed = 0;
				AddBRightWheel.TempSpeed = 0;
				
				//清除PID残留
				LeftPID.ctrOut = 0;
				RightPID.ctrOut= 0;
				ThreePID.ctrOut = 0;
				FourPID.ctrOut= 0;
				
			}
			else
			{
				TouchStep = 2;
			}
			break;
		}
		case 2:		//后退
		{
		
			//取消急停
			STOP1 = 1;
			STOP2 = 1;
			STOP3 = 1;
			STOP4 = 1;
			DealTouchFlag = 1;
			TouchStep = 3;
			//退500ms
			Cnt = 5;
			break;
		}
		case 3:
		{
			if(Cnt)
			{
				Cnt--;
			}
			
			if(DelectStatus == 0)
			{
				SetAddLeftWheelSpeed(200);
				SetAddRightWheelSpeed(200);
				SetAddBLeftWheelSpeed(200);
				SetAddBRightWheelSpeed(200);
			}
			else if(DelectStatus == 1)
			{
				SetAddLeftWheelSpeed(-200);
				SetAddRightWheelSpeed(-200);
				SetAddBLeftWheelSpeed(-200);
				SetAddBRightWheelSpeed(-200);
			}
			//后退时间到了
			if(Cnt == 0)
			{
				
				DealTouchFlag = 0; 
				//清除速度
				SetAddLeftWheelSpeed(0);
				SetAddRightWheelSpeed(0);
				SetAddBLeftWheelSpeed(0);
				SetAddBRightWheelSpeed(0);
				
				//触边恢复
				//if(DELECTLEFT && DELECTRIGHT)
				{
					TouchStep = 0;
				}
			}	
			break;
		}
		default :break;
	}
	
	
}

/*******************************************************************************
* Function Name  : ErrorDetect  100MS进入一次
* Description    : 错误检测
* Input          : None
* Output         : None
* Return         : None 
****************************************************************************** */

void ErrorDetect(void)
{
	static u8 error0=0,error1=0,error2=0,error3=0,error4=0;
	//目标速度为0锁住轮子
	if((LeftWheel.AimSpeed == 0 && RightWheel.AimSpeed == 0 && BRightWheel.AimSpeed == 0 && BLeftWheel.AimSpeed == 0) && RobotState.data == 0)
	{
		//驻坡
	}
	//无错误
	else if( RobotState.data == 0 && TouchStep == 0 && RXRobotSpeed.prot.StopCon == 0)
	{
		//取消急停
		STOP1 = 1;
		STOP2 = 1;
		STOP3 = 1;
		STOP4 = 1;
	}
	
	//机械按下
	if(STOP_READ == 1)
	{
		//清除速度
		SetLeftWheelSpeed(0);
		SetRightWheelSpeed(0);
		SetBLeftWheelSpeed(0);
		SetBRightWheelSpeed(0);
		
		SetAddLeftWheelSpeed(0);
		SetAddRightWheelSpeed(0);
		SetAddBLeftWheelSpeed(0);
		SetAddBRightWheelSpeed(0);
		
		AddLeftWheel.TempSpeed = 0;
		AddRightWheel.TempSpeed = 0;
		AddBLeftWheel.TempSpeed = 0;
		AddBRightWheel.TempSpeed = 0;
		
		//清除PID残留
		LeftPID.ctrOut = 0;
		RightPID.ctrOut= 0;
		ThreePID.ctrOut= 0;
		FourPID.ctrOut = 0;
	}
	//不在触边状态下 不在急停状态下 才进行错误检测
	if(TouchStep == 0 && STOP_READ ==0 && STOP1 ==1 && STOP2 ==1 && STOP3 ==1 && STOP4 ==1 && RobotState.data ==0)
	{
	
		//左轮故障检测，当PWM大于10，但是速度为0持续2S则判定故障
		if(abs(LeftWheel .MotoPwm) > (TIM8_Period/2) && LeftWheel. NowSpeed ==0 && LeftWheel.AimSpeed != 0)
		{
			error0++;
		}
		else
		{
			error0=0;
		}
		if(error0 > 20)
		{
			error0=21;
			RobotState.bits.bit0 = 1;
		}
		
		//右轮故障检测，当PWM大于10，但是速度为0持续2S则判定故障
		if(abs(RightWheel.MotoPwm) > (TIM8_Period/2) && RightWheel.NowSpeed ==0 && RightWheel.AimSpeed != 0)
		{
			error1++;
		}
		else
		{
			error1=0;
		}
		if(error1 > 20)
		{
			error1=21;
			RobotState.bits.bit1 = 1;
		}
		
		//后左轮故障检测，当PWM大于10，但是速度为0持续2S则判定故障
		if(abs(BLeftWheel .MotoPwm) > (TIM8_Period/2) && BLeftWheel. NowSpeed ==0 && BLeftWheel.AimSpeed != 0)
		{
			error2++;
		}
		else
		{
			error2=0;
		}
		if(error2 > 20)
		{
			error2=21;
			RobotState.bits.bit2 = 1;
		}
		
		//后右轮故障检测，当PWM大于10，但是速度为0持续2S则判定故障
		if(abs(BRightWheel.MotoPwm) > (TIM8_Period/2) && BRightWheel.NowSpeed ==0 && BRightWheel.AimSpeed != 0)
		{
			error3++;
		}
		else
		{
			error3=0;
		}
		if(error3 > 20)
		{
			error3=21;
			RobotState.bits.bit3 = 1;
		}
		
		//电池故障检测，当电压小于20V或者大于30V持续2S则判断电压错误
		if(PowerVale < 15 || PowerVale > 35)
		{
			error4++;
		}
		else
		{
			error4 = 0;
		}
		if(error4 > 20)
		{
			error4=21;
			RobotState.bits.bit4 = 1;
		}
	}
	//如若发生故障需要重启才能清除故障
	if(RobotState.data != 0 )
	{
		if(RobotState.bits.bit4)
		{
			BeefON(2,50);
		}
		else
		{
			BeefON(1,50);
		}
		
		//急停
		STOP1 = 0;
		STOP2 = 0;
		STOP3 = 0;
		STOP4 = 0;
		//清除速度
		SetLeftWheelSpeed(0);
		SetRightWheelSpeed(0);
		SetBLeftWheelSpeed(0);
		SetBRightWheelSpeed(0);
		
		SetAddLeftWheelSpeed(0);
		SetAddRightWheelSpeed(0);
		SetAddBLeftWheelSpeed(0);
		SetAddBRightWheelSpeed(0);
		
		AddLeftWheel.TempSpeed = 0;
		AddRightWheel.TempSpeed = 0;
		AddBLeftWheel.TempSpeed = 0;
		AddBRightWheel.TempSpeed = 0;
		
		//清除PID残留
		LeftPID.ctrOut = 0;
		RightPID.ctrOut= 0;
		ThreePID.ctrOut= 0;
		FourPID.ctrOut = 0;
	}
}


