/**
  ******************************************************************************
  * @file    dealbkscharge.c
  * @author  zxp
  * @version V1.0.0
  * @date    2019-09-05
  * @brief   步科思回充模块的数据通信和运动的实现
  ******************************************************************************
  * @attention 
  * 
  ******************************************************************************
  */
#include "dealbkscharge.h"
#include "bsp_usart.h"
#include "control.h"
#include "timer.h"
#include "motor.h"
#include "errordetect.h"

BKSCHARGEDATA BKSChargeData;
/*******************************************************************************
* Function Name  : ExtractChargeData  
* Description    : 步科思回充数据提取函数
* Input          : data   回充数据
* Output         : None
* Return         : None 
****************************************************************************** */
u8 ExtractChargeData(u8 *data)
{
	u8 i=0,chek=0;
	
	if(data[0] == 0xAA && data[1] == 0x55)
	{
		for(i=2;i<2+data[2]+1;i++)
		{
			chek ^=data[i];
		}
		if(chek == data[2+data[2]+1])
		{
			BKSChargeData.Check		= chek;
			BKSChargeData.DataLentgh= data[2];
			BKSChargeData.Cmd		= data[3];
			for(i=0;i<BKSChargeData.DataLentgh-1;i++)
			{
				BKSChargeData.Data[i] = data[i+4];
			}
			BKSChargeData.SuccessFlag = 1;
			return 1;
		}
		BKSChargeData.SuccessFlag = 0;
	}
	BKSChargeData.SuccessFlag = 0;
	return 0;
}

/*******************************************************************************
* Function Name  : DealBKSCharge  
* Description    : 步科思回充数据处理函数
* Input          : data   回充数据
* Output         : None
* Return         : None 
****************************************************************************** */
void DealBKSCharge(u8 *data)
{
	static uint16_t xLineSpeedH=0,AngularSpeedH=0;
	static int LeftWheelSpeed=0,RightWheelSpeed=0;
	static int xLineSpeed=0,AngularSpeed=0,xLineSpeedLast=0,AngularSpeedLast=0;
	
	if(ExtractChargeData(data) == 0)			//数据错误返回
	{
		return;
	}
	
	switch(BKSChargeData.Cmd)
	{
		case CMDOPSETBreakState:				//刹车
		{
			if(BKSChargeData.Data[0] == 1){STOP_BRK = 1;}//刹车
			if(BKSChargeData.Data[0] == 0){STOP_BRK = 0;}//刹车取消
			break;
		}
		case CMDOPTestIRError:					//红外信号错误
		{
			break;
		}
		case CMDOPAutoChargeUsingTimeOut:		//回充超时
		{
			break;
		}
		case CMDOPAutoChargeButtError:			//对接失败
		{
			break;
		}
		case CMDOPAutoChargeSpit:				//充电桩脱落
		{
			break;
		}
		case CMDOPAutoChargeOver:				//自动充电完成
		{
			break;
		}
		
		case CMDOPAutoChareSystemStat:			//自动充电信息
		{
			switch(BKSChargeData.Data[0])
			{
				case 0:		//空闲
				{
					break;
				}
				case 1:		//手动充电
				{
					LedMode=0x22;
					break;
				}
				case 2:		//手动已经满了，但是还在充电桩上
				{
					LedMode=0x33;
					break;
				}
				case 3:		//正在检测红外信号
				{
					LedMode=0x01;
					break;
				}
				case 4:		//自动充电前往充电桩中
				{
					LedMode=0x03;
					break;
				}
				case 5:		//自动充电对接成功正在充电
				{
					LedMode=0x22;
					break;
				}
				case 6:
				{
					break;
				}
				case 7:		//充电已经满，脱离充电桩
				{
					LedMode=0x33;
					break;
				}

				default:break;
			}
			break;
		}
		case MoveCMD:							//移动指令
		{
			
			xLineSpeedH=BKSChargeData.Data[0];	
			xLineSpeed=(xLineSpeedH<<8)+BKSChargeData.Data[1];
			if(xLineSpeed&0x8000)
			{
				xLineSpeed^=0xFFFF;
				xLineSpeed+=1;
				xLineSpeedLast=-xLineSpeed;
			}
			else
			{
				xLineSpeedLast=(xLineSpeedH<<8)+BKSChargeData.Data[1];
			}

			AngularSpeedH=BKSChargeData.Data[4];
			AngularSpeed=(AngularSpeedH<<8)+BKSChargeData.Data[5];
			if(AngularSpeed&0x8000)
			{
				AngularSpeed^=0xFFFF;
				AngularSpeed+=1;
				AngularSpeedLast=-AngularSpeed;
			}
			else
			{
				AngularSpeedLast=(AngularSpeedH<<8)+BKSChargeData.Data[5];
			}				 
			LeftWheelSpeed =(xLineSpeedLast*2-((AngularSpeedLast)*(float)WheelGauge))/2;
			RightWheelSpeed=(xLineSpeedLast*2+((AngularSpeedLast)*(float)WheelGauge))/2;
			
			
			//左右轮加速度取消
			LeftWheel.AddDelFlag=0;
			RightWheel.AddDelFlag=0;
			
			if(LeftWheelSpeed == 0 && RightWheelSpeed == 0)
			{
				STOP_BRK = 1;
			}
			else
			{
				STOP_BRK = 0;
			}
			SetLeftWheelSpeed(LeftWheelSpeed);
			SetRightWheelSpeed(RightWheelSpeed);
			break;
		}
		
		default:break;
	}
}

/*******************************************************************************
* Function Name  : StartAutoCharge  
* Description    : 开始自动回充
* Input          : None
* Output         : None
* Return         : None 
****************************************************************************** */
void StartAutoCharge(void)
{
	static u8 data[5]={0xAA,0x55,0x01,0x6C,0x6D};
	UART4_DMA_TX(data,5);
	RobotState.bits.bit5 = 1;
	
}

/*******************************************************************************
* Function Name  : StartAutoCharge  
* Description    : 停止自动回充
* Input          : None
* Output         : None
* Return         : None 
****************************************************************************** */
void StopAutoCharge(void)
{
	static u8 data[5]={0xAA,0x55,0x01,0x6D,0x6C};
	UART4_DMA_TX(data,5);
	RobotState.bits.bit5 = 0;
	LedMode=0x33;
}


