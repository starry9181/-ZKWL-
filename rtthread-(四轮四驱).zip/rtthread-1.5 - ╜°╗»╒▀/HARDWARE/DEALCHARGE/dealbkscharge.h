#ifndef __DEALBKSCHARGE_H
#define __DEALBKSCHARGE_H	 
#include "sys.h"

#define WheelGauge                   0.337	//轮间距 
#define MoveCMD                      0x67	//移动命令
#define CMDOPCOFFON                  108
#define CMDOPCOFFOFF                 109
#define CMDOPSETBreakState           134
#define CMDOPTestIRError             141
#define CMDOPAutoChargeUsingTimeOut  142
#define CMDOPAutoChargeButtError     143
#define CMDOPAutoChargeSpit          144
#define CMDOPAutoChargeOver          145
#define CMDOPAutoChareSystemStat     146
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
//回充数据结构体
typedef struct
{
	u8 Check;	//校验
	u8 Cmd;		//命令
	u8 Data[10];//数据
	u8 DataLentgh;//数据长度
	_Bool SuccessFlag;//接收成功标志
}BKSCHARGEDATA;
extern BKSCHARGEDATA BKSChargeData;
/*+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++*/
void DealBKSCharge(u8 *data);
void StartAutoCharge(void);
void StopAutoCharge(void);
#endif


